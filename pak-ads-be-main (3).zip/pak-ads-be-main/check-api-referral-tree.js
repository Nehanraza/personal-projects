/**
 * Check API Referral Tree - Database vs API
 * Checks how many direct referrals have approved deposits
 * Then tests the actual API response
 */

require('dotenv').config();
const { sequelize, User, Deposit } = require('./src/models');
const { Op } = require('sequelize');

// User details
const userEmail = 'faisalcomedychanel@gmail.com';
const userPhone = '03497210618';

// Colors
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

async function checkAPIReferralTree() {
  try {
    console.log(`${colors.cyan}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.cyan}║  API Referral Tree Check - Database Analysis            ║${colors.reset}`);
    console.log(`${colors.cyan}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    // Step 1: Find user
    console.log(`${colors.blue}Step 1: Finding user...${colors.reset}`);
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: userEmail },
          { phone: userPhone }
        ]
      },
      attributes: ['id', 'name', 'email', 'phone']
    });

    if (!user) {
      console.log(`${colors.red}✗ User not found${colors.reset}\n`);
      process.exit(1);
    }

    console.log(`${colors.green}✓ User found: ${user.name} (ID: ${user.id})${colors.reset}\n`);

    // Step 2: Get ALL direct referrals with deposits
    console.log(`${colors.blue}Step 2: Checking direct referrals and their deposit status...${colors.reset}`);
    const directReferrals = await User.findAll({
      where: { referred_by: user.id },
      attributes: ['id', 'name', 'email', 'created_at'],
      include: [
        {
          model: Deposit,
          as: 'deposits',
          attributes: ['id', 'status', 'amount'],
          required: false,
        },
      ],
      order: [['created_at', 'DESC']],
    });

    console.log(`   Total Direct Referrals: ${colors.green}${directReferrals.length}${colors.reset}\n`);

    // Step 3: Categorize by deposit status
    const withApprovedDeposits = [];
    const withoutApprovedDeposits = [];

    directReferrals.forEach(ref => {
      const hasApprovedDeposit = ref.deposits && ref.deposits.some(d => d.status === 'approved');
      const approvedDeposit = ref.deposits?.find(d => d.status === 'approved');
      
      if (hasApprovedDeposit) {
        withApprovedDeposits.push({
          id: ref.id,
          name: ref.name,
          email: ref.email,
          depositAmount: approvedDeposit ? parseFloat(approvedDeposit.amount) : null,
        });
      } else {
        withoutApprovedDeposits.push({
          id: ref.id,
          name: ref.name,
          email: ref.email,
        });
      }
    });

    console.log(`${colors.cyan}Direct Referrals WITH Approved Deposits: ${colors.green}${withApprovedDeposits.length}${colors.reset}`);
    if (withApprovedDeposits.length > 0) {
      withApprovedDeposits.forEach((ref, index) => {
        console.log(`   ${index + 1}. ID: ${ref.id}, Name: ${ref.name}, Email: ${ref.email}, Deposit: ${ref.depositAmount} PKR`);
      });
    }
    console.log('');

    console.log(`${colors.yellow}Direct Referrals WITHOUT Approved Deposits: ${withoutApprovedDeposits.length}${colors.reset}`);
    if (withoutApprovedDeposits.length > 0 && withoutApprovedDeposits.length <= 10) {
      withoutApprovedDeposits.forEach((ref, index) => {
        console.log(`   ${index + 1}. ID: ${ref.id}, Name: ${ref.name}, Email: ${ref.email}`);
      });
    } else if (withoutApprovedDeposits.length > 10) {
      withoutApprovedDeposits.slice(0, 5).forEach((ref, index) => {
        console.log(`   ${index + 1}. ID: ${ref.id}, Name: ${ref.name}, Email: ${ref.email}`);
      });
      console.log(`   ... and ${withoutApprovedDeposits.length - 5} more`);
    }
    console.log('');

    // Step 4: Count indirect referrals
    console.log(`${colors.blue}Step 3: Counting indirect referrals by level...${colors.reset}`);
    const levelCounts = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, 1 as level
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, rt.level + 1
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT level, COUNT(*) as count
      FROM referral_tree
      GROUP BY level
      ORDER BY level;
    `, {
      replacements: { userId: user.id },
      type: sequelize.QueryTypes.SELECT,
    });

    let totalIndirect = 0;
    console.log(`${colors.cyan}Network Summary by Level:${colors.reset}`);
    levelCounts.forEach(item => {
      const level = parseInt(item.level, 10);
      const count = parseInt(item.count, 10);
      if (level === 1) {
        console.log(`   Level ${level} (Direct): ${count} users`);
      } else {
        console.log(`   Level ${level} (Indirect): ${count} users`);
        totalIndirect += count;
      }
    });
    console.log(`   ${colors.magenta}Total Indirect (Level 2-7): ${totalIndirect}${colors.reset}\n`);

    // Step 5: Summary
    console.log(`${colors.magenta}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}║  SUMMARY                                              ║${colors.reset}`);
    console.log(`${colors.magenta}╚════════════════════════════════════════════════════════╝${colors.reset}`);
    console.log(`   User ID: ${user.id}`);
    console.log(`   ${colors.cyan}Direct Referrals:${colors.reset}`);
    console.log(`     - Total: ${directReferrals.length}`);
    console.log(`     - ${colors.green}With Approved Deposits: ${withApprovedDeposits.length}${colors.reset} ${colors.yellow}← API mein yeh show hona chahiye${colors.reset}`);
    console.log(`     - Without Approved Deposits: ${withoutApprovedDeposits.length}`);
    console.log(`   ${colors.cyan}Indirect Referrals:${colors.reset}`);
    console.log(`     - Total (Level 2-7): ${totalIndirect}`);
    levelCounts.filter(item => parseInt(item.level, 10) > 1).forEach(item => {
      console.log(`     - Level ${item.level}: ${item.count}`);
    });
    console.log('');

    // Step 6: What API currently returns vs what should return
    console.log(`${colors.magenta}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}║  API CURRENT vs EXPECTED BEHAVIOR                      ║${colors.reset}`);
    console.log(`${colors.magenta}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);
    
    console.log(`${colors.yellow}⚠️  Current API Behavior:${colors.reset}`);
    console.log(`   - Returns ${colors.red}ALL ${directReferrals.length} direct referrals${colors.reset} (regardless of deposit status)`);
    console.log(`   - Shows hasApprovedDeposit flag for each\n`);
    
    console.log(`${colors.green}✓ Expected API Behavior:${colors.reset}`);
    console.log(`   - Should return only ${colors.green}${withApprovedDeposits.length} direct referrals${colors.reset} (only those with approved deposits)`);
    console.log(`   - Indirect referrals count should remain the same\n`);

    console.log(`${colors.blue}API Test Instructions:${colors.reset}`);
    console.log(`   1. Login with user credentials`);
    console.log(`   2. Call: GET /api/v1/wallet/referral-tree`);
    console.log(`   3. Check: directReferrals.length should be ${withApprovedDeposits.length} (not ${directReferrals.length})`);
    console.log(`   4. Check: networkSummary should show indirect counts as above\n`);

    await sequelize.close();
    console.log(`${colors.green}✓ Database connection closed${colors.reset}\n`);

    // Return data for API test
    return {
      userId: user.id,
      totalDirect: directReferrals.length,
      withApprovedDeposits: withApprovedDeposits.length,
      withoutApprovedDeposits: withoutApprovedDeposits.length,
      indirectCounts: levelCounts.filter(item => parseInt(item.level, 10) > 1),
      totalIndirect: totalIndirect,
    };

  } catch (error) {
    console.error(`${colors.red}✗ Error: ${error.message}${colors.reset}`);
    console.error(error);
    await sequelize.close();
    process.exit(1);
  }
}

// Run the check
if (require.main === module) {
  checkAPIReferralTree();
}

module.exports = { checkAPIReferralTree };

