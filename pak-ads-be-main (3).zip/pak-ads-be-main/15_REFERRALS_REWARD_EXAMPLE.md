# 💰 Example: User A Gets 15 Referrals

## 🎯 **Scenario**

**User A** ne 15 direct joinings karwayi hain aur **teeno users ke deposits approve hain**.

---

## 💵 **Kitna Balance Add Hoga?**

### **Commission (Per Deposit):**
| Deposit | Commission | Total Commission |
|---------|------------|------------------|
| 1st - 14th | 175 PKR each | **2,450 PKR** |
| 15th | 175 PKR | **175 PKR** |
| **TOTAL** | 15 × 175 | **2,625 PKR** |

### **Rewards:**
| Reward Type | Threshold | Amount | Total |
|-------------|-----------|--------|-------|
| **Rank 1** | 15 referrals | 566 PKR | 566 PKR ✅ |
| **Deposit Reward** | 15 referrals | 566 PKR | 566 PKR ✅ |
| **Daily Bonus** | Depends on today | 0-849 PKR | Variable |

---

## 🎉 **GRAND TOTAL**

### **Fixed Amounts (Always):**
```
Commission:    2,625 PKR
Rank Reward:     566 PKR
Deposit Reward:  566 PKR
────────────────────────
SUBTOTAL:      3,757 PKR ($13.28)
```

### **Plus Daily Bonus (If applicable):**
```
If 3rd referral today:  +283 PKR
If 6th referral today:  +283 PKR  
If 8th referral today:  +283 PKR
```

**Maximum Total (with all bonuses): 4,323 PKR ($15.28)**

---

## ✅ **All Automatic!**

**Jab admin 15th deposit approve kare:**
- ✅ Commission: 175 PKR added
- ✅ Rank 1 Reward: 566 PKR **AUTO ADDED!**
- ✅ Deposit Reward: 566 PKR **AUTO ADDED!**
- ✅ Total: **1,307 PKR ($4.62)** in one approval!

**User ko kuch nahi karna! Sab automatic! 🎊**

---

## 📊 **Simple Answer**

**Question:** 15 referrals par kitna milega?

**Answer:** 
- **Fixed:** 2,625 (commission) + 566 (rank) + 566 (deposit) = **3,757 PKR**
- **Plus:** Daily bonus agar applicable ho

**All automatic! No manual work! 🚀**

