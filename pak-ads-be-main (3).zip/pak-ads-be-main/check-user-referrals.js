/**
 * Check Direct and Indirect Referrals for a Specific User
 * Compares database counts with API response
 */

require('dotenv').config();
const { sequelize } = require('./src/config/database');
const { Op } = require('sequelize');
const User = require('./src/models/User');

// User details to check
const userEmail = 'faisalcomedychanel@gmail.com';
const userPhone = '03497210618';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

async function checkUserReferrals() {
  try {
    console.log(`${colors.cyan}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.cyan}║  User Referral Check                                  ║${colors.reset}`);
    console.log(`${colors.cyan}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    // Step 1: Find the user
    console.log(`${colors.blue}Step 1: Finding user...${colors.reset}`);
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: userEmail },
          { phone: userPhone }
        ]
      },
      attributes: ['id', 'name', 'email', 'phone', 'total_referrals', 'created_at']
    });

    if (!user) {
      console.log(`${colors.red}✗ User not found with email: ${userEmail} or phone: ${userPhone}${colors.reset}\n`);
      process.exit(1);
    }

    console.log(`${colors.green}✓ User found:${colors.reset}`);
    console.log(`   ID: ${user.id}`);
    console.log(`   Name: ${user.name}`);
    console.log(`   Email: ${user.email}`);
    console.log(`   Phone: ${user.phone}`);
    console.log(`   Total Referrals (from DB): ${user.total_referrals}`);
    console.log(`   Created At: ${user.created_at}\n`);

    // Step 2: Count direct referrals (Level 1)
    console.log(`${colors.blue}Step 2: Counting direct referrals (Level 1)...${colors.reset}`);
    const directReferrals = await User.findAll({
      where: { referred_by: user.id },
      attributes: ['id', 'name', 'email', 'created_at', 'total_referrals']
    });

    console.log(`${colors.green}✓ Direct Referrals (Level 1): ${directReferrals.length}${colors.reset}`);
    if (directReferrals.length > 0) {
      console.log(`${colors.cyan}Direct Referral List:${colors.reset}`);
      directReferrals.forEach((ref, index) => {
        console.log(`   ${index + 1}. ID: ${ref.id}, Name: ${ref.name}, Email: ${ref.email}, Created: ${ref.created_at}`);
      });
    }
    console.log('');

    // Step 3: Count referrals at each level using recursive CTE (same as API)
    console.log(`${colors.blue}Step 3: Counting referrals at each level (using recursive CTE like API)...${colors.reset}`);
    const levelCounts = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, 1 as level
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, rt.level + 1
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT level, COUNT(*) as count
      FROM referral_tree
      GROUP BY level
      ORDER BY level;
    `, {
      replacements: { userId: user.id },
      type: sequelize.QueryTypes.SELECT,
    });

    console.log(`${colors.green}✓ Network Summary by Level:${colors.reset}`);
    let totalIndirect = 0;
    levelCounts.forEach(item => {
      const level = parseInt(item.level, 10);
      const count = parseInt(item.count, 10);
      if (level === 1) {
        console.log(`   Level ${level} (Direct): ${count} users ${colors.yellow}[Should match direct referrals count]${colors.reset}`);
      } else {
        console.log(`   Level ${level} (Indirect): ${count} users`);
        totalIndirect += count;
      }
    });
    console.log(`   ${colors.cyan}Total Indirect Referrals (Level 2-7): ${totalIndirect}${colors.reset}`);
    console.log(`   ${colors.cyan}Total All Referrals (Level 1-7): ${levelCounts.reduce((sum, item) => sum + parseInt(item.count, 10), 0)}${colors.reset}\n`);

    // Step 4: Get detailed breakdown by level
    console.log(`${colors.blue}Step 4: Getting detailed breakdown by level...${colors.reset}`);
    const detailedBreakdown = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, name, email, 1 as level
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, u.name, u.email, rt.level + 1
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT level, id, name, email, referred_by
      FROM referral_tree
      ORDER BY level, id;
    `, {
      replacements: { userId: user.id },
      type: sequelize.QueryTypes.SELECT,
    });

    // Group by level
    const byLevel = {};
    detailedBreakdown.forEach(item => {
      const level = parseInt(item.level, 10);
      if (!byLevel[level]) {
        byLevel[level] = [];
      }
      byLevel[level].push({
        id: item.id,
        name: item.name,
        email: item.email,
        referred_by: item.referred_by
      });
    });

    // Display detailed breakdown
    Object.keys(byLevel).sort((a, b) => parseInt(a) - parseInt(b)).forEach(level => {
      const users = byLevel[level];
      console.log(`${colors.cyan}Level ${level} (${users.length} users):${colors.reset}`);
      users.forEach((u, index) => {
        console.log(`   ${index + 1}. ID: ${u.id}, Name: ${u.name || 'N/A'}, Email: ${u.email}, Referred By: ${u.referred_by}`);
      });
      console.log('');
    });

    // Step 5: Summary
    console.log(`${colors.magenta}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}║  SUMMARY                                              ║${colors.reset}`);
    console.log(`${colors.magenta}╚════════════════════════════════════════════════════════╝${colors.reset}`);
    console.log(`   User ID: ${user.id}`);
    console.log(`   Direct Referrals (Level 1): ${colors.green}${directReferrals.length}${colors.reset}`);
    console.log(`   Total Indirect Referrals (Level 2-7): ${colors.green}${totalIndirect}${colors.reset}`);
    console.log(`   Total All Referrals (Level 1-7): ${colors.green}${levelCounts.reduce((sum, item) => sum + parseInt(item.count, 10), 0)}${colors.reset}`);
    console.log(`   DB total_referrals field: ${colors.yellow}${user.total_referrals}${colors.reset}`);
    
    // Validation
    if (directReferrals.length !== parseInt(levelCounts.find(l => l.level === 1)?.count || 0)) {
      console.log(`   ${colors.red}⚠️  WARNING: Direct referrals count mismatch!${colors.reset}`);
      console.log(`      Direct query: ${directReferrals.length}`);
      console.log(`      Recursive CTE Level 1: ${levelCounts.find(l => l.level === 1)?.count || 0}`);
    } else {
      console.log(`   ${colors.green}✓ Direct referrals count matches between queries${colors.reset}`);
    }
    console.log('');

    // Step 6: What API should return
    console.log(`${colors.blue}Expected API Response Structure:${colors.reset}`);
    console.log(`   directReferrals.length: ${colors.green}${directReferrals.length}${colors.reset}`);
    console.log(`   networkSummary:`);
    levelCounts.forEach(item => {
      console.log(`     - Level ${item.level}: ${item.count}`);
    });
    console.log('');

    await sequelize.close();
    console.log(`${colors.green}✓ Database connection closed${colors.reset}\n`);

  } catch (error) {
    console.error(`${colors.red}✗ Error: ${error.message}${colors.reset}`);
    console.error(error);
    await sequelize.close();
    process.exit(1);
  }
}

// Run the check
if (require.main === module) {
  checkUserReferrals();
}

module.exports = { checkUserReferrals };


