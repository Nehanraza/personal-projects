# Ad Watching & Referral System Documentation

## Overview

This document describes the complete Ad Watching and Referral System implemented in the Pak Ads platform. This system allows users to watch ads with specific time-based restrictions and requires them to add new members (referrals) to continue watching ads.

## How It Works

### User Registration
- When a new user registers, they are automatically assigned a unique **referral code** (8-character alphanumeric code)
- Users can optionally provide a referral code during registration to be linked to the user who referred them
- Each user can watch **1 ad per 24 hours** for **7 days**

### Ad Watching Cycle

1. **Day 1-7**: User can watch 1 ad every 24 hours
2. **After 7 days**: User must add a new member to continue watching ads
3. **If member added**: A new 7-day cycle starts immediately from that day
4. **If no member added**: Ad watching access is stopped until a member is added

### Key Rules

- ✅ Users can watch 1 ad every 24 hours
- ✅ The 7-day cycle starts when the user watches their first ad
- ✅ Adding a member before 7 days resets the cycle to start from that day
- ✅ Users cannot watch their own ads
- ❌ After 7 days without adding a member, access is blocked

---

## Database Schema

### Users Table - New Fields

```sql
-- Referral tracking
referred_by INTEGER          -- ID of user who referred this user
referral_code VARCHAR(20)    -- Unique referral code for this user
total_referrals INTEGER      -- Total number of users referred

-- Ad watching tracking
last_ad_watched_at TIMESTAMP -- When user last watched an ad
current_cycle_started_at TIMESTAMP -- When current 7-day cycle started
```

### Ad Views Table (New)

```sql
CREATE TABLE ad_views (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  ad_id INTEGER NOT NULL,
  watched_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
```

---

## API Endpoints

### 1. Register with Referral Code

**Endpoint**: `POST /api/v1/auth/register`

**Request Body**:
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "phone": "+1234567890",
  "referralCode": "ABC12345"  // Optional
}
```

**Response**:
```json
{
  "success": true,
  "token": "jwt_token_here",
  "user": {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "role": "user",
    "referralCode": "XYZ98765",
    "totalReferrals": 0
  }
}
```

---

### 2. Watch an Ad

**Endpoint**: `POST /api/v1/ad-views/:adId/watch`

**Headers**: 
```
Authorization: Bearer <token>
```

**Success Response**:
```json
{
  "success": true,
  "message": "Ad watched successfully",
  "data": {
    "adId": 5,
    "watchedAt": "2025-10-08T10:30:00.000Z",
    "nextAdAvailableAt": "2025-10-09T10:30:00.000Z",
    "adWatchingStatus": {
      "canWatchAd": false,
      "cycleStartDate": "2025-10-01T10:30:00.000Z",
      "lastAdWatchedAt": "2025-10-08T10:30:00.000Z",
      "totalReferrals": 2,
      "referralCode": "XYZ98765",
      "daysRemainingInCycle": 6,
      "daysSinceCycleStart": 1,
      "message": "You can watch your next ad in 24.0 hours.",
      "hoursUntilNextAd": 24.0
    }
  }
}
```

**Error Response - Too Soon**:
```json
{
  "success": false,
  "message": "You can watch your next ad in 18.5 hours.",
  "reason": "too_soon",
  "data": {
    "canWatch": false,
    "reason": "too_soon",
    "message": "You can watch your next ad in 18.5 hours.",
    "hoursRemaining": 18.5
  }
}
```

**Error Response - Cycle Expired**:
```json
{
  "success": false,
  "message": "Your 7-day cycle has expired. Please add a new member to continue watching ads.",
  "reason": "cycle_expired",
  "data": {
    "canWatch": false,
    "reason": "cycle_expired",
    "message": "Your 7-day cycle has expired. Please add a new member to continue watching ads.",
    "daysExpired": 2
  }
}
```

---

### 3. Get Ad Watching Status

**Endpoint**: `GET /api/v1/ad-views/status`

**Headers**: 
```
Authorization: Bearer <token>
```

**Response**:
```json
{
  "success": true,
  "data": {
    "canWatchAd": true,
    "cycleStartDate": "2025-10-01T10:30:00.000Z",
    "lastAdWatchedAt": "2025-10-07T10:30:00.000Z",
    "totalReferrals": 2,
    "referralCode": "XYZ98765",
    "daysRemainingInCycle": 6,
    "daysSinceCycleStart": 1,
    "message": "You can watch an ad now!",
    "referrals": [
      {
        "id": 10,
        "name": "Jane Smith",
        "email": "jane@example.com",
        "createdAt": "2025-10-05T08:00:00.000Z"
      }
    ]
  }
}
```

---

### 4. Get Ad Watching History

**Endpoint**: `GET /api/v1/ad-views/history?page=1&limit=10`

**Headers**: 
```
Authorization: Bearer <token>
```

**Response**:
```json
{
  "success": true,
  "data": {
    "history": [
      {
        "id": 15,
        "user_id": 1,
        "ad_id": 5,
        "watched_at": "2025-10-08T10:30:00.000Z",
        "createdAt": "2025-10-08T10:30:00.000Z",
        "updatedAt": "2025-10-08T10:30:00.000Z",
        "ad": {
          "id": 5,
          "title": "iPhone 13 Pro",
          "slug": "iphone-13-pro",
          "price": "999.00",
          "status": "active",
          "user": {
            "id": 3,
            "name": "Seller Name",
            "email": "seller@example.com"
          }
        }
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 3,
      "totalRecords": 25,
      "limit": 10
    }
  }
}
```

---

### 5. Add a New Member (Referral)

**Endpoint**: `POST /api/v1/ad-views/add-member`

**Headers**: 
```
Authorization: Bearer <token>
```

**Request Body**:
```json
{
  "referralCode": "ABC12345"
}
```

**Response**:
```json
{
  "success": true,
  "message": "Member added successfully! Your 7-day cycle has been reset.",
  "data": {
    "totalReferrals": 3,
    "newCycleStartDate": "2025-10-08T10:30:00.000Z",
    "adWatchingStatus": {
      "canWatchAd": true,
      "cycleStartDate": "2025-10-08T10:30:00.000Z",
      "lastAdWatchedAt": "2025-10-07T09:00:00.000Z",
      "totalReferrals": 3,
      "referralCode": "XYZ98765",
      "daysRemainingInCycle": 7,
      "daysSinceCycleStart": 0,
      "message": "You can watch an ad now!"
    }
  }
}
```

**Error Response**:
```json
{
  "success": false,
  "message": "Invalid referral code"
}
```

---

### 6. Get Referral Information

**Endpoint**: `GET /api/v1/ad-views/referral-info`

**Headers**: 
```
Authorization: Bearer <token>
```

**Response**:
```json
{
  "success": true,
  "data": {
    "referralCode": "XYZ98765",
    "totalReferrals": 3,
    "referrals": [
      {
        "id": 10,
        "name": "Jane Smith",
        "email": "jane@example.com",
        "createdAt": "2025-10-05T08:00:00.000Z"
      },
      {
        "id": 12,
        "name": "Bob Johnson",
        "email": "bob@example.com",
        "createdAt": "2025-10-06T14:30:00.000Z"
      }
    ],
    "referredBy": {
      "id": 2,
      "name": "Alice Brown",
      "email": "alice@example.com"
    }
  }
}
```

---

## User Flow Examples

### Example 1: New User Registration

```
Day 0 (Registration):
- User registers with optional referral code
- Gets assigned unique referral code: "ABC12345"
- Can watch first ad immediately

Day 1:
- User watches first ad
- Cycle starts: current_cycle_started_at = Day 1
- Next ad available in 24 hours

Day 2-7:
- User watches 1 ad per day
- Each ad unlocks after 24 hours

Day 8:
- Cycle expired - cannot watch ads
- Must add a new member to continue
```

### Example 2: Adding Member Before Cycle Expires

```
Day 1: User watches first ad (Cycle starts)
Day 3: User adds a new member
- Cycle resets: current_cycle_started_at = Day 3
- New 7-day cycle starts from Day 3
- Can continue watching ads for 7 more days (until Day 10)
```

### Example 3: Cycle Expired Scenario

```
Day 1: User watches first ad
Day 7: User watches 7th ad
Day 8: Cycle expired
- User tries to watch ad → Error: "Your 7-day cycle has expired"
- User adds new member
- Cycle resets, can watch ads again
```

---

## Business Rules Implementation

### 1. One Ad Per 24 Hours
- Enforced in `User.canWatchAd()` method
- Checks time difference between `last_ad_watched_at` and current time
- Returns error if less than 24 hours

### 2. Seven-Day Cycle
- Tracked via `current_cycle_started_at` field
- Cycle starts when user watches first ad
- After 7 days, user must add member to reset cycle

### 3. Referral System
- Each user gets unique 8-character code on registration
- Users can register with a referral code
- Adding a member increments `total_referrals`
- Adding a member resets the 7-day cycle

### 4. Restrictions
- Users cannot watch their own ads
- Referral codes must be unique
- Users cannot use their own referral code
- Users who are already referred cannot be referred again

---

## Database Migrations

To implement this feature, run the following migrations:

```bash
# Run migrations
npm run db:migrate
```

This will execute:
1. `012_add_referral_and_ad_watching_fields.js` - Adds fields to users table
2. `013_create_ad_views_table.js` - Creates ad_views table

---

## Testing the Feature

### 1. Test User Registration with Referral
```bash
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "password123",
    "referralCode": "ABC12345"
  }'
```

### 2. Test Watching an Ad
```bash
curl -X POST http://localhost:4000/api/v1/ad-views/5/watch \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 3. Test Getting Status
```bash
curl -X GET http://localhost:4000/api/v1/ad-views/status \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 4. Test Adding Member
```bash
curl -X POST http://localhost:4000/api/v1/ad-views/add-member \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "referralCode": "XYZ98765"
  }'
```

---

## Frontend Integration Guidelines

### Display User's Status
```javascript
// Fetch user's ad watching status
const response = await fetch('/api/v1/ad-views/status', {
  headers: {
    'Authorization': `Bearer ${token}`
  }
});

const { data } = await response.json();

// Show appropriate UI based on status
if (data.canWatchAd) {
  // Show "Watch Ad" button
} else if (data.cycleExpired) {
  // Show "Add Member to Continue" message
} else {
  // Show countdown timer for next ad
  // data.hoursUntilNextAd
}
```

### Watch Ad Flow
```javascript
// When user clicks watch ad
const watchAd = async (adId) => {
  const response = await fetch(`/api/v1/ad-views/${adId}/watch`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });

  if (response.ok) {
    // Success - show ad and confirmation
    const { data } = await response.json();
    showNextAdTimer(data.nextAdAvailableAt);
  } else {
    // Handle error (too soon, cycle expired, etc.)
    const error = await response.json();
    showError(error.message);
  }
};
```

### Add Member Flow
```javascript
// When user adds a member
const addMember = async (referralCode) => {
  const response = await fetch('/api/v1/ad-views/add-member', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ referralCode })
  });

  if (response.ok) {
    // Success - cycle reset
    const { data } = await response.json();
    showSuccess('Member added! Your cycle has been reset.');
    updateStatus(data.adWatchingStatus);
  } else {
    // Handle error
    const error = await response.json();
    showError(error.message);
  }
};
```

---

## Security Considerations

1. **Authentication Required**: All ad watching endpoints require valid JWT token
2. **Rate Limiting**: Time-based restrictions prevent abuse
3. **Ownership Checks**: Users cannot watch their own ads
4. **Unique Referral Codes**: Prevents duplicate referrals
5. **Self-Referral Prevention**: Users cannot use their own referral code

---

## Performance Optimization

1. **Database Indexes**: Added on frequently queried fields
   - `users.referred_by`
   - `users.referral_code`
   - `ad_views.user_id`
   - `ad_views.watched_at`

2. **Efficient Queries**: Use specific field selection and joins
3. **Caching Opportunities**: User status can be cached for short periods

---

## Future Enhancements

1. **Email Notifications**: Notify users when cycle is about to expire
2. **Referral Rewards**: Give bonuses for successful referrals
3. **Analytics Dashboard**: Track ad watching patterns
4. **Premium Tiers**: Allow users to watch more ads with premium membership
5. **Social Sharing**: Share referral codes on social media

---

## Troubleshooting

### Issue: User cannot watch ads after registration
**Solution**: Check if `current_cycle_started_at` is null. First ad watch will set this field.

### Issue: Cycle not resetting after adding member
**Solution**: Verify that `current_cycle_started_at` is updated to current timestamp when member is added.

### Issue: Invalid referral code error
**Solution**: Ensure the referral code exists and hasn't been used by another user.

### Issue: User can watch own ads
**Solution**: Check `watchAd` controller - should block if `ad.user_id === userId`.

---

## Support

For any issues or questions, please contact the development team or refer to the main API documentation.

**Last Updated**: October 8, 2025
**Version**: 1.0.0

