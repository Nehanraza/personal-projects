require('dotenv').config();
const { sequelize } = require('./src/config/database');

async function checkTable() {
  try {
    await sequelize.authenticate();
    console.log('Database connected');
    
    const [results] = await sequelize.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name = 'deposit_rewards'
    `);
    
    if (results.length > 0) {
      console.log('✅ deposit_rewards table exists');
    } else {
      console.log('❌ deposit_rewards table does NOT exist');
      console.log('\nRunning migration 030...');
      
      const migration30 = require('./src/database/migrations/030_create_deposit_rewards.js');
      const queryInterface = sequelize.getQueryInterface();
      await migration30.up(queryInterface);
      
      console.log('✅ Migration 030 completed');
      
      console.log('\nRunning migration 031...');
      const migration31 = require('./src/database/migrations/031_add_deposit_reward_earning_type.js');
      await migration31.up(queryInterface, sequelize);
      
      console.log('✅ Migration 031 completed');
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

checkTable();

