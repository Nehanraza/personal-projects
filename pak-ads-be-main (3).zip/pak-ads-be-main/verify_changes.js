const { User, UserPlan, InvestmentPlan, Earning, Deposit } = require('./src/models');
const { distributeDailyROIEarnings } = require('./src/utils/earningService');
const { distributeCommission } = require('./src/utils/commissionService');
const { sequelize } = require('./src/config/database');
const logger = require('./src/config/logger');

async function testROI() {
  console.log('--- Testing ROI Distribution (2 min) ---');
  const transaction = await sequelize.transaction();
  try {
    // 1. Create a user
    const user = await User.create({
      name: 'Test ROI User',
      email: `test_roi_${Date.now()}@example.com`,
      phone: `0300${Math.floor(Math.random() * 10000000)}`,
      password: 'password123',
    }, { transaction });

    // 2. Create a plan
    const plan = await InvestmentPlan.findOne({ transaction });
    if (!plan) throw new Error('No investment plans found in DB');

    // 3. Create a user plan activated 3 minutes ago
    const activatedAt = new Date(Date.now() - 3 * 60 * 1000); // 3 mins ago
    const userPlan = await UserPlan.create({
      user_id: user.id,
      plan_id: plan.id,
      status: 'active',
      investment_amount: plan.investment_amount,
      daily_profit: plan.daily_profit,
      max_return: plan.total_return,
      activated_at: activatedAt,
      last_earning_at: activatedAt,
    }, { transaction });

    await transaction.commit();
    console.log(`Created user ${user.id} with plan activated at ${activatedAt}`);

    // 4. Run distribution
    console.log('Running distributeDailyROIEarnings...');
    const result = await distributeDailyROIEarnings();
    console.log('Distribution Result:', result);

    // 5. Verify
    const updatedUser = await User.findByPk(user.id);
    const earnings = await Earning.findAll({ where: { user_id: user.id, type: 'roi_daily_profit' } });
    
    if (earnings.length > 0) {
      console.log('✅ ROI distribution successful!');
      console.log('Earning Amount:', earnings[0].amount);
      console.log('User New Balance:', updatedUser.wallet_balance);
    } else {
      console.log('❌ ROI distribution failed!');
    }
  } catch (error) {
    await transaction.rollback();
    console.error('ROI Test Error:', error);
  }
}

async function testReferralRule() {
  console.log('\n--- Testing Referral Plan-Tier Rule ---');
  const transaction = await sequelize.transaction();
  try {
    // 1. User A (Referrer) with low-tier plan
    const userA = await User.create({
      name: 'Referrer A (Low Plan)',
      email: `referrer_a_${Date.now()}@example.com`,
      phone: `0310${Math.floor(Math.random() * 10000000)}`,
      password: 'password123',
    }, { transaction });

    // Assuming plan ID 1 is $10 and plan ID 2 is $50 (adjust based on your seeders)
    const plans = await InvestmentPlan.findAll({ order: [['investment_amount', 'ASC']], transaction });
    if (plans.length < 2) throw new Error('At least 2 plans needed for this test');
    
    const lowPlan = plans[0];
    const highPlan = plans[1];

    await UserPlan.create({
      user_id: userA.id,
      plan_id: lowPlan.id,
      status: 'active',
      investment_amount: lowPlan.investment_amount,
      daily_profit: lowPlan.daily_profit,
      max_return: lowPlan.total_return,
    }, { transaction });
    
    // Give User A an approved deposit to pass the initial guard
    await Deposit.create({
        user_id: userA.id,
        amount: lowPlan.investment_amount,
        status: 'approved',
        transaction_id: `TXN_${Date.now()}_A`,
    }, { transaction });

    // 2. User B (Downline) with high-tier plan
    const userB = await User.create({
      name: 'Downline B (High Plan)',
      email: `downline_b_${Date.now()}@example.com`,
      phone: `0320${Math.floor(Math.random() * 10000000)}`,
      password: 'password123',
      referred_by: userA.id,
    }, { transaction });

    await UserPlan.create({
      user_id: userB.id,
      plan_id: highPlan.id,
      status: 'active',
      investment_amount: highPlan.investment_amount,
      daily_profit: highPlan.daily_profit,
      max_return: highPlan.total_return,
    }, { transaction });

    await transaction.commit();
    console.log(`Referrer A (Plan ${lowPlan.investment_amount}) referred B (Plan ${highPlan.investment_amount})`);

    // 3. Trigger commission for User B
    console.log('Distributing ad watching commission for User B...');
    const result = await distributeCommission(userB.id, 5, 'ad_watching', 'fixed');
    console.log('Commission Result:', result);

    // 4. Verify User A got NOTHING
    const earningsA = await Earning.findAll({ where: { user_id: userA.id, from_user_id: userB.id } });
    if (earningsA.length === 0) {
      console.log('✅ Referral rule enforced! Referrer got no commission as expected.');
    } else {
      console.log('❌ Referral rule violation! Referrer received commission.');
    }

    // 5. Upgrade User A to High Plan and try again
    const transaction2 = await sequelize.transaction();
    await UserPlan.update({ investment_amount: highPlan.investment_amount }, { where: { user_id: userA.id }, transaction: transaction2 });
    await transaction2.commit();
    
    console.log(`Upgraded Referrer A to Plan ${highPlan.investment_amount}. Trying again...`);
    const result2 = await distributeCommission(userB.id, 5, 'ad_watching', 'fixed');
    
    const earningsA2 = await Earning.findAll({ where: { user_id: userA.id, from_user_id: userB.id } });
    if (earningsA2.length > 0) {
      console.log('✅ Referral rule verified! Referrer now receives commission.');
    } else {
      console.log('❌ Referral rule failed! Referrer still gets nothing.');
    }

  } catch (error) {
    if (transaction.finished !== 'rollback') await transaction.rollback();
    console.error('Referral Test Error:', error);
  }
}

async function runTests() {
  try {
    // Run tests sequentially
    await testROI();
    await testReferralRule();
    console.log('\n--- All Tests Completed ---');
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

runTests();
