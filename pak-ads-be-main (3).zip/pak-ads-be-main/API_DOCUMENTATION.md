# Pak Ads API Documentation

Complete API reference for the Pak Ads classified ads platform.

## Base URL

```
http://localhost:4000/api/v1
```

## Authentication

Most endpoints require JWT authentication. Include the token in the Authorization header:

```
Authorization: Bearer YOUR_JWT_TOKEN
```

---

## Authentication Endpoints

### Get Joining Fee Information
```http
GET /auth/joining-fee-info
```

Get information about the joining fee, currency exchange rate, and commission structure.

**Response:**
```json
{
  "success": true,
  "data": {
    "joiningFee": {
      "amountPKR": 650,
      "amountUSD": 2.3
    },
    "currencyRate": {
      "usdToPkr": 283,
      "description": "1 USD = 283 PKR"
    },
    "commissionStructure": {
      "1": 22,
      "2": 9,
      "3": 7,
      "4": 5,
      "5": 4,
      "6": 3,
      "7": 2
    }
  }
}
```

### Register User
```http
POST /auth/register
```

**⚠️ Note:** Registration requires a joining fee of **650 PKR ($2.30)**. The `joiningFeePaid` field must be set to `true`.

**🔐 NEW:** Email verification with OTP is now required. After registration, user receives a 6-digit OTP via email.

**Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "phone": "+92-300-1234567",
  "referralCode": "ABC12345",
  "joiningFeePaid": true
}
```

**Success Response:**
```json
{
  "success": true,
  "message": "Registration successful! Please check your email for verification code.",
  "data": {
    "user": {
      "id": 1,
      "name": "John Doe",
      "email": "john@example.com",
      "role": "user",
      "referralCode": "ABC123XY",
      "isEmailVerified": false
    }
  },
  "requiresVerification": true
}
```

**Error Response (No Joining Fee):**
```json
{
  "success": false,
  "message": "Registration requires a joining fee of 650 PKR ($2.3)",
  "joiningFee": {
    "amountPKR": 650,
    "amountUSD": 2.3
  }
}
```

### Verify Email with OTP
```http
POST /auth/verify-email
```

**🔐 NEW:** Verify email address using the OTP sent during registration.

**Body:**
```json
{
  "email": "john@example.com",
  "otp": "123456"
}
```

**Success Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "role": "user",
    "referralCode": "ABC123XY"
  }
}
```

**Error Responses:**
```json
// Invalid OTP
{
  "success": false,
  "message": "Invalid OTP code"
}

// Expired OTP
{
  "success": false,
  "message": "OTP has expired. Please request a new one.",
  "expired": true
}
```

### Resend OTP
```http
POST /auth/resend-otp
```

**🔐 NEW:** Request a new OTP if the previous one expired.

**Body:**
```json
{
  "email": "john@example.com"
}
```

**Success Response:**
```json
{
  "success": true,
  "message": "Verification code sent to your email"
}
```

### Login
```http
POST /auth/login
```

**🔐 UPDATED:** Now checks if email is verified before allowing login.

**Body:**
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**Success Response (Verified User):**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {...}
}
```

**Error Response (Unverified User):**
```json
{
  "success": false,
  "message": "Please verify your email before logging in",
  "requiresVerification": true,
  "email": "john@example.com"
}
```

### Forgot Password
```http
POST /auth/forgotpassword
```

**🔐 UPDATED:** Now sends OTP to email for password reset.

**Body:**
```json
{
  "email": "john@example.com"
}
```

**Success Response:**
```json
{
  "success": true,
  "message": "Password reset code sent to your email"
}
```

### Reset Password
```http
POST /auth/reset-password
```

**🔐 NEW:** Reset password using OTP received via email.

**Body:**
```json
{
  "email": "john@example.com",
  "otp": "123456",
  "newPassword": "newpassword123"
}
```

**Success Response:**
```json
{
  "success": true,
  "message": "Password reset successful. You can now login with your new password."
}
```

### Get Current User
```http
GET /auth/me
```
🔒 **Requires Authentication**

### Update User Details
```http
PUT /auth/updatedetails
```
🔒 **Requires Authentication**

**Body:**
```json
{
  "name": "John Updated",
  "phone": "+92-300-9999999"
}
```

### Update Password
```http
PUT /auth/updatepassword
```
🔒 **Requires Authentication**

**Body:**
```json
{
  "currentPassword": "password123",
  "newPassword": "newpassword456"
}
```

---

## Category Endpoints

### Get All Categories
```http
GET /categories?parent_id=null&search=electronics&is_active=true&page=1&limit=50
```

**Query Parameters:**
- `parent_id` - Filter by parent category (use "null" for top-level categories)
- `search` - Search in category name
- `is_active` - Filter active/inactive categories
- `page` - Page number
- `limit` - Items per page

### Get Category Tree
```http
GET /categories/tree
```

Returns hierarchical category structure with subcategories.

### Get Single Category
```http
GET /categories/:id
```

### Create Category
```http
POST /categories
```
🔒 **Requires Admin**

**Body:**
```json
{
  "name": "Electronics",
  "slug": "electronics",
  "description": "Electronic devices",
  "icon": "📱",
  "parent_id": null,
  "is_active": true,
  "display_order": 1
}
```

### Update Category
```http
PUT /categories/:id
```
🔒 **Requires Admin**

### Delete Category
```http
DELETE /categories/:id
```
🔒 **Requires Admin**

---

## Location Endpoints

### Get All Locations
```http
GET /locations?type=city&parent_id=1&search=lahore&page=1&limit=100
```

**Query Parameters:**
- `type` - Filter by type (country, province, city, area)
- `parent_id` - Filter by parent location
- `search` - Search in location name
- `is_active` - Filter active/inactive
- `page` - Page number
- `limit` - Items per page

### Get Location Tree
```http
GET /locations/tree
```

Returns hierarchical location structure.

### Get Single Location
```http
GET /locations/:id
```

### Create Location
```http
POST /locations
```
🔒 **Requires Admin**

**Body:**
```json
{
  "name": "Lahore",
  "slug": "lahore",
  "type": "city",
  "parent_id": 1,
  "latitude": 31.5204,
  "longitude": 74.3587,
  "is_active": true,
  "display_order": 1
}
```

### Update Location
```http
PUT /locations/:id
```
🔒 **Requires Admin**

### Delete Location
```http
DELETE /locations/:id
```
🔒 **Requires Admin**

---

## Ad Endpoints

### Get All Ads
```http
GET /ads?status=active&category_id=1&location_id=5&user_id=2&is_featured=true&search=iphone&min_price=10000&max_price=50000&condition=new&page=1&limit=10
```

**Query Parameters:**
- `status` - Filter by status (pending, active, sold, expired, rejected)
- `category_id` - Filter by category
- `location_id` - Filter by location
- `user_id` - Filter by user (get user's ads)
- `is_featured` - Filter featured ads
- `search` - Search in title and description
- `min_price` - Minimum price
- `max_price` - Maximum price
- `condition` - Filter by condition (new, used, refurbished)
- `page` - Page number
- `limit` - Items per page

### Get Single Ad
```http
GET /ads/:id
```

Increments view count automatically.

### Create Ad
```http
POST /ads
```
🔒 **Requires Authentication**

**Body:**
```json
{
  "title": "iPhone 13 Pro Max",
  "slug": "iphone-13-pro-max-256gb",
  "description": "Brand new iPhone 13 Pro Max with 256GB storage",
  "price": 45000,
  "is_negotiable": true,
  "condition": "new",
  "category_id": 1,
  "location_id": 5,
  "address": "DHA Phase 5, Lahore",
  "phone": "+92-300-1234567",
  "email": "seller@example.com",
  "images": [
    {
      "image_url": "https://example.com/image1.jpg",
      "thumbnail_url": "https://example.com/thumb1.jpg"
    }
  ]
}
```

### Update Ad
```http
PUT /ads/:id
```
🔒 **Requires Authentication** (Owner or Admin)

### Delete Ad
```http
DELETE /ads/:id
```
🔒 **Requires Authentication** (Owner or Admin)

### Approve Ad
```http
PUT /ads/:id/approve
```
🔒 **Requires Admin**

### Reject Ad
```http
PUT /ads/:id/reject
```
🔒 **Requires Admin**

**Body:**
```json
{
  "rejection_reason": "Inappropriate content"
}
```

### Feature Ad
```http
PUT /ads/:id/feature
```
🔒 **Requires Admin**

**Body:**
```json
{
  "days": 7
}
```

### Get Ad Statistics
```http
GET /ads/admin/stats
```
🔒 **Requires Admin**

Returns statistics about total, featured, active, and pending ads.

---

## Package Endpoints

### Get All Packages
```http
GET /packages?is_active=true&search=premium
```

### Get Single Package
```http
GET /packages/:id
```

### Create Package
```http
POST /packages
```
🔒 **Requires Admin**

**Body:**
```json
{
  "name": "Premium",
  "slug": "premium",
  "description": "Featured listing with maximum exposure",
  "price": 999,
  "duration_days": 60,
  "ads_limit": 25,
  "images_limit": 10,
  "is_featured": true,
  "featured_days": 7,
  "priority": 2,
  "is_active": true,
  "display_order": 3
}
```

### Update Package
```http
PUT /packages/:id
```
🔒 **Requires Admin**

### Delete Package
```http
DELETE /packages/:id
```
🔒 **Requires Admin**

---

## Review Endpoints

### Get All Reviews
```http
GET /reviews?ad_id=1&seller_id=2&user_id=3&is_approved=true&page=1&limit=20
```

**Query Parameters:**
- `ad_id` - Filter by ad
- `seller_id` - Filter by seller
- `user_id` - Filter by reviewer
- `is_approved` - Filter approved reviews
- `page` - Page number
- `limit` - Items per page

### Get Single Review
```http
GET /reviews/:id
```

### Create Review
```http
POST /reviews
```
🔒 **Requires Authentication**

**Body:**
```json
{
  "ad_id": 1,
  "rating": 5,
  "comment": "Great seller, excellent product!"
}
```

### Update Review
```http
PUT /reviews/:id
```
🔒 **Requires Authentication** (Owner or Admin)

### Delete Review
```http
DELETE /reviews/:id
```
🔒 **Requires Authentication** (Owner or Admin)

### Approve Review
```http
PUT /reviews/:id/approve
```
🔒 **Requires Admin**

---

## Message Endpoints

### Get All Messages
```http
GET /messages?ad_id=1&page=1&limit=50
```
🔒 **Requires Authentication**

Returns messages sent to or received by the authenticated user.

### Get Conversation
```http
GET /messages/conversation/:adId/:userId
```
🔒 **Requires Authentication**

Get all messages between the authenticated user and another user about a specific ad.

### Send Message
```http
POST /messages
```
🔒 **Requires Authentication**

**Body:**
```json
{
  "ad_id": 1,
  "receiver_id": 5,
  "message": "Is this item still available?"
}
```

### Mark Message as Read
```http
PUT /messages/:id/read
```
🔒 **Requires Authentication**

### Get Unread Count
```http
GET /messages/unread/count
```
🔒 **Requires Authentication**

Returns the number of unread messages for the authenticated user.

### Delete Message
```http
DELETE /messages/:id
```
🔒 **Requires Authentication**

---

## Report Endpoints

### Get All Reports
```http
GET /reports?status=pending&reason=spam&ad_id=1&page=1&limit=20
```
🔒 **Requires Admin**

**Query Parameters:**
- `status` - Filter by status (pending, reviewed, action_taken, dismissed)
- `reason` - Filter by reason (spam, inappropriate, fraud, duplicate, wrong_category, other)
- `ad_id` - Filter by ad
- `page` - Page number
- `limit` - Items per page

### Get Single Report
```http
GET /reports/:id
```
🔒 **Requires Admin**

### Create Report
```http
POST /reports
```
🔒 **Requires Authentication**

**Body:**
```json
{
  "ad_id": 1,
  "reason": "spam",
  "description": "This ad is spam"
}
```

### Update Report Status
```http
PUT /reports/:id/status
```
🔒 **Requires Admin**

**Body:**
```json
{
  "status": "action_taken",
  "admin_notes": "Ad has been removed"
}
```

### Delete Report
```http
DELETE /reports/:id
```
🔒 **Requires Admin**

### Get Report Statistics
```http
GET /reports/stats
```
🔒 **Requires Admin**

Returns statistics about reports by status and reason.

---

## User Endpoints

### Get All Users
```http
GET /users?page=1&limit=10&search=john
```
🔒 **Requires Admin**

**Query Parameters:**
- `page` - Page number
- `limit` - Items per page
- `search` - Search in name and email

### Get Single User
```http
GET /users/:id
```
🔒 **Requires Authentication**

### Update User
```http
PUT /users/:id
```
🔒 **Requires Authentication** (Owner or Admin)

**Body:**
```json
{
  "name": "Updated Name",
  "phone": "+92-300-9999999",
  "role": "admin",
  "is_active": true
}
```

### Delete User
```http
DELETE /users/:id
```
🔒 **Requires Authentication** (Owner or Admin)

---

## Dashboard Endpoints

### Get Financial Dashboard
```http
GET /dashboard/financial
```
🔒 **Requires Authentication**

Get comprehensive financial information for dashboard display including current balance, total withdrawals, reward earnings, and ad earnings.

**Response:**
```json
{
  "success": true,
  "data": {
    "currentBalance": {
      "pkr": 2500.00,
      "usd": 8.83
    },
    "totalWithdrawal": {
      "pkr": 500.00,
      "usd": 1.77
    },
    "rewardEarning": {
      "pkr": 1200.00,
      "usd": 4.24
    },
    "totalAdsEarning": {
      "pkr": 300.00,
      "usd": 1.06
    },
    "totalEarnings": {
      "pkr": 3000.00,
      "usd": 10.60
    },
    "pendingEarnings": {
      "pkr": 150.00,
      "usd": 0.53
    },
    "earningsByType": [
      {
        "type": "referral_commission",
        "total": {
          "pkr": 800.00,
          "usd": 2.83
        },
        "count": 20
      },
      {
        "type": "lucky_draw_win",
        "total": {
          "pkr": 400.00,
          "usd": 1.41
        },
        "count": 5
      }
    ],
    "totalReferrals": 10,
    "currencyRate": {
      "usdToPkr": 283
    }
  }
}
```

---

## Wallet & Earnings Endpoints

### Get Wallet Balance
```http
GET /wallet/balance
```
🔒 **Requires Authentication**

Get the current user's wallet balance and earnings summary.

**Response:**
```json
{
  "success": true,
  "data": {
    "walletBalance": 2500.00,
    "walletBalanceUSD": 8.83,
    "totalEarnings": 3000.00,
    "totalEarningsUSD": 10.60,
    "totalWithdrawn": 500.00,
    "totalWithdrawnUSD": 1.77,
    "totalReferrals": 10,
    "availableBalance": 2500.00,
    "availableBalanceUSD": 8.83,
    "currencyRate": {
      "usdToPkr": 283
    }
  }
}
```

### Get Earnings History
```http
GET /wallet/earnings?page=1&limit=10
```
🔒 **Requires Authentication**

Get paginated list of all earnings (commissions, bonuses, etc.).

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)

**Response:**
```json
{
  "success": true,
  "data": {
    "earnings": [
      {
        "id": 123,
        "amount": 22.00,
        "level": 1,
        "type": "referral_commission",
        "description": "Commission from level 1 referral",
        "status": "completed",
        "fromUser": {
          "id": 45,
          "name": "John Doe",
          "email": "john@example.com"
        },
        "createdAt": "2025-10-13T10:30:00.000Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 5,
      "totalRecords": 50,
      "limit": 10
    }
  }
}
```

### Get Earnings Summary
```http
GET /wallet/earnings-summary
```
🔒 **Requires Authentication**

Get summary of earnings grouped by level and type.

**Response:**
```json
{
  "success": true,
  "data": {
    "summary": {
      "walletBalance": 2500.00,
      "totalEarnings": 3000.00,
      "totalWithdrawn": 500.00,
      "totalReferrals": 10
    },
    "earningsByLevel": [
      {
        "level": 1,
        "count": 5,
        "total": 110.00
      }
    ],
    "earningsByType": [
      {
        "type": "referral_commission",
        "count": 25,
        "total": 500.00
      }
    ]
  }
}
```

### Get Earnings by Level
```http
GET /wallet/earnings-by-level/:level?page=1&limit=10
```
🔒 **Requires Authentication**

Get earnings from a specific referral level (1-7).

**Path Parameters:**
- `level` - Referral level (1-7)

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)

**Response:**
```json
{
  "success": true,
  "data": {
    "level": 1,
    "totalEarnings": 110.00,
    "totalCount": 5,
    "earnings": [
      {
        "id": 123,
        "amount": 22.00,
        "description": "Commission from level 1 referral",
        "fromUser": {
          "id": 45,
          "name": "John Doe",
          "email": "john@example.com"
        },
        "createdAt": "2025-10-13T10:30:00.000Z"
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalRecords": 5,
      "limit": 10
    }
  }
}
```

### Get Referral Tree
```http
GET /wallet/referral-tree
```
🔒 **Requires Authentication**

Get the user's referral network tree showing direct referrals and network summary.

**Response:**
```json
{
  "success": true,
  "data": {
    "directReferrals": [
      {
        "id": 45,
        "name": "John Doe",
        "email": "john@example.com",
        "joinedAt": "2025-10-13T10:30:00.000Z",
        "totalReferrals": 3,
        "earnedFromThis": 22.00
      }
    ],
    "networkSummary": [
      {
        "level": 1,
        "count": 5
      },
      {
        "level": 2,
        "count": 15
      }
    ]
  }
}
```

### Get Available Payment Methods
```http
GET /wallet/payment-methods
```
🔒 **Requires Authentication**

Get list of available payment methods for withdrawal along with minimum withdrawal requirements.

**Response:**
```json
{
  "success": true,
  "data": {
    "paymentMethods": [
      {
        "id": 1,
        "name": "Easypaisa",
        "slug": "easypaisa",
        "active": true
      },
      {
        "id": 2,
        "name": "Jazzcash",
        "slug": "jazzcash",
        "active": true
      },
      {
        "id": 3,
        "name": "Upaisa",
        "slug": "upaisa",
        "active": true
      },
      {
        "id": 4,
        "name": "Rast payment",
        "slug": "rast_payment",
        "active": true
      },
      {
        "id": 5,
        "name": "Sada pay",
        "slug": "sada_pay",
        "active": true
      },
      {
        "id": 6,
        "name": "Naya pay",
        "slug": "naya_pay",
        "active": true
      },
      {
        "id": 7,
        "name": "First pay",
        "slug": "first_pay",
        "active": true
      },
      {
        "id": 8,
        "name": "Alfa pay",
        "slug": "alfa_pay",
        "active": true
      },
      {
        "id": 9,
        "name": "Pay max",
        "slug": "pay_max",
        "active": true
      }
    ],
    "minimumWithdrawal": {
      "pkr": 283,
      "usd": 1
    },
    "currencyRate": {
      "usdToPkr": 283
    }
  }
}
```

### Request Withdrawal
```http
POST /wallet/withdraw
```
🔒 **Requires Authentication**

Request a withdrawal from wallet balance. Minimum withdrawal amount is 283 PKR ($1 USD).

**Body:**
```json
{
  "amount": 500,
  "paymentMethod": "JazzCash",
  "accountDetails": "03001234567"
}
```

**Parameters:**
- `amount` (required) - Withdrawal amount in PKR (minimum: 283)
- `paymentMethod` (optional) - Payment method (e.g., JazzCash, EasyPaisa, Bank Transfer)
- `accountDetails` (optional) - Account details for payment

**Success Response (200 OK):**
```json
{
  "success": true,
  "message": "Withdrawal request submitted successfully. It will be processed within 24-48 hours.",
  "data": {
    "withdrawalId": 123,
    "amount": 500,
    "amountUSD": 1.77,
    "status": "pending",
    "remainingBalance": {
      "pkr": 2000.00,
      "usd": 7.07
    },
    "totalWithdrawn": {
      "pkr": 500.00,
      "usd": 1.77
    }
  }
}
```

**Error Response - Insufficient Amount (400 Bad Request):**
```json
{
  "success": false,
  "message": "Insufficient amount. Minimum withdrawal amount is 283 PKR ($1)",
  "minimumAmount": {
    "pkr": 283,
    "usd": 1
  }
}
```

**Error Response - Insufficient Balance (400 Bad Request):**
```json
{
  "success": false,
  "message": "Insufficient wallet balance",
  "availableBalance": {
    "pkr": 250.00,
    "usd": 0.88
  },
  "requestedAmount": {
    "pkr": 500.00,
    "usd": 1.77
  }
}
```

### Get Withdrawal History
```http
GET /wallet/withdrawals?page=1&limit=10
```
🔒 **Requires Authentication**

Get paginated list of all withdrawal requests.

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10)

**Response:**
```json
{
  "success": true,
  "data": {
    "withdrawals": [
      {
        "id": 123,
        "amount": 500.00,
        "amountUSD": 1.77,
        "status": "pending",
        "description": "Withdrawal request: 500 PKR via JazzCash",
        "createdAt": "2025-10-13T10:30:00.000Z",
        "metadata": {
          "paymentMethod": "JazzCash",
          "accountDetails": "03001234567",
          "requestedAt": "2025-10-13T10:30:00.000Z"
        }
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 5,
      "totalRecords": 50,
      "limit": 10
    }
  }
}
```

---

## Response Format

### Success Response
```json
{
  "success": true,
  "data": { /* response data */ }
}
```

### Success with Pagination
```json
{
  "success": true,
  "count": 10,
  "total": 50,
  "page": 1,
  "pages": 5,
  "data": [ /* array of items */ ]
}
```

### Error Response
```json
{
  "success": false,
  "error": "Error message here"
}
```

### Validation Error
```json
{
  "success": false,
  "errors": [
    {
      "field": "email",
      "message": "Please provide a valid email"
    }
  ]
}
```

---

## Status Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Request successful |
| 201 | Created - Resource created successfully |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Not authenticated |
| 403 | Forbidden - Not authorized |
| 404 | Not Found - Resource not found |
| 500 | Server Error - Internal server error |

---

## Rate Limiting

- **Rate Limit**: 100 requests per 15 minutes per IP address
- Applies to all `/api/v1` endpoints

---

## Database Models

### User
- id, name, email, password, role, phone, avatar
- is_active, is_email_verified
- created_at, updated_at

### Category
- id, name, slug, description, icon, image
- parent_id (self-referential)
- is_active, display_order
- created_at, updated_at

### Location
- id, name, slug, type (country/province/city/area)
- parent_id (self-referential)
- latitude, longitude
- is_active, display_order
- created_at, updated_at

### Ad
- id, title, slug, description
- price, is_negotiable, condition
- user_id, category_id, location_id
- address, phone, email
- status, is_featured, featured_until
- views_count, favorites_count
- expires_at, rejection_reason
- created_at, updated_at

### AdImage
- id, ad_id, image_url, thumbnail_url
- is_primary, display_order
- created_at, updated_at

### Package
- id, name, slug, description, price
- duration_days, ads_limit, images_limit
- is_featured, featured_days, priority
- is_active, display_order
- created_at, updated_at

### Review
- id, ad_id, user_id, seller_id
- rating (1-5), comment
- is_approved
- created_at, updated_at

### Message
- id, ad_id, sender_id, receiver_id
- message, is_read, read_at
- created_at, updated_at

### Report
- id, ad_id, reporter_id
- reason, description, status
- admin_notes, reviewed_by, reviewed_at
- created_at, updated_at

---

## Relationships

- **User** has many Ads
- **Category** has many Ads, has many Subcategories
- **Location** has many Ads, has many Sublocations
- **Ad** belongs to User, Category, Location
- **Ad** has many AdImages, Reviews, Messages, Reports
- **Review** belongs to Ad, User (reviewer), User (seller)
- **Message** belongs to Ad, User (sender), User (receiver)
- **Report** belongs to Ad, User (reporter), User (reviewer)

---

## Testing with cURL

### Example: Create an Ad

```bash
# 1. Login
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@pakads.com","password":"admin123"}'

# Save the token from response

# 2. Create Ad
curl -X POST http://localhost:4000/api/v1/ads \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "title": "iPhone 13 Pro",
    "slug": "iphone-13-pro",
    "description": "Excellent condition",
    "price": 120000,
    "category_id": 1,
    "location_id": 1
  }'
```

---

## Need Help?

- **Setup Guide**: See `SETUP_GUIDE.md`
- **Quick Reference**: See `QUICK_REFERENCE.md`
- **Project Summary**: See `PROJECT_SUMMARY.md`

---

**Last Updated**: October 2024  
**API Version**: v1

