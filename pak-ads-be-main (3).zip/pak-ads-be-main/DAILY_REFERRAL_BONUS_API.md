# Daily Referral Bonus API Documentation

## ✅ Feature Complete

A daily referral bonus system where users earn $1 (283 PKR) for every 3 members they refer in a single day.

## 🎯 Bonus Rules

### How It Works:
1. **First Bonus**: After referring **3 members** in a single day → Get **$1 (283 PKR)**
2. **Second Bonus**: After referring **6 members** in a single day → Get another **$1 (283 PKR)**
3. **Third Bonus**: After referring **8 members** in a single day → Get another **$1 (283 PKR)**
4. **Maximum**: Only **8 referrals** are counted for bonus (9+ referrals get no additional bonus)

### Examples:
- **3 referrals in a day** → 1 bonus = $1 (283 PKR)
- **6 referrals in a day** → 2 bonuses = $2 (566 PKR)
- **8 referrals in a day** → 3 bonuses = $3 (849 PKR)
- **9+ referrals in a day** → Still only 3 bonuses = $3 (849 PKR) - No additional bonus

## 📡 API Endpoints

### 1. Check and Award Daily Bonus
```http
POST /api/daily-referral-bonus/check
```
🔒 **Requires Authentication**

Checks today's referrals and awards bonuses if applicable.

**Response Examples:**

**No Referrals Today:**
```json
{
  "success": true,
  "message": "No referrals made today",
  "data": {
    "todayReferrals": 0,
    "bonusEarned": 0,
    "bonusAmount": 0
  }
}
```

**Not Enough Referrals (e.g., 2 referrals):**
```json
{
  "success": true,
  "message": "You have 2 referrals today. You need 1 more referrals to get your first bonus!",
  "data": {
    "todayReferrals": 2,
    "bonusEarned": 0,
    "bonusAmount": 0,
    "nextThreshold": 1
  }
}
```

**Bonus Awarded (e.g., 8 referrals):**
```json
{
  "success": true,
  "message": "Congratulations! You earned 3 daily referral bonus(es) worth 849 PKR!",
  "data": {
    "todayReferrals": 8,
    "bonusEarned": 3,
    "bonusAmount": {
      "pkr": 849,
      "usd": 3.00
    },
    "bonusBreakdown": [
      {
        "threshold": 3,
        "bonusCount": 1,
        "bonusAmount": 283,
        "description": "First bonus for 3 referrals"
      },
      {
        "threshold": 6,
        "bonusCount": 1,
        "bonusAmount": 283,
        "description": "Second bonus for 6 referrals"
      },
      {
        "threshold": 8,
        "bonusCount": 1,
        "bonusAmount": 283,
        "description": "Third bonus for 8 referrals"
      }
    ],
    "remainingBalance": {
      "pkr": 2500,
      "usd": 8.83
    },
    "earningId": 123
  }
}
```

**Already Awarded Today:**
```json
{
  "success": true,
  "message": "Daily bonus already awarded for today",
  "data": {
    "todayReferrals": 5,
    "bonusEarned": 2,
    "bonusAmount": 566,
    "alreadyAwarded": true
  }
}
```

### 2. Get Today's Referral Status
```http
GET /api/daily-referral-bonus/status
```
🔒 **Requires Authentication**

Get current status without awarding bonuses.

**Response:**
```json
{
  "success": true,
  "data": {
    "todayReferrals": 4,
    "bonusAwarded": false,
    "bonusAwardedCount": 0,
    "bonusAwardedAmount": null,
    "potentialBonus": {
      "count": 1,
      "amount": {
        "pkr": 283,
        "usd": 1.00
      },
      "breakdown": [
        {
          "threshold": 3,
          "bonusCount": 1,
          "bonusAmount": 283,
          "description": "First bonus for 3 referrals"
        }
      ]
    },
    "progress": {
      "toNextBonus": 75.0,
      "referralsNeeded": 1
    },
    "bonusRules": {
      "firstBonusThreshold": 3,
      "subsequentBonusThreshold": 2,
      "bonusAmount": {
        "pkr": 283,
        "usd": 1
      }
    }
  }
}
```

### 3. Get Daily Bonus History
```http
GET /api/daily-referral-bonus/history?page=1&limit=10
```
🔒 **Requires Authentication**

Get paginated history of daily bonuses earned.

**Response:**
```json
{
  "success": true,
  "data": {
    "bonuses": [
      {
        "id": 1,
        "bonusDate": "2025-10-13",
        "referralsCount": 7,
        "bonusCount": 3,
        "bonusAmount": {
          "pkr": 849,
          "usd": 3.00
        },
        "earning": {
          "id": 123,
          "amount": 849,
          "description": "Daily referral bonus: 3 bonus(es) for 7 referrals on Mon Oct 13 2025",
          "createdAt": "2025-10-13T10:30:00.000Z"
        },
        "createdAt": "2025-10-13T10:30:00.000Z"
      }
    ],
    "summary": {
      "totalBonuses": 15,
      "totalBonusAmount": {
        "pkr": 4245,
        "usd": 15.00
      }
    },
    "pagination": {
      "currentPage": 1,
      "totalPages": 3,
      "totalRecords": 25,
      "limit": 10
    }
  }
}
```

## 🔧 Technical Implementation

### Files Created/Modified:

#### 1. `src/config/constants.js`
Added daily referral bonus configuration:
```javascript
DAILY_REFERRAL_BONUS: {
  FIRST_BONUS_THRESHOLD: 3,        // First bonus after 3 referrals
  SUBSEQUENT_BONUS_THRESHOLD: 2,   // Additional bonuses every 2 referrals
  BONUS_AMOUNT_USD: 1,             // $1 per bonus
  BONUS_AMOUNT_PKR: 283,           // 283 PKR per bonus (1 USD)
}
```

#### 2. `src/models/DailyReferralBonus.js`
New model to track daily bonuses with fields:
- `user_id` - User who earned the bonus
- `bonus_date` - Date when bonus was earned
- `referrals_count` - Number of referrals made that day
- `bonus_amount` - Total bonus amount awarded
- `bonus_count` - Number of bonuses earned
- `earning_id` - Reference to earning record

#### 3. `src/controllers/dailyReferralBonus.controller.js`
Three main functions:
- `checkAndAwardDailyBonus()` - Check and award bonuses
- `getTodayReferralStatus()` - Get current status
- `getDailyBonusHistory()` - Get bonus history

#### 4. `src/routes/dailyReferralBonus.routes.js`
API routes for the bonus system.

#### 5. Database Migrations:
- `022_create_daily_referral_bonuses.js` - Create bonus tracking table
- `023_add_daily_referral_bonus_earning_type.js` - Add earning type

## 📊 Bonus Calculation Logic

### Algorithm:
```javascript
function calculateDailyBonus(referralCount) {
  let totalBonusCount = 0;
  let totalBonusAmount = 0;
  
  if (referralCount >= 3) {
    // First bonus at 3 referrals
    totalBonusCount = 1;
    totalBonusAmount = 283; // PKR
    
    // Additional bonuses every 3 referrals
    const additionalBonuses = Math.floor((referralCount - 3) / 3);
    
    if (additionalBonuses > 0) {
      totalBonusCount += additionalBonuses;
      totalBonusAmount += additionalBonuses * 283; // PKR
    }
  }
  
  return { totalBonusCount, totalBonusAmount };
}
```

### Examples:
| Referrals | Bonuses | Amount (PKR) | Amount (USD) |
|-----------|---------|--------------|--------------|
| 1         | 0       | 0            | $0.00        |
| 2         | 0       | 0            | $0.00        |
| 3         | 1       | 283          | $1.00        |
| 4         | 1       | 283          | $1.00        |
| 5         | 1       | 283          | $1.00        |
| 6         | 2       | 566          | $2.00        |
| 7         | 2       | 566          | $2.00        |
| 8         | 3       | 849          | $3.00        |
| 9         | 3       | 849          | $3.00        |
| 10        | 3       | 849          | $3.00        |
| 11        | 3       | 849          | $3.00        |
| 12        | 3       | 849          | $3.00        |

## 📱 Frontend Integration

### Example: Check and Award Bonus
```javascript
async function checkDailyBonus() {
  try {
    const response = await fetch('/api/daily-referral-bonus/check', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    const data = await response.json();
    
    if (data.success) {
      if (data.data.bonusEarned > 0) {
        alert(`Congratulations! You earned ${data.data.bonusEarned} bonus(es) worth ${data.data.bonusAmount.pkr} PKR!`);
      } else if (data.data.todayReferrals > 0) {
        alert(`You have ${data.data.todayReferrals} referrals today. Keep going!`);
      } else {
        alert('No referrals today yet. Start referring to earn bonuses!');
      }
    }
  } catch (error) {
    console.error('Error checking bonus:', error);
  }
}
```

### Example: Get Today's Status
```javascript
async function getTodayStatus() {
  const response = await fetch('/api/daily-referral-bonus/status', {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  
  const data = await response.json();
  
  if (data.success) {
    const status = data.data;
    
    // Update UI
    document.getElementById('today-referrals').textContent = status.todayReferrals;
    document.getElementById('potential-bonus').textContent = 
      `${status.potentialBonus.count} bonus(es) = ${status.potentialBonus.amount.pkr} PKR`;
    
    // Show progress
    const progressBar = document.getElementById('progress-bar');
    progressBar.style.width = `${status.progress.toNextBonus}%`;
    
    // Show referrals needed
    if (status.progress.referralsNeeded > 0) {
      document.getElementById('referrals-needed').textContent = 
        `${status.progress.referralsNeeded} more referrals needed`;
    }
  }
}
```

### Example: React Component
```javascript
import { useState, useEffect } from 'react';

function DailyReferralBonus() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  
  useEffect(() => {
    fetchStatus();
  }, []);
  
  const fetchStatus = async () => {
    const response = await fetch('/api/daily-referral-bonus/status', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await response.json();
    if (data.success) setStatus(data.data);
  };
  
  const checkBonus = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/daily-referral-bonus/check', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      
      if (data.success) {
        alert(data.message);
        fetchStatus(); // Refresh status
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };
  
  if (!status) return <div>Loading...</div>;
  
  return (
    <div className="daily-bonus">
      <h3>Daily Referral Bonus</h3>
      
      <div className="status">
        <p>Today's Referrals: <strong>{status.todayReferrals}</strong></p>
        <p>Potential Bonus: <strong>{status.potentialBonus.count} = {status.potentialBonus.amount.pkr} PKR</strong></p>
        
        {status.progress.referralsNeeded > 0 && (
          <p>Need <strong>{status.progress.referralsNeeded}</strong> more referrals</p>
        )}
        
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ width: `${status.progress.toNextBonus}%` }}
          />
        </div>
      </div>
      
      <button 
        onClick={checkBonus} 
        disabled={loading || status.bonusAwarded}
        className="check-bonus-btn"
      >
        {loading ? 'Checking...' : status.bonusAwarded ? 'Already Awarded' : 'Check & Claim Bonus'}
      </button>
      
      <div className="rules">
        <h4>Bonus Rules:</h4>
        <ul>
          <li>3 referrals = $1 bonus</li>
          <li>Every 2 more referrals = +$1 bonus</li>
          <li>Bonuses reset daily</li>
        </ul>
      </div>
    </div>
  );
}
```

## 🎨 UI Design Suggestions

### Progress Card:
```
┌─────────────────────────────────────────┐
│  🎯 Daily Referral Bonus                │
├─────────────────────────────────────────┤
│                                         │
│  Today's Referrals: 4                   │
│  Potential Bonus: 1 = 283 PKR           │
│                                         │
│  Progress to Next Bonus:                │
│  ████████████████████░░░░ 75%           │
│                                         │
│  Need 1 more referral for bonus!        │
│                                         │
│  ┌─────────────────────────────────────┐ │
│  │     Check & Claim Bonus        →    │ │
│  └─────────────────────────────────────┘ │
│                                         │
│  Rules:                                 │
│  • 3 referrals = $1 bonus              │
│  • Every 2 more = +$1 bonus            │
│  • Resets daily                        │
└─────────────────────────────────────────┘
```

## 🔒 Security Features

- ✅ Authentication required for all endpoints
- ✅ Users can only access their own bonus data
- ✅ One bonus per day per user (prevents double-claiming)
- ✅ Database transactions ensure data integrity
- ✅ Referrals are counted by creation date

## 📝 Notes

### Important Rules:
1. **Daily Reset**: Bonuses reset every day at midnight
2. **One Claim Per Day**: Users can only claim bonus once per day
3. **Referral Counting**: Only counts referrals made on the same calendar day
4. **Automatic Calculation**: System automatically calculates correct bonus amount
5. **Earning Integration**: Bonuses are added to user's wallet and earnings

### Database Structure:
- `daily_referral_bonuses` table tracks all bonuses
- `earnings` table stores bonus transactions
- Unique constraint prevents duplicate daily bonuses

## 🚀 Testing

### Test Scenarios:
1. ✅ 0 referrals → No bonus
2. ✅ 2 referrals → No bonus, shows progress
3. ✅ 3 referrals → 1 bonus ($1)
4. ✅ 5 referrals → 2 bonuses ($2)
5. ✅ 7 referrals → 3 bonuses ($3)
6. ✅ 10 referrals → 4 bonuses ($4)
7. ✅ Already claimed today → Shows already awarded
8. ✅ Multiple API calls → Prevents double-claiming

## ✅ Summary

**API Endpoints:**
- `POST /api/daily-referral-bonus/check` - Check and award bonuses
- `GET /api/daily-referral-bonus/status` - Get today's status
- `GET /api/daily-referral-bonus/history` - Get bonus history

**Bonus Rules:**
- 3 referrals = $1 (283 PKR)
- 6 referrals = $2 (566 PKR) total
- 8 referrals = $3 (849 PKR) total
- Maximum 8 referrals counted for bonus
- Resets daily
- One claim per day

**Features:**
- ✅ Automatic bonus calculation
- ✅ Progress tracking
- ✅ History viewing
- ✅ Wallet integration
- ✅ Security and validation

---

**Implementation Date**: October 13, 2025  
**Status**: ✅ Complete and Ready  
**Authentication**: Required  
**Role**: User/Admin  

