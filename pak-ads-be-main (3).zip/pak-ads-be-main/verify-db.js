require('dotenv').config();
const { sequelize } = require('./src/config/database');

const verify = async () => {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connected successfully!\n');

    const [tables] = await sequelize.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE'
      ORDER BY table_name;
    `);

    console.log(`📋 Found ${tables.length} tables:\n`);
    tables.forEach(t => console.log(`  ✓ ${t.table_name}`));

    // Count rows in key tables
    console.log('\n📊 Row Counts:');
    const keyTables = ['users', 'categories', 'locations', 'investment_plans', 'packages', 'earnings', 'deposits', 'user_plans'];
    for (const tbl of keyTables) {
      try {
        const [[{ count }]] = await sequelize.query(`SELECT COUNT(*) as count FROM "${tbl}"`);
        console.log(`  ${tbl}: ${count} rows`);
      } catch (e) {
        console.log(`  ${tbl}: (table not found)`);
      }
    }

    console.log('\n✨ Verification complete!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
};

verify();
