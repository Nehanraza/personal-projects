# Complete API Endpoints List - Pak Ads Backend

## 🎯 Total: 82 API Endpoints

---

## 🔐 Authentication (8 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | `/api/v1/auth/register` | Public | Register new user |
| POST | `/api/v1/auth/login` | Public | Login user |
| GET | `/api/v1/auth/logout` | Private | Logout user |
| GET | `/api/v1/auth/me` | Private | Get current user |
| PUT | `/api/v1/auth/updatedetails` | Private | Update user details |
| PUT | `/api/v1/auth/updatepassword` | Private | Update password |
| POST | `/api/v1/auth/forgotpassword` | Public | Request password reset |
| PUT | `/api/v1/auth/resetpassword/:token` | Public | Reset password |

---

## 👥 Users (4 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/users` | Admin | Get all users |
| GET | `/api/v1/users/:id` | Private | Get single user |
| PUT | `/api/v1/users/:id` | Private | Update user |
| DELETE | `/api/v1/users/:id` | Private | Delete user |

---

## 📂 Categories (7 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/categories` | Public | Get all categories |
| GET | `/api/v1/categories/tree` | Public | Get category tree |
| GET | `/api/v1/categories/:id` | Public | Get single category |
| POST | `/api/v1/categories` | Admin | Create category |
| PUT | `/api/v1/categories/:id` | Admin | Update category |
| DELETE | `/api/v1/categories/:id` | Admin | Delete category |

---

## 📍 Locations (7 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/locations` | Public | Get all locations |
| GET | `/api/v1/locations/tree` | Public | Get location tree |
| GET | `/api/v1/locations/:id` | Public | Get single location |
| POST | `/api/v1/locations` | Admin | Create location |
| PUT | `/api/v1/locations/:id` | Admin | Update location |
| DELETE | `/api/v1/locations/:id` | Admin | Delete location |

---

## 📢 Ads (10 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/ads` | Public | Get all ads (with filters) |
| GET | `/api/v1/ads/:id` | Public | Get single ad |
| POST | `/api/v1/ads` | Private | Create ad |
| PUT | `/api/v1/ads/:id` | Private | Update ad |
| DELETE | `/api/v1/ads/:id` | Private | Delete ad |
| PUT | `/api/v1/ads/:id/approve` | Admin | Approve ad |
| PUT | `/api/v1/ads/:id/reject` | Admin | Reject ad |
| PUT | `/api/v1/ads/:id/feature` | Admin | Mark as featured |
| GET | `/api/v1/ads/admin/stats` | Admin | Get ad statistics |

---

## 💎 Packages (6 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/packages` | Public | Get all packages |
| GET | `/api/v1/packages/:id` | Public | Get single package |
| POST | `/api/v1/packages` | Admin | Create package |
| PUT | `/api/v1/packages/:id` | Admin | Update package |
| DELETE | `/api/v1/packages/:id` | Admin | Delete package |

---

## ⭐ Reviews (7 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/reviews` | Public | Get all reviews |
| GET | `/api/v1/reviews/:id` | Public | Get single review |
| POST | `/api/v1/reviews` | Private | Create review |
| PUT | `/api/v1/reviews/:id` | Private | Update review |
| DELETE | `/api/v1/reviews/:id` | Private | Delete review |
| PUT | `/api/v1/reviews/:id/approve` | Admin | Approve review |

---

## 💬 Messages (7 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/messages` | Private | Get all messages |
| GET | `/api/v1/messages/conversation/:adId/:userId` | Private | Get conversation |
| POST | `/api/v1/messages` | Private | Send message |
| PUT | `/api/v1/messages/:id/read` | Private | Mark as read |
| GET | `/api/v1/messages/unread/count` | Private | Get unread count |
| DELETE | `/api/v1/messages/:id` | Private | Delete message |

---

## 🚨 Reports (7 endpoints)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/reports` | Admin | Get all reports |
| GET | `/api/v1/reports/:id` | Admin | Get single report |
| POST | `/api/v1/reports` | Private | Create report |
| PUT | `/api/v1/reports/:id/status` | Admin | Update report status |
| DELETE | `/api/v1/reports/:id` | Admin | Delete report |
| GET | `/api/v1/reports/stats` | Admin | Get report statistics |

---

## ❤️ Favorites (4 endpoints) ⭐NEW

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/favorites` | Private | Get user's favorites |
| POST | `/api/v1/favorites/:adId` | Private | Add to favorites |
| DELETE | `/api/v1/favorites/:adId` | Private | Remove from favorites |
| GET | `/api/v1/favorites/check/:adId` | Private | Check if favorited |

---

## 🔔 Notifications (6 endpoints) ⭐NEW

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/notifications` | Private | Get all notifications |
| GET | `/api/v1/notifications/unread/count` | Private | Get unread count |
| PUT | `/api/v1/notifications/:id/read` | Private | Mark as read |
| PUT | `/api/v1/notifications/read-all` | Private | Mark all as read |
| DELETE | `/api/v1/notifications/:id` | Private | Delete notification |
| DELETE | `/api/v1/notifications/all` | Private | Delete all |

---

## 📊 Dashboard (3 endpoints) ⭐NEW

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/dashboard/home` | Public | Homepage data |
| GET | `/api/v1/dashboard/stats` | Private | User dashboard stats |
| GET | `/api/v1/dashboard/admin/stats` | Admin | Admin dashboard stats |

---

## 👤 Profile (3 endpoints) ⭐NEW

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/api/v1/profile/:userId` | Public | Get user profile |
| GET | `/api/v1/profile/:userId/ads` | Public | Get user's ads |
| GET | `/api/v1/profile/:userId/reviews` | Public | Get user's reviews |

---

## 🏥 System (1 endpoint)

| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| GET | `/health` | Public | Health check |

---

## 📋 Quick Reference by Feature

### For Homepage
- `GET /dashboard/home` - All homepage data
- `GET /categories/tree` - Category navigation
- `GET /locations/tree` - Location dropdown

### For Search/Browse
- `GET /ads` - Search and filter ads
- `GET /categories` - Filter by category
- `GET /locations` - Filter by location

### For Ad Details
- `GET /ads/:id` - Ad details
- `GET /profile/:userId` - Seller profile
- `GET /reviews?ad_id=X` - Ad reviews
- `POST /favorites/:adId` - Add to favorites
- `POST /messages` - Contact seller
- `POST /reports` - Report ad

### For User Dashboard
- `GET /dashboard/stats` - Dashboard statistics
- `GET /ads?user_id=X` - My ads
- `GET /favorites` - My favorites
- `GET /messages` - My messages
- `GET /notifications` - My notifications

### For Posting Ad
- `GET /categories/tree` - Select category
- `GET /locations/tree` - Select location
- `GET /packages` - Select package
- `POST /ads` - Create ad

---

## 🎯 Essential for Frontend

### Must Have Endpoints:
1. `POST /auth/register` - User registration
2. `POST /auth/login` - User login
3. `GET /auth/me` - Get current user
4. `GET /dashboard/home` - Homepage data
5. `GET /ads` - Browse/search ads
6. `GET /ads/:id` - Ad details
7. `POST /ads` - Post new ad
8. `GET /categories/tree` - Categories
9. `GET /locations/tree` - Locations
10. `POST /favorites/:adId` - Save favorites
11. `POST /messages` - Contact sellers
12. `GET /dashboard/stats` - User dashboard

---

## 📖 Full Documentation

- **Frontend APIs**: `FRONTEND_API_DOCUMENTATION.md`
- **Admin APIs**: `API_DOCUMENTATION.md`
- **Setup**: `SETUP_GUIDE.md`
- **Quick Ref**: `QUICK_REFERENCE.md`

---

**Total Endpoints**: 82  
**Public Endpoints**: 15  
**Protected Endpoints**: 40  
**Admin Only Endpoints**: 27

**Status**: ✅ ALL READY FOR PRODUCTION!
