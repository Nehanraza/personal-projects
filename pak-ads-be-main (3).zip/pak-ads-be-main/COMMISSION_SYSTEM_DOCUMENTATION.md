# Generation-Based Multi-Level Commission System

## Overview

This document provides comprehensive documentation for the generation-based referral commission system implemented in the Pak Ads application. The system calculates and distributes direct and indirect referral commissions up to 7 levels based on a configurable percentage structure.

## Table of Contents

1. [Commission Structure](#commission-structure)
2. [System Architecture](#system-architecture)
3. [API Endpoints](#api-endpoints)
4. [Implementation Details](#implementation-details)
5. [Usage Examples](#usage-examples)
6. [Admin Features](#admin-features)
7. [Configuration](#configuration)
8. [Testing Guide](#testing-guide)

---

## Commission Structure

### 7-Level Distribution

The commission system distributes earnings across 7 levels of referrers based on the following structure:

| Level | Amount (PKR) | Percentage | Ratio |
|-------|--------------|------------|-------|
| Level 1 | 22 | 7.7% | 0.077 |
| Level 2 | 9 | 3.1% | 0.031 |
| Level 3 | 7 | 2.4% | 0.024 |
| Level 4 | 5 | 1.7% | 0.017 |
| Level 5 | 4 | 1.4% | 0.014 |
| Level 6 | 3 | 1.0% | 0.010 |
| Level 7 | 2 | 0.7% | 0.007 |
| **Total** | **52 PKR** | **18.0%** | **0.18** |

### Calculation Methods

The system supports two calculation methods:

1. **Percentage-Based**: Commissions are calculated as a percentage of the base transaction amount
2. **Fixed Amount**: Fixed PKR amounts based on the 50 PKR base (as shown in the table above)

### Commission Triggers

Commissions are automatically distributed when:

1. **New Member Joins** (Joining Fee): When a new user registers with a referral code
2. **Ad Watching**: When a user earns money from watching ads
3. **Purchases**: When a user makes a purchase or transaction
4. **Manual Distribution**: Admin can manually trigger commission distribution

---

## System Architecture

### Database Schema

The system uses the existing `earnings` table to track all commission transactions:

```sql
earnings
├── id (Primary Key)
├── user_id (Who earned the commission)
├── from_user_id (Who triggered the commission)
├── amount (Commission amount in PKR)
├── level (Commission level: 1-7)
├── type (referral_commission)
├── description (Human-readable description)
├── status (completed, pending, cancelled)
├── metadata (JSON string with additional data)
├── created_at
└── updated_at
```

### Key Models

1. **User Model**: Contains referral relationships
   - `referred_by`: ID of the user who referred this user
   - `referral_code`: Unique referral code for the user
   - `total_referrals`: Count of direct referrals

2. **Earning Model**: Tracks all financial transactions including commissions

### Commission Service

Location: `src/utils/commissionService.js`

Core functions:
- `getUplineChain()`: Traverses the referral tree up to 7 levels
- `distributeCommission()`: Main distribution logic
- `calculateCommissionForLevel()`: Calculates commission for specific level
- `getUserCommissionStats()`: Gets user's commission statistics
- `getOverallCommissionStats()`: Gets system-wide statistics (admin)

---

## API Endpoints

### User Endpoints

#### Get My Commission Stats
```http
GET /api/v1/commissions/my-stats
Authorization: Bearer {token}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalCommissionEarned": 150.50,
    "totalCommissions": 25,
    "directReferrals": 5,
    "byLevel": [
      {
        "level": 1,
        "count": 5,
        "amount": 110.00
      },
      {
        "level": 2,
        "count": 8,
        "amount": 40.50
      }
    ],
    "recentCommissions": [...]
  }
}
```

#### Get My Commission History
```http
GET /api/v1/commissions/my-history?page=1&limit=20&level=1
Authorization: Bearer {token}
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20)
- `level` (optional): Filter by specific level (1-7)

#### Get My Referral Network
```http
GET /api/v1/commissions/my-network?levels=7
Authorization: Bearer {token}
```

**Query Parameters:**
- `levels` (optional): Maximum levels to retrieve (default: 7)

**Response:**
```json
{
  "success": true,
  "data": {
    "network": [
      {
        "id": 10,
        "name": "John Doe",
        "email": "john@example.com",
        "level": 1,
        "total_referrals": 3,
        "children": [
          {
            "id": 15,
            "name": "Jane Smith",
            "level": 2,
            "children": []
          }
        ]
      }
    ],
    "stats": {
      "totalMembers": 12,
      "byLevel": {
        "1": 5,
        "2": 4,
        "3": 3
      }
    }
  }
}
```

#### Preview Commission Distribution
```http
POST /api/v1/commissions/preview
Authorization: Bearer {token}
Content-Type: application/json

{
  "fromUserId": 123,
  "baseAmount": 650,
  "calculationType": "percentage"
}
```

#### Get Daily Commission Earnings
```http
GET /api/v1/commissions/daily-earnings?days=30
Authorization: Bearer {token}
```

#### Get Commission Structure
```http
GET /api/v1/commissions/structure
```

**Public endpoint** - No authentication required

---

### Admin Endpoints

#### Get Overall Commission Statistics
```http
GET /api/v1/commissions/admin/overall-stats?startDate=2024-01-01&endDate=2024-12-31
Authorization: Bearer {admin_token}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalCommissionDistributed": 125000.00,
    "totalCommissions": 5420,
    "usersWithReferrals": 342,
    "distributionByLevel": [
      {
        "level": 1,
        "count": 1200,
        "amount": 55000.00,
        "percentage": 44
      }
    ],
    "commissionStructure": {...}
  }
}
```

#### Get Top Commission Earners
```http
GET /api/v1/commissions/admin/top-earners?limit=10&startDate=2024-01-01
Authorization: Bearer {admin_token}
```

#### Get User Commission Stats (Admin)
```http
GET /api/v1/commissions/admin/user/:userId
Authorization: Bearer {admin_token}
```

#### Manually Distribute Commission
```http
POST /api/v1/commissions/distribute
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "fromUserId": 123,
  "baseAmount": 650,
  "activityType": "manual",
  "calculationType": "percentage",
  "metadata": {
    "reason": "Special bonus"
  }
}
```

---

### Dashboard Endpoints

#### Get User Commission Dashboard
```http
GET /api/v1/dashboard/commissions
Authorization: Bearer {token}
```

#### Get Admin Commission Dashboard
```http
GET /api/v1/dashboard/admin/commissions?startDate=2024-01-01&endDate=2024-12-31
Authorization: Bearer {admin_token}
```

---

## Implementation Details

### How Commission Distribution Works

1. **User Registration with Referral Code**
   ```javascript
   // In auth.controller.js
   if (referrerId) {
     const joiningFeeAmount = constants.CURRENCY.JOINING_FEE_PKR; // 650 PKR
     await commissionService.distributeJoiningFeeCommission(
       user.id, 
       joiningFeeAmount
     );
   }
   ```

2. **Upline Chain Traversal**
   - System finds the user's referrer (Level 1)
   - Continues up the chain to find Level 2, 3, ... 7 referrers
   - Stops when no more referrers exist or 7 levels reached

3. **Commission Calculation**
   - For percentage-based: `amount = baseAmount × levelRatio`
   - For fixed amount: `amount = fixedLevelAmount`

4. **Database Transactions**
   - All commission distributions use atomic transactions
   - If any level fails, entire distribution is rolled back
   - User wallets are updated immediately

### Commission Flow Example

**Scenario:** User E joins with referral code from User D

```
User A (Level 4)
  └── User B (Level 3)
       └── User C (Level 2)
            └── User D (Level 1) ← Direct referrer
                 └── User E (New user) - Pays 650 PKR joining fee
```

**Distribution (Percentage-based on 650 PKR):**

| User | Level | Calculation | Commission |
|------|-------|-------------|------------|
| User D | 1 | 650 × 0.44 | 286.00 PKR |
| User C | 2 | 650 × 0.18 | 117.00 PKR |
| User B | 3 | 650 × 0.14 | 91.00 PKR |
| User A | 4 | 650 × 0.10 | 65.00 PKR |
| **Total** | | | **559.00 PKR** |

---

## Usage Examples

### Integrating Commission Distribution

#### Example 1: Ad Watching Earnings

```javascript
// In your ad watching controller
const { distributeAdWatchingCommission } = require('../utils/commissionService');

// After user watches an ad and earns money
const adEarning = 50; // PKR earned from watching ad

try {
  const result = await distributeAdWatchingCommission(
    userId,
    adEarning
  );
  
  console.log(`Distributed ${result.totalDistributed} PKR to ${result.recipients} recipients`);
} catch (error) {
  console.error('Commission distribution failed:', error);
  // Handle error - don't fail the main operation
}
```

#### Example 2: Purchase Transaction

```javascript
const { distributePurchaseCommission } = require('../utils/commissionService');

// After user completes a purchase
const purchaseAmount = 5000; // PKR

const result = await distributePurchaseCommission(
  userId,
  purchaseAmount,
  {
    orderId: order.id,
    productName: product.name
  }
);
```

#### Example 3: Getting User Commission Summary

```javascript
const { getUserCommissionStats } = require('../utils/commissionService');

const stats = await getUserCommissionStats(userId);

console.log(`Total Earned: ${stats.totalCommissionEarned} PKR`);
console.log(`From ${stats.totalCommissions} commissions`);
console.log(`Direct Referrals: ${stats.directReferrals}`);
```

---

## Admin Features

### Commission Analytics Dashboard

Admins have access to comprehensive analytics:

1. **Overall Statistics**
   - Total commissions distributed (PKR)
   - Number of commission transactions
   - Users with active referrals
   - Distribution breakdown by level

2. **Top Earners**
   - Ranked list of users by commission earnings
   - Filterable by date range
   - Shows direct referral count

3. **User-Specific Analysis**
   - View any user's complete commission history
   - See their referral network
   - Check earning patterns

4. **Manual Commission Distribution**
   - Trigger commissions for special cases
   - Override calculation type
   - Add custom metadata

### Updating Commission Ratios

To modify commission percentages, update `src/config/constants.js`:

```javascript
COMMISSION_LEVELS: {
  1: { amount: 22, ratio: 0.44, percentage: 44 },
  2: { amount: 9, ratio: 0.18, percentage: 18 },
  // ... update values as needed
}
```

**Important:** Changes take effect immediately for new commissions but don't affect historical data.

---

## Configuration

### Environment Variables

No additional environment variables required. The system uses existing database and JWT configuration.

### Constants Configuration

Location: `src/config/constants.js`

```javascript
// Commission structure
COMMISSION_LEVELS: {
  1: { amount: 22, ratio: 0.44, percentage: 44 },
  // ... levels 2-7
},

// Configuration
COMMISSION_CONFIG: {
  BASE_AMOUNT: 50,        // Base amount for fixed calculations
  TOTAL_LEVELS: 7,        // Maximum commission levels
  TOTAL_DISTRIBUTED: 52,  // Total amount distributed in fixed mode
}
```

---

## Testing Guide

### Manual Testing

#### Test 1: New User Registration with Referral

1. Register User A
2. Note User A's referral code
3. Register User B with User A's referral code
4. Check User A's wallet - should increase by Level 1 commission
5. Verify earning record created with correct level

#### Test 2: Multi-Level Commission Chain

1. Create referral chain: User A → User B → User C
2. Register User D with User C's referral code
3. Verify commissions:
   - User C receives Level 1 commission
   - User B receives Level 2 commission
   - User A receives Level 3 commission

#### Test 3: 7-Level Deep Chain

1. Create 7-level referral chain
2. Register new user at the bottom
3. Verify all 7 levels receive correct commissions
4. Verify Level 8 (if exists) does NOT receive commission

#### Test 4: Commission API Endpoints

```bash
# Get your commission stats
curl -X GET http://localhost:5000/api/v1/commissions/my-stats \
  -H "Authorization: Bearer YOUR_TOKEN"

# Get commission history
curl -X GET "http://localhost:5000/api/v1/commissions/my-history?page=1&limit=10" \
  -H "Authorization: Bearer YOUR_TOKEN"

# Preview commission distribution
curl -X POST http://localhost:5000/api/v1/commissions/preview \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "fromUserId": 123,
    "baseAmount": 650,
    "calculationType": "percentage"
  }'
```

### Automated Testing

Create test cases in `src/tests/commission.test.js`:

```javascript
describe('Commission System', () => {
  test('should distribute commission to 7 levels', async () => {
    // Test implementation
  });

  test('should stop at maximum 7 levels', async () => {
    // Test implementation
  });

  test('should handle users with no referrers', async () => {
    // Test implementation
  });

  test('should calculate correct percentages', async () => {
    // Test implementation
  });
});
```

---

## Database Queries

### Useful Admin Queries

#### Get total commissions by level
```sql
SELECT 
  level,
  COUNT(*) as commission_count,
  SUM(amount) as total_amount
FROM earnings
WHERE type = 'referral_commission'
GROUP BY level
ORDER BY level;
```

#### Find top commission earners
```sql
SELECT 
  u.id,
  u.name,
  u.email,
  SUM(e.amount) as total_commissions,
  COUNT(e.id) as commission_count
FROM users u
JOIN earnings e ON u.id = e.user_id
WHERE e.type = 'referral_commission'
GROUP BY u.id, u.name, u.email
ORDER BY total_commissions DESC
LIMIT 10;
```

#### View specific user's upline chain
```sql
WITH RECURSIVE upline AS (
  SELECT id, name, referred_by, 1 as level
  FROM users
  WHERE id = ? -- Target user ID
  
  UNION ALL
  
  SELECT u.id, u.name, u.referred_by, up.level + 1
  FROM users u
  JOIN upline up ON u.id = up.referred_by
  WHERE up.level < 7
)
SELECT * FROM upline;
```

---

## Troubleshooting

### Common Issues

#### Issue: Commissions not being distributed
**Solution:**
1. Check user has a valid `referred_by` field
2. Verify referrer exists in database
3. Check transaction logs for errors
4. Ensure commission service is imported correctly

#### Issue: Wrong commission amounts
**Solution:**
1. Verify `COMMISSION_LEVELS` configuration
2. Check `calculationType` parameter (percentage vs fixed)
3. Review base amount being passed

#### Issue: Commission distribution partially fails
**Solution:**
1. Check database transaction logs
2. Verify all users in chain exist
3. Ensure wallet balance updates are atomic
4. Review error logs for specific failures

---

## Security Considerations

1. **Authorization**: All commission-related endpoints require authentication
2. **Admin Protection**: Commission distribution and analytics require admin role
3. **Transaction Integrity**: All distributions use database transactions
4. **Audit Trail**: All commissions are logged with metadata
5. **Input Validation**: Base amounts and user IDs are validated

---

## Future Enhancements

Possible improvements for the commission system:

1. **Dynamic Commission Rates**
   - Allow per-user or per-campaign commission rates
   - Time-based commission multipliers

2. **Commission Caps**
   - Maximum commission per user per day/month
   - Lifetime commission limits

3. **Bonus Levels**
   - Extra bonuses for high-performing referrers
   - Achievement-based commission boosts

4. **Commission Reports**
   - Automated email reports for users
   - PDF commission statements
   - Tax documentation generation

5. **Real-time Notifications**
   - Push notifications for commission earnings
   - WebSocket updates for live dashboard

---

## Support

For questions or issues:
- Review this documentation
- Check `src/utils/commissionService.js` for implementation details
- Contact development team

---

## Changelog

### Version 1.0.0 (Current)
- Initial implementation of 7-level commission system
- Percentage and fixed amount calculation methods
- User and admin API endpoints
- Dashboard integration
- Complete documentation

---

## License

This commission system is part of the Pak Ads application and follows the same licensing terms.

---

**Last Updated:** October 2024
**Version:** 1.0.0


