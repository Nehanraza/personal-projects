/**
 * Final Check - Indirect Referrals with Complete Explanation
 * Shows database data and explains what API should return
 */

require('dotenv').config();
const { sequelize, User } = require('./src/models');
const { Op } = require('sequelize');

// User details
const userEmail = 'faisalcomedychanel@gmail.com';
const userPhone = '03497210618';

// Colors
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
  bold: '\x1b[1m',
};

async function main() {
  try {
    console.log(`${colors.cyan}${colors.bold}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.cyan}${colors.bold}║  INDIRECT REFERRALS - COMPLETE ANALYSIS              ║${colors.reset}`);
    console.log(`${colors.cyan}${colors.bold}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    // Step 1: Explain Levels
    console.log(`${colors.yellow}${colors.bold}📚 LEVELS KYA HAIN? (Explanation)${colors.reset}\n`);
    console.log(`   ${colors.cyan}Level 1 (Direct Referrals):${colors.reset}`);
    console.log(`      → Ye wo users hain jo DIRECT aap se refer huye hain`);
    console.log(`      → Example: Aap (User 406) ne User A ko refer kiya → User A = Level 1\n`);

    console.log(`   ${colors.cyan}Level 2 (Indirect Referrals):${colors.reset}`);
    console.log(`      → Ye wo users hain jo aapke DIRECT referrals (Level 1) ne refer kiye hain`);
    console.log(`      → Example: User A ne User B ko refer kiya → User B = Level 2\n`);

    console.log(`   ${colors.cyan}Level 3 (Indirect Referrals):${colors.reset}`);
    console.log(`      → Ye wo users hain jo Level 2 ke users ne refer kiye hain`);
    console.log(`      → Example: User B ne User C ko refer kiya → User C = Level 3\n`);

    console.log(`   ${colors.cyan}Level 4-7 (Indirect Referrals):${colors.reset}`);
    console.log(`      → Same pattern continue hota hai`);
    console.log(`      → Level 4 = Level 3 ke referrals`);
    console.log(`      → Level 5 = Level 4 ke referrals`);
    console.log(`      → Level 6 = Level 5 ke referrals`);
    console.log(`      → Level 7 = Level 6 ke referrals\n`);

    console.log(`${colors.green}${colors.bold}✓ Total Indirect Referrals = Level 2 + Level 3 + Level 4 + Level 5 + Level 6 + Level 7${colors.reset}\n`);
    console.log(`${colors.magenta}${'─'.repeat(60)}${colors.reset}\n`);

    // Step 2: Find User
    console.log(`${colors.blue}${colors.bold}Step 1: Finding User...${colors.reset}\n`);
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: userEmail },
          { phone: userPhone }
        ]
      },
      attributes: ['id', 'name', 'email', 'phone']
    });

    if (!user) {
      console.log(`${colors.red}✗ User not found${colors.reset}\n`);
      process.exit(1);
    }

    console.log(`${colors.green}✓ User found:${colors.reset}`);
    console.log(`   ID: ${user.id}`);
    console.log(`   Name: ${user.name}`);
    console.log(`   Email: ${user.email}`);
    console.log(`   Phone: ${user.phone}\n`);

    // Step 3: Get Direct Referrals
    console.log(`${colors.blue}${colors.bold}Step 2: Getting Direct Referrals (Level 1)...${colors.reset}\n`);
    const directReferrals = await User.findAll({
      where: { referred_by: user.id },
      attributes: ['id', 'name', 'email']
    });

    console.log(`${colors.green}✓ Direct Referrals Count: ${directReferrals.length}${colors.reset}\n`);

    // Step 4: Get All Levels
    console.log(`${colors.blue}${colors.bold}Step 3: Getting All Referral Levels...${colors.reset}\n`);
    const levelCounts = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, 1 as level
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, rt.level + 1
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT level, COUNT(*) as count
      FROM referral_tree
      GROUP BY level
      ORDER BY level;
    `, {
      replacements: { userId: user.id },
      type: sequelize.QueryTypes.SELECT,
    });

    // Separate direct and indirect
    const directLevel = levelCounts.find(item => parseInt(item.level, 10) === 1);
    const indirectLevels = levelCounts.filter(item => parseInt(item.level, 10) > 1);
    
    // Calculate total indirect
    const totalIndirectReferrals = indirectLevels.reduce((sum, item) => {
      return sum + parseInt(item.count, 10);
    }, 0);

    // Step 5: Display Results
    console.log(`${colors.magenta}${colors.bold}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}║  RESULTS - INDIRECT REFERRALS COUNT                  ║${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    console.log(`${colors.cyan}${colors.bold}1. DIRECT REFERRALS (Level 1):${colors.reset}`);
    console.log(`   Total: ${colors.green}${colors.bold}${directLevel ? directLevel.count : 0}${colors.reset} users\n`);

    console.log(`${colors.cyan}${colors.bold}2. INDIRECT REFERRALS (Levels 2-7):${colors.reset}\n`);
    console.log(`   ${colors.green}${colors.bold}Total Indirect Referrals: ${totalIndirectReferrals}${colors.reset} users\n`);
    
    console.log(`   ${colors.yellow}Breakdown by Level:${colors.reset}`);
    indirectLevels.forEach(level => {
      const levelNum = parseInt(level.level, 10);
      const count = parseInt(level.count, 10);
      console.log(`      Level ${levelNum}: ${colors.green}${count}${colors.reset} users`);
    });
    console.log('');

    // Step 6: Show Network Summary
    console.log(`${colors.cyan}${colors.bold}3. NETWORK SUMMARY (All Levels):${colors.reset}\n`);
    levelCounts.forEach(item => {
      const level = parseInt(item.level, 10);
      const count = parseInt(item.count, 10);
      const type = level === 1 ? 'direct' : 'indirect';
      const typeColor = type === 'direct' ? colors.cyan : colors.yellow;
      console.log(`   Level ${level} (${typeColor}${type}${colors.reset}): ${colors.green}${count}${colors.reset} users`);
    });
    console.log('');

    // Step 7: Show What API Should Return
    console.log(`${colors.magenta}${colors.bold}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}║  API RESPONSE STRUCTURE (What API Should Return)    ║${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    console.log(`${colors.cyan}API Endpoint: GET /api/v1/wallet/referral-tree${colors.reset}\n`);
    console.log(`${colors.yellow}Expected Response:${colors.reset}`);
    console.log(`{`);
    console.log(`  "success": true,`);
    console.log(`  "data": {`);
    console.log(`    "directReferrals": [...],`);
    console.log(`    "directReferralsStats": {`);
    console.log(`      "total": ${directLevel ? directLevel.count : 0},`);
    console.log(`      "withApprovedDeposits": <count>,`);
    console.log(`      "withoutApprovedDeposits": <count>`);
    console.log(`    },`);
    console.log(`    ${colors.green}"indirectReferralsStats": {${colors.reset}`);
    console.log(`      ${colors.green}"total": ${totalIndirectReferrals},${colors.reset}`);
    console.log(`      ${colors.green}"byLevel": [${colors.reset}`);
    indirectLevels.forEach(level => {
      console.log(`        ${colors.green}{ "level": ${level.level}, "count": ${level.count} },${colors.reset}`);
    });
    console.log(`      ${colors.green}]${colors.reset}`);
    console.log(`    ${colors.green}},${colors.reset}`);
    console.log(`    "networkSummary": [`);
    levelCounts.forEach(item => {
      const type = parseInt(item.level, 10) === 1 ? 'direct' : 'indirect';
      console.log(`      { "level": ${item.level}, "count": ${item.count}, "type": "${type}" },`);
    });
    console.log(`    ]`);
    console.log(`  }`);
    console.log(`}\n`);

    // Step 8: Final Summary
    console.log(`${colors.magenta}${colors.bold}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}║  FINAL SUMMARY                                      ║${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    console.log(`${colors.green}${colors.bold}✓ Total Indirect Referrals: ${totalIndirectReferrals}${colors.reset}\n`);
    console.log(`${colors.cyan}Breakdown:${colors.reset}`);
    indirectLevels.forEach(level => {
      console.log(`   - Level ${level.level}: ${level.count} users`);
    });
    console.log('');

    console.log(`${colors.yellow}${colors.bold}Important Points:${colors.reset}`);
    console.log(`   1. Level 1 = Direct Referrals (${directLevel ? directLevel.count : 0} users)`);
    console.log(`   2. Level 2-7 = Indirect Referrals (${totalIndirectReferrals} users total)`);
    console.log(`   3. API mein ${colors.green}indirectReferralsStats${colors.reset} field hai jo total count deta hai`);
    console.log(`   4. API mein ${colors.green}indirectReferralsStats.byLevel${colors.reset} field hai jo har level ka count deta hai`);
    console.log(`   5. ${colors.green}networkSummary${colors.reset} mein har level ka count aur type (direct/indirect) hai\n`);

    console.log(`${colors.green}${colors.bold}✓ Analysis Complete!${colors.reset}\n`);

    await sequelize.close();

  } catch (error) {
    console.error(`${colors.red}✗ Error: ${error.message}${colors.reset}`);
    console.error(error);
    await sequelize.close();
    process.exit(1);
  }
}

// Run
if (require.main === module) {
  main();
}

module.exports = { main };

