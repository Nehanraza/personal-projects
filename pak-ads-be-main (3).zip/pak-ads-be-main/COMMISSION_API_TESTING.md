# Commission System - API Testing Guide

## 🧪 Complete API Testing Guide

This document provides step-by-step instructions for testing the commission system APIs.

---

## Prerequisites

- Server running on `http://localhost:5000` (or your API URL)
- At least one registered user account
- Admin account for testing admin endpoints
- Tool for making API requests (curl, Postman, Insomnia, etc.)

---

## Test Scenario 1: User Registration with Referral

### Step 1: Get Referral Code

```bash
# Login as User A
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "userA@example.com",
    "password": "password123"
  }'

# Save the token from response
# Note the referralCode from the user object
```

**Expected Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "User A",
    "email": "userA@example.com",
    "referralCode": "ABC12345",
    "totalReferrals": 0
  }
}
```

### Step 2: Register New User with Referral Code

```bash
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "User B",
    "email": "userB@example.com",
    "password": "password123",
    "referralCode": "ABC12345",
    "joiningFeePaid": true
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 2,
    "name": "User B",
    "email": "userB@example.com",
    "referralCode": "DEF67890",
    "totalReferrals": 0,
    "joiningFeePaid": true
  }
}
```

### Step 3: Check Commission Was Distributed

```bash
# Check User A's commission stats
curl -X GET http://localhost:5000/api/v1/commissions/my-stats \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "totalCommissionEarned": 286.00,
    "totalCommissions": 1,
    "directReferrals": 1,
    "byLevel": [
      {
        "level": 1,
        "count": 1,
        "amount": 286.00
      }
    ],
    "recentCommissions": [
      {
        "id": 1,
        "amount": 286.00,
        "level": 1,
        "fromUser": {
          "id": 2,
          "name": "User B"
        },
        "description": "Level 1 referral commission from User B (joining_fee)",
        "createdAt": "2024-10-14T10:00:00.000Z"
      }
    ]
  }
}
```

### Step 4: Check User A's Wallet Balance

```bash
curl -X GET http://localhost:5000/api/v1/dashboard/financial \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected:** Wallet balance increased by 286 PKR

---

## Test Scenario 2: Multi-Level Commission Chain

### Create 3-Level Chain

```bash
# 1. User A registers (no referral)
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "User A",
    "email": "userA@example.com",
    "password": "password123",
    "joiningFeePaid": true
  }'
# Note: referralCode = ABC12345

# 2. User B registers with User A's code
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "User B",
    "email": "userB@example.com",
    "password": "password123",
    "referralCode": "ABC12345",
    "joiningFeePaid": true
  }'
# Note: referralCode = DEF67890

# 3. User C registers with User B's code
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "User C",
    "email": "userC@example.com",
    "password": "password123",
    "referralCode": "DEF67890",
    "joiningFeePaid": true
  }'
# Note: referralCode = GHI24680

# 4. User D registers with User C's code
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "User D",
    "email": "userD@example.com",
    "password": "password123",
    "referralCode": "GHI24680",
    "joiningFeePaid": true
  }'
```

### Verify Commissions

```bash
# Check User C (Level 1 - Direct referrer)
curl -X GET http://localhost:5000/api/v1/commissions/my-stats \
  -H "Authorization: Bearer USER_C_TOKEN"
# Expected: 286 PKR (650 × 0.44)

# Check User B (Level 2)
curl -X GET http://localhost:5000/api/v1/commissions/my-stats \
  -H "Authorization: Bearer USER_B_TOKEN"
# Expected: 403 PKR total (286 from User C + 117 from User D)

# Check User A (Level 3)
curl -X GET http://localhost:5000/api/v1/commissions/my-stats \
  -H "Authorization: Bearer USER_A_TOKEN"
# Expected: 494 PKR total (286 + 117 + 91)
```

---

## Test Scenario 3: Commission History

### Get Paginated History

```bash
# Get first page
curl -X GET "http://localhost:5000/api/v1/commissions/my-history?page=1&limit=10" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "commissions": [
      {
        "id": 3,
        "amount": 91.00,
        "level": 3,
        "fromUser": {
          "id": 4,
          "name": "User D",
          "email": "userD@example.com"
        },
        "description": "Level 3 referral commission from User D (joining_fee)",
        "status": "completed",
        "metadata": {
          "activity_type": "joining_fee",
          "base_amount": 650,
          "calculation_type": "percentage",
          "commission_percentage": 14
        },
        "createdAt": "2024-10-14T10:30:00.000Z"
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "total": 3,
      "totalPages": 1
    }
  }
}
```

### Filter by Level

```bash
# Get only Level 1 commissions
curl -X GET "http://localhost:5000/api/v1/commissions/my-history?level=1" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## Test Scenario 4: Referral Network

### Get Network Tree

```bash
curl -X GET "http://localhost:5000/api/v1/commissions/my-network?levels=7" \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "network": [
      {
        "id": 2,
        "name": "User B",
        "email": "userB@example.com",
        "created_at": "2024-10-14T09:00:00.000Z",
        "total_referrals": 1,
        "level": 1,
        "children": [
          {
            "id": 3,
            "name": "User C",
            "email": "userC@example.com",
            "created_at": "2024-10-14T09:30:00.000Z",
            "total_referrals": 1,
            "level": 2,
            "children": [
              {
                "id": 4,
                "name": "User D",
                "email": "userD@example.com",
                "created_at": "2024-10-14T10:00:00.000Z",
                "total_referrals": 0,
                "level": 3,
                "children": []
              }
            ]
          }
        ]
      }
    ],
    "stats": {
      "totalMembers": 3,
      "byLevel": {
        "1": 1,
        "2": 1,
        "3": 1
      }
    }
  }
}
```

---

## Test Scenario 5: Commission Preview

### Preview Before Distribution

```bash
curl -X POST http://localhost:5000/api/v1/commissions/preview \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "fromUserId": 4,
    "baseAmount": 650,
    "calculationType": "percentage"
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "fromUserId": 4,
    "baseAmount": 650,
    "calculationType": "percentage",
    "totalToDistribute": 494.00,
    "recipients": 3,
    "levels": [
      {
        "userId": 3,
        "userName": "User C",
        "level": 1,
        "amount": 286.00,
        "percentage": 44
      },
      {
        "userId": 2,
        "userName": "User B",
        "level": 2,
        "amount": 117.00,
        "percentage": 18
      },
      {
        "userId": 1,
        "userName": "User A",
        "level": 3,
        "amount": 91.00,
        "percentage": 14
      }
    ]
  }
}
```

---

## Test Scenario 6: Daily Earnings Chart

### Get Daily Commission Earnings

```bash
curl -X GET "http://localhost:5000/api/v1/commissions/daily-earnings?days=30" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "days": 30,
    "earnings": [
      {
        "date": "2024-10-14",
        "amount": 494.00,
        "count": 3
      },
      {
        "date": "2024-10-13",
        "amount": 286.00,
        "count": 1
      }
    ]
  }
}
```

---

## Test Scenario 7: Commission Structure (Public)

### Get Commission Structure

```bash
# No authentication required
curl -X GET http://localhost:5000/api/v1/commissions/structure
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "levels": {
      "1": { "amount": 22, "ratio": 0.44, "percentage": 44 },
      "2": { "amount": 9, "ratio": 0.18, "percentage": 18 },
      "3": { "amount": 7, "ratio": 0.14, "percentage": 14 },
      "4": { "amount": 5, "ratio": 0.10, "percentage": 10 },
      "5": { "amount": 4, "ratio": 0.08, "percentage": 8 },
      "6": { "amount": 3, "ratio": 0.06, "percentage": 6 },
      "7": { "amount": 2, "ratio": 0.04, "percentage": 4 }
    },
    "config": {
      "BASE_AMOUNT": 50,
      "TOTAL_LEVELS": 7,
      "TOTAL_DISTRIBUTED": 52
    }
  }
}
```

---

## Test Scenario 8: User Commission Dashboard

### Get Dashboard Data

```bash
curl -X GET http://localhost:5000/api/v1/dashboard/commissions \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": 1,
      "name": "User A",
      "referralCode": "ABC12345",
      "totalReferrals": 1
    },
    "commissions": {
      "totalCommissionEarned": 494.00,
      "totalCommissions": 3,
      "directReferrals": 1,
      "byLevel": [
        { "level": 1, "count": 1, "amount": 286.00 },
        { "level": 2, "count": 1, "amount": 117.00 },
        { "level": 3, "count": 1, "amount": 91.00 }
      ],
      "recentCommissions": [...]
    }
  }
}
```

---

## Admin Tests

### Test Scenario 9: Overall Statistics

```bash
# Admin only
curl -X GET "http://localhost:5000/api/v1/commissions/admin/overall-stats?startDate=2024-01-01&endDate=2024-12-31" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "totalCommissionDistributed": 1274.00,
    "totalCommissions": 7,
    "usersWithReferrals": 3,
    "distributionByLevel": [
      {
        "level": 1,
        "count": 3,
        "amount": 858.00,
        "percentage": 44
      },
      {
        "level": 2,
        "count": 2,
        "amount": 234.00,
        "percentage": 18
      },
      {
        "level": 3,
        "count": 1,
        "amount": 91.00,
        "percentage": 14
      }
    ],
    "commissionStructure": {...}
  }
}
```

### Test Scenario 10: Top Earners

```bash
curl -X GET "http://localhost:5000/api/v1/commissions/admin/top-earners?limit=10" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "topEarners": [
      {
        "userId": 1,
        "name": "User A",
        "email": "userA@example.com",
        "totalReferrals": 1,
        "totalEarned": 494.00,
        "commissionCount": 3
      },
      {
        "userId": 2,
        "name": "User B",
        "email": "userB@example.com",
        "totalReferrals": 1,
        "totalEarned": 403.00,
        "commissionCount": 2
      }
    ],
    "limit": 10
  }
}
```

### Test Scenario 11: Specific User Stats (Admin)

```bash
curl -X GET http://localhost:5000/api/v1/commissions/admin/user/1 \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": 1,
      "name": "User A",
      "email": "userA@example.com",
      "totalReferrals": 1
    },
    "stats": {
      "totalCommissionEarned": 494.00,
      "totalCommissions": 3,
      "directReferrals": 1,
      "byLevel": [...],
      "recentCommissions": [...]
    }
  }
}
```

### Test Scenario 12: Manual Commission Distribution

```bash
curl -X POST http://localhost:5000/api/v1/commissions/distribute \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "fromUserId": 4,
    "baseAmount": 1000,
    "activityType": "manual_bonus",
    "calculationType": "percentage",
    "metadata": {
      "reason": "Special achievement bonus",
      "campaign": "October 2024"
    }
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Commission distributed successfully",
  "data": {
    "success": true,
    "distributed": true,
    "message": "Commission distributed successfully",
    "totalDistributed": 760.00,
    "recipients": 3,
    "details": [
      {
        "userId": 3,
        "userName": "User C",
        "level": 1,
        "amount": 440.00,
        "earningId": 8
      },
      {
        "userId": 2,
        "userName": "User B",
        "level": 2,
        "amount": 180.00,
        "earningId": 9
      },
      {
        "userId": 1,
        "userName": "User A",
        "level": 3,
        "amount": 140.00,
        "earningId": 10
      }
    ]
  }
}
```

### Test Scenario 13: Admin Commission Dashboard

```bash
curl -X GET "http://localhost:5000/api/v1/dashboard/admin/commissions?startDate=2024-01-01&endDate=2024-12-31" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

---

## Error Test Cases

### Test: Invalid Referral Code

```bash
curl -X POST http://localhost:5000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "User X",
    "email": "userX@example.com",
    "password": "password123",
    "referralCode": "INVALID123",
    "joiningFeePaid": true
  }'
```

**Expected Response:**
```json
{
  "success": false,
  "message": "Invalid referral code"
}
```

### Test: Unauthorized Access

```bash
# Try to access admin endpoint without admin token
curl -X GET http://localhost:5000/api/v1/commissions/admin/overall-stats
```

**Expected Response:**
```json
{
  "success": false,
  "message": "Not authorized to access this route"
}
```

### Test: Missing Authentication

```bash
# Try to access protected endpoint without token
curl -X GET http://localhost:5000/api/v1/commissions/my-stats
```

**Expected Response:**
```json
{
  "success": false,
  "message": "Not authorized to access this route"
}
```

---

## Postman Collection

Import this collection to Postman for quick testing:

```json
{
  "info": {
    "name": "Commission System API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "User Endpoints",
      "item": [
        {
          "name": "Get My Stats",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{token}}"
              }
            ],
            "url": "{{baseUrl}}/api/v1/commissions/my-stats"
          }
        },
        {
          "name": "Get My History",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{token}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/api/v1/commissions/my-history?page=1&limit=10",
              "query": [
                { "key": "page", "value": "1" },
                { "key": "limit", "value": "10" }
              ]
            }
          }
        }
      ]
    }
  ],
  "variable": [
    {
      "key": "baseUrl",
      "value": "http://localhost:5000"
    },
    {
      "key": "token",
      "value": ""
    }
  ]
}
```

---

## Verification Checklist

After running all tests, verify:

- [ ] New users with referral codes receive correct commissions
- [ ] Multi-level chains distribute to all levels (up to 7)
- [ ] Commission amounts are calculated correctly
- [ ] Wallet balances update properly
- [ ] Commission history shows all earnings
- [ ] Referral network tree displays correctly
- [ ] Preview shows accurate distribution
- [ ] Admin can view overall statistics
- [ ] Admin can see top earners
- [ ] Manual distribution works
- [ ] Error cases handled properly
- [ ] Authentication/authorization working

---

## Database Verification

Check the database directly:

```sql
-- View all commission earnings
SELECT 
  e.id,
  e.user_id,
  u.name as user_name,
  e.from_user_id,
  fu.name as from_user_name,
  e.amount,
  e.level,
  e.description,
  e.created_at
FROM earnings e
JOIN users u ON e.user_id = u.id
LEFT JOIN users fu ON e.from_user_id = fu.id
WHERE e.type = 'referral_commission'
ORDER BY e.created_at DESC;

-- Check user wallet balances
SELECT 
  id,
  name,
  wallet_balance,
  total_earnings,
  total_referrals
FROM users
WHERE total_referrals > 0;

-- Verify referral chain
SELECT 
  id,
  name,
  email,
  referred_by
FROM users
ORDER BY id;
```

---

## Success Criteria

✅ All API endpoints return expected responses  
✅ Commission calculations match specifications  
✅ Database records created correctly  
✅ Wallet balances updated accurately  
✅ Error handling works properly  
✅ Authentication/authorization enforced  
✅ Multi-level chains work up to 7 levels  
✅ Admin features accessible only to admins  

---

**Testing Complete!** 🎉

Your commission system is ready for production use.

---

**Last Updated:** October 2024  
**Version:** 1.0.0


