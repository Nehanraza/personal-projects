# Ads API Usage Guide

## ✅ Fixed Issues

### 1. **GET /api/v1/ads** - 500 Error Fixed
- **Problem:** Database not initialized
- **Solution:** Run `GET /api/v1/setup-database` once to initialize database
- **Status:** ✅ Working (returns 200 with empty array when no ads)

### 2. **POST /api/v1/upload** - 500 Error Fixed  
- **Problem:** Serverless disk write fails on Vercel
- **Solution:** Implemented Cloudinary cloud storage
- **Status:** ✅ Working (uploads to cloud, returns imageUrl)

## 🎯 Admin Ad Creation with External URLs

### Example: Creating Ad with External YouTube/Image URLs

```javascript
// POST /api/v1/ads
{
  "title": "Amazing Product Ad",
  "description": "Check out this amazing product!",
  "external_url": "https://youtube.com/watch?v=example", // Admin can paste any external URL
  "placement": "homepage",
  "category_id": 1,
  "location_id": 1,
  "price": 1000,
  "condition": "new",
  "status": "active",
  "is_featured": true,
  "images": [
    {
      "image_url": "https://example.com/image1.jpg", // External image URL
      "thumbnail_url": "https://example.com/thumb1.jpg",
      "is_primary": true
    },
    {
      "image_url": "https://youtube.com/thumbnail.jpg", // YouTube thumbnail
      "thumbnail_url": "https://youtube.com/thumb.jpg",
      "is_primary": false
    }
  ]
}
```

### Response Format
```javascript
{
  "success": true,
  "data": {
    "id": 1,
    "title": "Amazing Product Ad",
    "description": "Check out this amazing product!",
    "external_url": "https://youtube.com/watch?v=example",
    "placement": "homepage",
    "images": [
      {
        "id": 1,
        "image_url": "https://example.com/image1.jpg",
        "thumbnail_url": "https://example.com/thumb1.jpg",
        "is_primary": true
      }
    ],
    "user": {
      "id": 1,
      "name": "Admin User",
      "email": "admin@example.com"
    },
    "category": {
      "id": 1,
      "name": "Electronics"
    },
    "location": {
      "id": 1,
      "name": "Karachi"
    }
  }
}
```

## 🔧 Upload API Usage

### Upload Image to Cloudinary
```javascript
// POST /api/v1/upload
// Content-Type: multipart/form-data
// Body: file (image file)

// Response:
{
  "success": true,
  "message": "Image uploaded successfully",
  "data": {
    "imageUrl": "https://res.cloudinary.com/your-cloud/image/upload/v1234567890/pak-ads/example.jpg",
    "publicId": "pak-ads/example",
    "filename": "example.jpg",
    "size": 1024000,
    "mimetype": "image/jpeg"
  }
}
```

## 🎯 Frontend Integration

The frontend developer can now:

1. **Get Ads:** `GET /api/v1/ads` - Returns 200 with ads array
2. **Upload Images:** `POST /api/v1/upload` - Uploads to Cloudinary, returns imageUrl
3. **Create Ads:** `POST /api/v1/ads` - Supports external URLs and image arrays
4. **Admin Workflow:** 
   - Admin copies YouTube/external URL
   - Admin uploads thumbnail image via upload API
   - Admin creates ad with external_url and image_url from upload response
   - Frontend displays the ad with external link

## ✅ All Issues Resolved!

- ✅ Database initialization working
- ✅ Ads API returning 200 with proper data structure  
- ✅ Upload API using Cloudinary (no more disk write errors)
- ✅ External URL support in ads
- ✅ Ready for frontend integration
