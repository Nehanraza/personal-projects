# Multi-Level Commission Distribution - Visual Flow

## 📊 Commission Distribution Visualization

### Commission Structure (Per New Registration)

```
┌─────────────────────────────────────────────────────┐
│         TOTAL DISTRIBUTION: 52 PKR                  │
└─────────────────────────────────────────────────────┘

Level 1 (Direct Referrer)     ████████████████████  22 PKR (42%)
Level 2                        ████████              9 PKR  (17%)
Level 3                        ███████               7 PKR  (13%)
Level 4                        █████                 5 PKR  (10%)
Level 5                        ████                  4 PKR  (8%)
Level 6                        ███                   3 PKR  (6%)
Level 7                        ██                    2 PKR  (4%)
```

---

## 🔄 Real-World Example: Building a Network

### Step 1: Alice Registers (Day 0)

```
┌─────────────────┐
│  Alice          │
│  Code: ABC123   │
│  Wallet: 0 PKR  │
└─────────────────┘
```

**Status**: Alice has referral code, no earnings yet

---

### Step 2: Bob Registers with Alice's Code (Day 3)

```
        ┌─────────────────┐
        │  Alice          │
        │  Wallet: 22 PKR │ ← Receives 22 PKR (Level 1)
        └─────────────────┘
                ↓ referred
        ┌─────────────────┐
        │  Bob            │
        │  Code: XYZ789   │
        │  Wallet: 0 PKR  │
        └─────────────────┘
```

**Distribution**:
- Alice: +22 PKR (Level 1 - direct referral)

---

### Step 3: Charlie Registers with Bob's Code (Day 5)

```
        ┌─────────────────┐
        │  Alice          │
        │  Wallet: 31 PKR │ ← +9 PKR (Level 2)
        └─────────────────┘
                ↓
        ┌─────────────────┐
        │  Bob            │
        │  Wallet: 22 PKR │ ← +22 PKR (Level 1)
        └─────────────────┘
                ↓
        ┌─────────────────┐
        │  Charlie        │
        │  Code: DEF456   │
        │  Wallet: 0 PKR  │
        └─────────────────┘
```

**Distribution**:
- Bob: +22 PKR (Level 1)
- Alice: +9 PKR (Level 2)

---

### Step 4: Full 7-Level Network Example

```
        Alice (Level 7)              Wallet: 52 PKR (+2)
          ↓
        Bob (Level 6)                Wallet: 53 PKR (+3)
          ↓
        Charlie (Level 5)            Wallet: 48 PKR (+4)
          ↓
        David (Level 4)              Wallet: 44 PKR (+5)
          ↓
        Emma (Level 3)               Wallet: 38 PKR (+7)
          ↓
        Frank (Level 2)              Wallet: 31 PKR (+9)
          ↓
        Grace (Level 1)              Wallet: 22 PKR (+22)
          ↓
        Henry (NEW) ← Registers with Grace's code
```

**When Henry registers, distribution happens:**

| Person | Level from Henry | Commission | Total Wallet |
|--------|-----------------|-----------|--------------|
| Grace | 1 | +22 PKR | 22 PKR |
| Frank | 2 | +9 PKR | 31 PKR |
| Emma | 3 | +7 PKR | 38 PKR |
| David | 4 | +5 PKR | 44 PKR |
| Charlie | 5 | +4 PKR | 48 PKR |
| Bob | 6 | +3 PKR | 53 PKR |
| Alice | 7 | +2 PKR | 52 PKR |

---

## 💰 Earning Potential Calculator

### If You Refer 5 People (Level 1)

```
You refer 5 people directly
5 × 22 PKR = 110 PKR
```

### If Each of Your 5 Referrals Refers 3 People (Level 2)

```
Your 5 referrals each bring 3 people
5 × 3 = 15 people at Level 2
15 × 9 PKR = 135 PKR

Total so far: 110 + 135 = 245 PKR
```

### Full Network Potential (Example)

```
Level 1: You refer 5 people
         5 × 22 = 110 PKR

Level 2: Each refers 3 people (5 × 3 = 15 people)
         15 × 9 = 135 PKR

Level 3: Each refers 2 people (15 × 2 = 30 people)
         30 × 7 = 210 PKR

Level 4: Each refers 2 people (30 × 2 = 60 people)
         60 × 5 = 300 PKR

Level 5: Each refers 2 people (60 × 2 = 120 people)
         120 × 4 = 480 PKR

Level 6: Each refers 1 person (120 × 1 = 120 people)
         120 × 3 = 360 PKR

Level 7: Each refers 1 person (120 × 1 = 120 people)
         120 × 2 = 240 PKR

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL POTENTIAL: 1,835 PKR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total network size: 470 people
```

---

## 🔄 Ad Watching + Commission System Integration

### Complete User Journey

```
┌────────────────────────────────────────────────────────────┐
│ DAY 0: Alice Registers                                     │
│ ─────────────────────────────────────────────────────────  │
│ ✓ Gets referral code: ABC123                               │
│ ✓ Wallet: 0 PKR                                            │
│ ✓ Can watch ads: Yes (starting anytime)                    │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ DAY 1: Alice Watches First Ad                              │
│ ─────────────────────────────────────────────────────────  │
│ ✓ Ad watching cycle starts                                 │
│ ✓ Next ad available: Day 2                                 │
│ ✓ Cycle expires: Day 8                                     │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ DAY 3: Bob Registers with Alice's Code (ABC123)            │
│ ─────────────────────────────────────────────────────────  │
│ ✓ Bob created with referral link to Alice                  │
│ ✓ Alice receives 22 PKR (Level 1 commission)               │
│ ✓ Alice's wallet: 0 → 22 PKR                               │
│ ✓ Alice's total_referrals: 0 → 1                           │
│ ✓ Alice's ad cycle: RESET! (New 7 days from Day 3)         │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ DAY 5: Charlie Registers with Bob's Code                   │
│ ─────────────────────────────────────────────────────────  │
│ ✓ Bob receives 22 PKR (Level 1)                            │
│ ✓ Alice receives 9 PKR (Level 2)                           │
│ ✓ Alice's wallet: 22 → 31 PKR                              │
│ ✓ Bob's ad cycle: RESET!                                   │
└────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────┐
│ DAY 10: Alice's New Cycle Expires (7 days after Day 3)     │
│ ─────────────────────────────────────────────────────────  │
│ ⚠ Cannot watch ads until new member added                  │
│ ✓ Wallet still accessible: 31 PKR                          │
│ ✓ Options:                                                  │
│   - Add new member to reset cycle                          │
│   - Share referral code                                     │
└────────────────────────────────────────────────────────────┘
```

---

## 📱 API Call Sequence Diagram

### New User Registration Flow

```
Frontend                Backend                  Database
   │                       │                         │
   │  POST /register       │                         │
   │  {referralCode}       │                         │
   ├──────────────────────>│                         │
   │                       │                         │
   │                       │  Find referrer          │
   │                       ├────────────────────────>│
   │                       │<────────────────────────┤
   │                       │  (referrer found)       │
   │                       │                         │
   │                       │  Create new user        │
   │                       ├────────────────────────>│
   │                       │<────────────────────────┤
   │                       │                         │
   │                       │  START TRANSACTION      │
   │                       ├────────────────────────>│
   │                       │                         │
   │                       │  Loop through 7 levels  │
   │                       │  For each ancestor:     │
   │                       │   - Create earning      │
   │                       │   - Update wallet       │
   │                       ├────────────────────────>│
   │                       │<────────────────────────┤
   │                       │                         │
   │                       │  COMMIT TRANSACTION     │
   │                       ├────────────────────────>│
   │                       │<────────────────────────┤
   │                       │                         │
   │<──────────────────────┤                         │
   │  {success, token}     │                         │
   │                       │                         │
```

---

## 🎯 Commission Distribution Algorithm

### Pseudocode

```
FUNCTION distributeReferralCommissions(newUserId, directReferrerId):
    
    commissionLevels = {
        1: 22 PKR,
        2: 9 PKR,
        3: 7 PKR,
        4: 5 PKR,
        5: 4 PKR,
        6: 3 PKR,
        7: 2 PKR
    }
    
    BEGIN TRANSACTION
        
        currentReferrerId = directReferrerId
        level = 1
        
        WHILE currentReferrerId EXISTS AND level <= 7:
            
            ancestor = FIND_USER(currentReferrerId)
            IF ancestor NOT EXISTS:
                BREAK
            
            commission = commissionLevels[level]
            
            // Create earning record
            CREATE_EARNING(
                user_id: ancestor.id,
                from_user_id: newUserId,
                amount: commission,
                level: level
            )
            
            // Update ancestor's wallet
            ancestor.wallet_balance += commission
            ancestor.total_earnings += commission
            
            IF level == 1:
                ancestor.total_referrals += 1
            
            SAVE(ancestor)
            
            // Move to next level
            currentReferrerId = ancestor.referred_by
            level += 1
        
        END WHILE
        
    COMMIT TRANSACTION
    
END FUNCTION
```

---

## 📊 Database Relationship Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                         USERS TABLE                          │
├─────────────────────────────────────────────────────────────┤
│ id                 INTEGER PRIMARY KEY                       │
│ name               VARCHAR(50)                               │
│ email              VARCHAR(100) UNIQUE                       │
│ password           VARCHAR                                   │
│ ─────────────────────────────────────────────────────────── │
│ referred_by        INTEGER → users.id (self-reference)       │
│ referral_code      VARCHAR(20) UNIQUE                        │
│ total_referrals    INTEGER DEFAULT 0                         │
│ ─────────────────────────────────────────────────────────── │
│ last_ad_watched_at        TIMESTAMP                          │
│ current_cycle_started_at  TIMESTAMP                          │
│ ─────────────────────────────────────────────────────────── │
│ wallet_balance     DECIMAL(12,2) DEFAULT 0.00                │
│ total_earnings     DECIMAL(12,2) DEFAULT 0.00                │
│ total_withdrawn    DECIMAL(12,2) DEFAULT 0.00                │
└─────────────────────────────────────────────────────────────┘
                    ↑                              ↑
                    │                              │
        ┌───────────┴──────────┐      ┌───────────┴──────────┐
        │                      │      │                      │
┌───────────────────┐  ┌───────────────────┐  ┌──────────────────┐
│   AD_VIEWS        │  │    EARNINGS       │  │      ADS         │
├───────────────────┤  ├───────────────────┤  ├──────────────────┤
│ id                │  │ id                │  │ id               │
│ user_id      ─────┼──┤ user_id      ─────┼──┤ user_id          │
│ ad_id             │  │ from_user_id      │  │ title            │
│ watched_at        │  │ amount            │  │ price            │
│ created_at        │  │ level (1-7)       │  │ status           │
└───────────────────┘  │ type              │  └──────────────────┘
                       │ description       │
                       │ status            │
                       │ created_at        │
                       └───────────────────┘
```

---

## ✨ Success Metrics

### What Success Looks Like

```
┌────────────────────────────────────────────────┐
│  USER GROWTH METRICS                           │
├────────────────────────────────────────────────┤
│  Active Users:           1,000                 │
│  Average Referrals/User: 3.5                   │
│  Network Depth:          5 levels avg          │
│  Total Ads Watched:      15,000                │
│  Total PKR Distributed:  180,000 PKR           │
└────────────────────────────────────────────────┘

┌────────────────────────────────────────────────┐
│  ENGAGEMENT METRICS                            │
├────────────────────────────────────────────────┤
│  Daily Active Users:     60%                   │
│  Weekly Ad Watchers:     85%                   │
│  Users with Referrals:   70%                   │
│  Average Wallet Balance: 180 PKR               │
└────────────────────────────────────────────────┘
```

---

## 🚀 Go Live Checklist

```
PRE-LAUNCH
□ Run all database migrations
□ Test registration with referral codes
□ Test commission distribution (all 7 levels)
□ Test ad watching (24-hour limit, 7-day cycle)
□ Verify wallet balances update correctly
□ Test earnings history API
□ Load test with multiple concurrent registrations

LAUNCH
□ Monitor server logs for errors
□ Watch database for transaction issues
□ Check first few registrations manually
□ Verify commissions distributing correctly

POST-LAUNCH
□ Daily monitoring of commission distribution
□ Weekly earning reports
□ Monthly network growth analysis
□ User feedback collection
```

---

## 📞 Quick Reference

### Commission Amounts
- Level 1: **22 PKR**
- Level 2: **9 PKR**
- Level 3: **7 PKR**
- Level 4: **5 PKR**
- Level 5: **4 PKR**
- Level 6: **3 PKR**
- Level 7: **2 PKR**

### Ad Watching Rules
- **1 ad per 24 hours**
- **7-day cycle**
- **Add member to reset cycle**

### Key API Endpoints
```
POST /api/v1/auth/register
POST /api/v1/ad-views/:adId/watch
GET  /api/v1/wallet/balance
GET  /api/v1/wallet/earnings
```

---

**Last Updated**: October 8, 2025  
**System Status**: ✅ Production Ready

