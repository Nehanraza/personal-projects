/**
 * Check Indirect Referrals Issue
 * Verifies the referral chain to find any issues
 */

require('dotenv').config();
const { sequelize, User } = require('./src/models');
const { Op } = require('sequelize');

// User details
const userEmail = 'faisalcomedychanel@gmail.com';
const userPhone = '03497210618';
console.log("test");
// Colors
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

async function checkIndirectReferralsIssue() {
  try {
    console.log(`${colors.cyan}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.cyan}║  Indirect Referrals Issue Check                       ║${colors.reset}`);
    console.log(`${colors.cyan}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    // Step 1: Find user
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: userEmail },
          { phone: userPhone }
        ]
      },
      attributes: ['id', 'name', 'email', 'phone', 'referred_by']
    });

    if (!user) {
      console.log(`${colors.red}✗ User not found${colors.reset}\n`);
      process.exit(1);
    }

    console.log(`${colors.green}✓ User found: ${user.name} (ID: ${user.id})${colors.reset}\n`);

    // Step 2: Get all referrals in the tree with their actual referred_by
    console.log(`${colors.blue}Step 2: Getting all referrals in the tree...${colors.reset}`);
    const allReferrals = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, name, email, 1 as level
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, u.name, u.email, rt.level + 1
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT id, referred_by, name, email, level
      FROM referral_tree
      ORDER BY level, id;
    `, {
      replacements: { userId: user.id },
      type: sequelize.QueryTypes.SELECT,
    });

    console.log(`   Total referrals found: ${allReferrals.length}\n`);

    // Step 3: Verify each referral's referred_by is correct
    console.log(`${colors.blue}Step 3: Verifying referral chain integrity...${colors.reset}`);
    const issues = [];
    const levelGroups = {};

    // Group by level
    allReferrals.forEach(ref => {
      const level = parseInt(ref.level);
      if (!levelGroups[level]) {
        levelGroups[level] = [];
      }
      levelGroups[level].push(ref);
    });

    // Check each level
    for (let level = 2; level <= 7; level++) {
      if (!levelGroups[level]) continue;

      console.log(`\n   ${colors.cyan}Checking Level ${level} (${levelGroups[level].length} users):${colors.reset}`);
      
      for (const ref of levelGroups[level]) {
        // Get the actual user from database
        const actualUser = await User.findByPk(ref.id, {
          attributes: ['id', 'referred_by', 'name', 'email']
        });

        if (!actualUser) {
          issues.push({
            level,
            userId: ref.id,
            issue: 'User not found in database',
            expectedReferredBy: ref.referred_by
          });
          console.log(`     ${colors.red}✗${colors.reset} ID ${ref.id}: User not found`);
          continue;
        }

        // Check if referred_by matches what we expect
        // For level 2, referred_by should be a level 1 user
        // For level 3, referred_by should be a level 2 user, etc.
        const expectedReferredBy = ref.referred_by;
        const actualReferredBy = actualUser.referred_by;

        if (actualReferredBy !== expectedReferredBy) {
          issues.push({
            level,
            userId: ref.id,
            name: ref.name,
            email: ref.email,
            issue: 'referred_by mismatch',
            expectedReferredBy: expectedReferredBy,
            actualReferredBy: actualReferredBy
          });
          console.log(`     ${colors.red}✗${colors.reset} ID ${ref.id} (${ref.name || 'N/A'}): referred_by mismatch`);
          console.log(`        Expected: ${expectedReferredBy}, Actual: ${actualReferredBy}`);
        } else {
          // Verify that the referred_by user is actually at the correct level
          const referrer = allReferrals.find(r => r.id === actualReferredBy);
          if (referrer) {
            const referrerLevel = parseInt(referrer.level);
            if (referrerLevel !== level - 1) {
              issues.push({
                level,
                userId: ref.id,
                name: ref.name,
                email: ref.email,
                issue: 'Referrer is at wrong level',
                referrerLevel: referrerLevel,
                expectedReferrerLevel: level - 1
              });
              console.log(`     ${colors.yellow}⚠${colors.reset} ID ${ref.id} (${ref.name || 'N/A'}): Referrer is at level ${referrerLevel}, expected ${level - 1}`);
            }
          } else {
            // Referrer not in tree - this is a problem
            issues.push({
              level,
              userId: ref.id,
              name: ref.name,
              email: ref.email,
              issue: 'Referrer not found in referral tree',
              referredBy: actualReferredBy
            });
            console.log(`     ${colors.red}✗${colors.reset} ID ${ref.id} (${ref.name || 'N/A'}): Referrer (${actualReferredBy}) not in tree`);
          }
        }
      }
    }

    // Step 4: Check for users that should be in the tree but aren't
    console.log(`\n${colors.blue}Step 4: Checking for missing referrals...${colors.reset}`);
    
    // Get all direct referrals
    const directReferrals = await User.findAll({
      where: { referred_by: user.id },
      attributes: ['id']
    });

    const directReferralIds = directReferrals.map(r => r.id);
    const allReferralIds = new Set(allReferrals.map(r => r.id));

    // For each direct referral, check if their referrals are in the tree
    for (const directRef of directReferrals) {
      const indirectRefs = await User.findAll({
        where: { referred_by: directRef.id },
        attributes: ['id', 'name', 'email', 'referred_by']
      });

      for (const indirectRef of indirectRefs) {
        if (!allReferralIds.has(indirectRef.id)) {
          issues.push({
            level: 'unknown',
            userId: indirectRef.id,
            name: indirectRef.name,
            email: indirectRef.email,
            issue: 'Should be in tree but missing',
            referredBy: indirectRef.referred_by
          });
          console.log(`     ${colors.red}✗${colors.reset} ID ${indirectRef.id} (${indirectRef.name || 'N/A'}): Should be in tree but missing`);
        }
      }
    }

    // Step 5: Summary
    console.log(`\n${colors.magenta}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}║  SUMMARY                                              ║${colors.reset}`);
    console.log(`${colors.magenta}╚════════════════════════════════════════════════════════╝${colors.reset}`);
    
    if (issues.length === 0) {
      console.log(`   ${colors.green}✓ No issues found! All indirect referrals are correctly linked.${colors.reset}\n`);
    } else {
      console.log(`   ${colors.red}✗ Found ${issues.length} issue(s):${colors.reset}\n`);
      issues.forEach((issue, index) => {
        console.log(`   ${index + 1}. Level ${issue.level}, User ID ${issue.userId} (${issue.name || 'N/A'}): ${issue.issue}`);
        if (issue.expectedReferredBy !== undefined) {
          console.log(`      Expected referred_by: ${issue.expectedReferredBy}, Actual: ${issue.actualReferredBy}`);
        }
      });
      console.log('');
    }

    // Step 6: Count by level
    console.log(`${colors.cyan}Referral Counts by Level:${colors.reset}`);
    Object.keys(levelGroups).sort((a, b) => parseInt(a) - parseInt(b)).forEach(level => {
      const count = levelGroups[level].length;
      const label = level === '1' ? 'Direct' : 'Indirect';
      console.log(`   Level ${level} (${label}): ${count} users`);
    });
    console.log('');

    await sequelize.close();
    console.log(`${colors.green}✓ Database connection closed${colors.reset}\n`);

  } catch (error) {
    console.error(`${colors.red}✗ Error: ${error.message}${colors.reset}`);
    console.error(error);
    await sequelize.close();
    process.exit(1);
  }
}

// Run the check
if (require.main === module) {
  checkIndirectReferralsIssue();
}

module.exports = { checkIndirectReferralsIssue };

