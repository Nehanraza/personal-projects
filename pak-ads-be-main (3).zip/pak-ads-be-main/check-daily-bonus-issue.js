/**
 * Check Daily Bonus Issue for User
 * Verifies how referrals are counted in status API vs auto-award
 */

require('dotenv').config();
const { sequelize, User, Deposit, DailyReferralBonus } = require('./src/models');
const { Op } = require('sequelize');

// Colors
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
  bold: '\x1b[1m',
};

async function checkDailyBonusIssue() {
  try {
    console.log(`${colors.cyan}${colors.bold}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.cyan}${colors.bold}║  DAILY BONUS ISSUE CHECK                            ║${colors.reset}`);
    console.log(`${colors.cyan}${colors.bold}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    const userEmail = 'faisalcomedychanel@gmail.com';
    const user = await User.findOne({
      where: { email: userEmail },
      attributes: ['id', 'name', 'email', 'wallet_balance', 'total_earnings']
    });

    if (!user) {
      console.log(`${colors.red}✗ User not found${colors.reset}\n`);
      process.exit(1);
    }

    console.log(`${colors.green}✓ User found: ${user.name} (ID: ${user.id})${colors.reset}\n`);

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999);

    console.log(`${colors.blue}${colors.bold}Today's Date Range:${colors.reset}`);
    console.log(`   From: ${today.toISOString()}`);
    console.log(`   To: ${endOfDay.toISOString()}\n`);

    // Method 1: Count by user creation date (CURRENT STATUS API METHOD - WRONG)
    const referralsByCreationDate = await User.count({
      where: {
        referred_by: user.id,
        created_at: {
          [Op.between]: [today, endOfDay],
        },
      },
    });

    console.log(`${colors.yellow}${colors.bold}Method 1: Count by User Creation Date (CURRENT - WRONG)${colors.reset}`);
    console.log(`   Referrals counted: ${referralsByCreationDate}\n`);

    // Method 2: Count by deposit approval date (CORRECT METHOD)
    const referralsByDepositApproval = await Deposit.count({
      include: [
        {
          model: User,
          as: 'user',
          where: {
            referred_by: user.id,
          },
          attributes: [],
        },
      ],
      where: {
        status: 'approved',
        approved_at: {
          [Op.between]: [today, endOfDay],
        },
      },
      distinct: true,
      col: 'user_id',
    });

    console.log(`${colors.green}${colors.bold}Method 2: Count by Deposit Approval Date (CORRECT)${colors.reset}`);
    console.log(`   Referrals counted: ${referralsByDepositApproval}\n`);

    // Get detailed referral list
    console.log(`${colors.cyan}${colors.bold}Detailed Referral List:${colors.reset}\n`);

    const allReferrals = await User.findAll({
      where: {
        referred_by: user.id,
        created_at: {
          [Op.between]: [today, endOfDay],
        },
      },
      attributes: ['id', 'name', 'email', 'created_at'],
      include: [
        {
          model: Deposit,
          as: 'deposits',
          attributes: ['id', 'status', 'approved_at', 'amount'],
          required: false,
        },
      ],
      order: [['created_at', 'DESC']],
    });

    console.log(`${colors.cyan}Referrals Created Today (by creation date):${colors.reset}`);
    allReferrals.forEach((ref, idx) => {
      const deposits = ref.deposits || [];
      const approvedDeposit = deposits.find(d => d.status === 'approved');
      const hasApprovedDeposit = !!approvedDeposit;
      const approvedToday = approvedDeposit && 
        new Date(approvedDeposit.approved_at) >= today && 
        new Date(approvedDeposit.approved_at) <= endOfDay;

      console.log(`\n   ${idx + 1}. ${ref.name} (${ref.email})`);
      console.log(`      Created: ${ref.created_at}`);
      console.log(`      Has Approved Deposit: ${hasApprovedDeposit ? colors.green + 'YES' + colors.reset : colors.red + 'NO' + colors.reset}`);
      if (approvedDeposit) {
        console.log(`      Approved At: ${approvedDeposit.approved_at}`);
        console.log(`      Approved Today: ${approvedToday ? colors.green + 'YES' + colors.reset : colors.yellow + 'NO (approved on different day)' + colors.reset}`);
        console.log(`      Amount: ${approvedDeposit.amount} PKR`);
      } else {
        console.log(`      ${colors.red}No approved deposit yet${colors.reset}`);
      }
    });

    // Check existing bonus
    const existingBonus = await DailyReferralBonus.findOne({
      where: {
        user_id: user.id,
        bonus_date: today,
      },
    });

    console.log(`\n${colors.cyan}${colors.bold}Today's Bonus Status:${colors.reset}`);
    if (existingBonus) {
      console.log(`   Bonus Awarded: ${colors.green}YES${colors.reset}`);
      console.log(`   Bonus Count: ${existingBonus.bonus_count}`);
      console.log(`   Bonus Amount: ${existingBonus.bonus_amount} PKR`);
      console.log(`   Referrals Count (in bonus record): ${existingBonus.referrals_count}`);
    } else {
      console.log(`   Bonus Awarded: ${colors.yellow}NO${colors.reset}`);
    }

    // Summary
    console.log(`\n${colors.magenta}${colors.bold}╔════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}║  ISSUE SUMMARY                                    ║${colors.reset}`);
    console.log(`${colors.magenta}${colors.bold}╚════════════════════════════════════════════════════════╝${colors.reset}\n`);

    console.log(`${colors.red}${colors.bold}PROBLEM:${colors.reset}`);
    console.log(`   Status API counts referrals by: ${colors.yellow}User Creation Date${colors.reset}`);
    console.log(`   Auto-award counts referrals by: ${colors.green}Deposit Approval Date${colors.reset}`);
    console.log(`   ${colors.red}These don't match!${colors.reset}\n`);

    console.log(`${colors.yellow}Current Status API shows:${colors.reset} ${referralsByCreationDate} referrals`);
    console.log(`${colors.green}Auto-award will count:${colors.reset} ${referralsByDepositApproval} referrals\n`);

    if (referralsByCreationDate !== referralsByDepositApproval) {
      console.log(`${colors.red}✗ MISMATCH DETECTED!${colors.reset}`);
      console.log(`   Progress bar shows ${referralsByCreationDate} referrals`);
      console.log(`   But bonus is only awarded for ${referralsByDepositApproval} approved referrals`);
      console.log(`   ${colors.yellow}This causes confusion!${colors.reset}\n`);
    } else {
      console.log(`${colors.green}✓ Counts match (but still wrong method)${colors.reset}\n`);
    }

    console.log(`${colors.green}${colors.bold}SOLUTION:${colors.reset}`);
    console.log(`   Fix status API to count by deposit approval date`);
    console.log(`   This will match the auto-award logic\n`);

    await sequelize.close();

  } catch (error) {
    console.error(`${colors.red}✗ Error: ${error.message}${colors.reset}`);
    console.error(error);
    await sequelize.close();
    process.exit(1);
  }
}

// Run
if (require.main === module) {
  checkDailyBonusIssue();
}

module.exports = { checkDailyBonusIssue };

