# 🔄 Daily Bonus Chart Reset - Frontend Implementation Guide

## 📋 Owner's Request

**"Ya bonus chart reset nhi ho rha plz iska timer lgay ya rat ko daily 12 bjy reset ho jaiy"**

Translation: "This bonus chart is not resetting, please set a timer for it or make it reset daily at 12 AM."

---

## ✅ Answer: **YES, This is Mainly Frontend Work!**

### 🎯 Summary

**Backend Already Works Correctly:**
- ✅ Backend automatically calculates "today" based on midnight (12 AM)
- ✅ API already returns fresh data for each new day
- ✅ No backend changes needed for reset logic

**Frontend Needs to:**
1. ✅ Refresh data when app opens/becomes active
2. ✅ Set up timer to check at midnight (12 AM) and refresh
3. ✅ Detect when date changes and reset UI state
4. ✅ Call status API periodically to get fresh data

---

## 🔧 Backend Enhancement (Already Done)

I've added `currentDate` field to the status API response so frontend can easily detect when date changes:

### API Response Now Includes:
```json
{
  "success": true,
  "data": {
    "currentDate": "2024-01-15",  // ← NEW: Use this to detect date changes
    "todayReferrals": 8,
    "bonusAwarded": true,
    "bonusAwardedCount": 3,
    // ... rest of the data
  }
}
```

---

## 📱 Frontend Implementation (Required)

### **Method 1: Timer-Based Reset (Recommended)**

Set up a timer that checks at midnight and refreshes the data:

```javascript
// React/React Native Example
import { useEffect, useState, useRef } from 'react';

function DailyBonusChart() {
  const [status, setStatus] = useState(null);
  const [lastDate, setLastDate] = useState(null);
  const midnightTimerRef = useRef(null);

  // Fetch status from API
  const fetchStatus = async () => {
    try {
      const response = await fetch('/api/daily-referral-bonus/status', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      
      if (data.success) {
        const currentDate = data.data.currentDate;
        
        // If date changed, reset everything
        if (lastDate && lastDate !== currentDate) {
          // Date changed! Reset UI
          console.log('New day detected! Resetting bonus chart...');
          // Reset all UI state
        }
        
        setLastDate(currentDate);
        setStatus(data.data);
      }
    } catch (error) {
      console.error('Error fetching status:', error);
    }
  };

  // Set up midnight timer
  useEffect(() => {
    const setupMidnightTimer = () => {
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0); // Next midnight
      
      const msUntilMidnight = tomorrow.getTime() - now.getTime();
      
      // Clear existing timer
      if (midnightTimerRef.current) {
        clearTimeout(midnightTimerRef.current);
      }
      
      // Set timer for midnight
      midnightTimerRef.current = setTimeout(() => {
        console.log('Midnight reached! Refreshing bonus chart...');
        fetchStatus(); // Refresh data at midnight
        
        // Schedule next midnight check
        setupMidnightTimer();
      }, msUntilMidnight);
      
      console.log(`Next refresh scheduled in ${msUntilMidnight / 1000 / 60} minutes`);
    };
    
    // Initial fetch
    fetchStatus();
    
    // Set up midnight timer
    setupMidnightTimer();
    
    // Cleanup on unmount
    return () => {
      if (midnightTimerRef.current) {
        clearTimeout(midnightTimerRef.current);
      }
    };
  }, []);

  // Also check when app becomes active (user returns to app)
  useEffect(() => {
    const handleAppActive = () => {
      fetchStatus(); // Refresh when app becomes active
    };
    
    // React Native: AppState
    // Web: visibilitychange or focus events
    window.addEventListener('focus', handleAppActive);
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        handleAppActive();
      }
    });
    
    return () => {
      window.removeEventListener('focus', handleAppActive);
      document.removeEventListener('visibilitychange', handleAppActive);
    };
  }, []);

  // Render your bonus chart UI here using status data
  // ...
}
```

### **Method 2: Periodic Polling (Simple Alternative)**

Poll the API every few minutes and check if date changed:

```javascript
useEffect(() => {
  const fetchStatus = async () => {
    const response = await fetch('/api/daily-referral-bonus/status', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await response.json();
    
    if (data.success) {
      const currentDate = data.data.currentDate;
      
      // Check if date changed
      if (lastDate && lastDate !== currentDate) {
        // New day! Reset UI
        console.log('New day detected!');
        // Reset all progress bars, completed states, etc.
      }
      
      setLastDate(currentDate);
      setStatus(data.data);
    }
  };
  
  // Fetch immediately
  fetchStatus();
  
  // Poll every 5 minutes
  const interval = setInterval(fetchStatus, 5 * 60 * 1000);
  
  return () => clearInterval(interval);
}, [lastDate]);
```

### **Method 3: Date Change Detection (Most Efficient)**

Compare dates and only refresh when date actually changes:

```javascript
useEffect(() => {
  const checkDateChange = () => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    
    // Get last checked date from localStorage or state
    const lastCheckedDate = localStorage.getItem('lastBonusDate');
    
    if (lastCheckedDate !== today) {
      // Date changed! Refresh data
      console.log('New day detected! Refreshing...');
      fetchStatus();
      localStorage.setItem('lastBonusDate', today);
    }
  };
  
  // Check on mount
  checkDateChange();
  
  // Check every minute
  const interval = setInterval(checkDateChange, 60 * 1000);
  
  return () => clearInterval(interval);
}, []);
```

---

## 🎨 UI Reset Logic

When date changes, reset these UI elements:

```javascript
const resetUI = () => {
  // Reset progress bars
  setProgressBars([0, 0, 0]);
  
  // Reset completed states
  setCompletedTargets([false, false, false]);
  
  // Reset collected bonuses display
  setCollectedBonuses([]);
  
  // Reset referral counts
  setTodayReferrals(0);
  
  // Clear any cached data
  localStorage.removeItem('bonusChartCache');
};
```

---

## 📡 API Endpoint

**GET** `/api/daily-referral-bonus/status`

**Response:**
```json
{
  "success": true,
  "data": {
    "currentDate": "2024-01-15",           // ← Use this to detect date changes
    "todayReferrals": 8,
    "bonusAwarded": true,
    "bonusAwardedCount": 3,
    "bonusAwardedAmount": {
      "pkr": 849,
      "usd": 3.00
    },
    "potentialBonus": {
      "count": 3,
      "amount": {
        "pkr": 849,
        "usd": 3.00
      },
      "breakdown": [
        {
          "bonusNumber": 1,
          "thresholdReached": 3,
          "bonusAmount": 283,
          "description": "First bonus for 3 referrals"
        },
        {
          "bonusNumber": 2,
          "thresholdReached": 6,
          "bonusAmount": 283,
          "description": "Second bonus for 6 referrals"
        },
        {
          "bonusNumber": 3,
          "thresholdReached": 8,
          "bonusAmount": 283,
          "description": "Third bonus for 8 referrals"
        }
      ]
    },
    "progress": {
      "toNextBonus": 0,
      "referralsNeeded": 0
    },
    "bonusRules": {
      "firstBonusThreshold": 3,
      "subsequentBonusThreshold": 3,
      "bonusAmount": {
        "pkr": 283,
        "usd": 1.00
      }
    }
  }
}
```

---

## ✅ Checklist for Frontend Developer

- [ ] Set up midnight timer to refresh data at 12 AM
- [ ] Detect date changes using `currentDate` from API
- [ ] Reset all UI progress bars when date changes
- [ ] Reset completed target states
- [ ] Clear collected bonuses display
- [ ] Refresh data when app becomes active/focused
- [ ] Handle edge cases (app closed at midnight, timezone changes, etc.)

---

## 🌍 Timezone Considerations

**Important:** Backend uses server timezone. If your app shows different timezone, make sure to:
- Use server's `currentDate` field (not client date)
- Don't rely on client-side date calculations for reset logic
- Always use API's `currentDate` to determine if reset should happen

---

## 🎯 Summary

**Owner's Question:** "Ye kam frontend say ho ga?"

**Answer:** **Haan, yeh primarily frontend ka kaam hai!**

1. ✅ Backend already correctly handles daily reset (midnight calculation)
2. ✅ Backend API now includes `currentDate` field for easy detection
3. ⚠️ Frontend needs to:
   - Set up midnight timer
   - Refresh data when date changes
   - Reset UI state when new day starts

**Expected Behavior:**
- At 12:00 AM (midnight), bonus chart should automatically reset
- All progress bars should go back to 0
- All completed targets should show as incomplete
- New day's data should load automatically

---

## 📞 Support

If frontend developer needs help, they can:
1. Use the `currentDate` field from API to detect date changes
2. Implement any of the 3 methods above (timer-based is recommended)
3. Test by changing device time or waiting for midnight

---

**Status:** ✅ Backend ready, waiting for frontend implementation

