# Quick Setup Guide - Ad Watching & Referral System

## Overview
This guide will help you set up and test the new Ad Watching and Referral System.

---

## Step 1: Run Database Migrations

The new feature requires database schema changes. Run the migrations:

```bash
npm run db:migrate
```

This will:
- Add referral and ad watching fields to the `users` table
- Create a new `ad_views` table to track ad watching history

**New Fields in Users Table:**
- `referred_by` - ID of user who referred this user
- `referral_code` - Unique 8-character code for each user
- `last_ad_watched_at` - Timestamp of last ad watch
- `current_cycle_started_at` - Start of current 7-day cycle
- `total_referrals` - Count of users referred

---

## Step 2: Restart the Server

After running migrations, restart your server:

```bash
npm run dev
```

---

## Step 3: Test the Feature

### A. Test User Registration

Register a new user (they will automatically get a referral code):

```bash
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Alice Johnson",
    "email": "alice@test.com",
    "password": "password123",
    "phone": "+1234567890"
  }'
```

**Expected Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "name": "Alice Johnson",
    "email": "alice@test.com",
    "role": "user",
    "referralCode": "A1B2C3D4",  // ← Unique code generated
    "totalReferrals": 0
  }
}
```

**Save the referral code!** You'll need it for testing referrals.

---

### B. Register Second User with Referral Code

Now register another user using the first user's referral code:

```bash
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Bob Smith",
    "email": "bob@test.com",
    "password": "password123",
    "phone": "+0987654321",
    "referralCode": "A1B2C3D4"
  }'
```

This will:
- Create Bob's account
- Link Bob to Alice (Alice referred Bob)
- Give Bob his own referral code
- Increment Alice's `total_referrals` counter

---

### C. Check Ad Watching Status

Get the current ad watching status:

```bash
curl -X GET http://localhost:4000/api/v1/ad-views/status \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**First Time Response:**
```json
{
  "success": true,
  "data": {
    "canWatchAd": true,
    "cycleStartDate": null,
    "lastAdWatchedAt": null,
    "totalReferrals": 0,
    "referralCode": "A1B2C3D4",
    "daysRemainingInCycle": 7,
    "message": "You can watch your first ad now!",
    "referrals": []
  }
}
```

---

### D. Watch an Ad

First, make sure you have some ads in the database. Then watch an ad:

```bash
curl -X POST http://localhost:4000/api/v1/ad-views/1/watch \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Success Response:**
```json
{
  "success": true,
  "message": "Ad watched successfully",
  "data": {
    "adId": 1,
    "watchedAt": "2025-10-08T10:30:00.000Z",
    "nextAdAvailableAt": "2025-10-09T10:30:00.000Z",
    "adWatchingStatus": {
      "canWatchAd": false,
      "cycleStartDate": "2025-10-08T10:30:00.000Z",
      "lastAdWatchedAt": "2025-10-08T10:30:00.000Z",
      "message": "You can watch your next ad in 24.0 hours.",
      "hoursUntilNextAd": 24.0,
      "daysRemainingInCycle": 7
    }
  }
}
```

---

### E. Try to Watch Another Ad Immediately

Try to watch another ad before 24 hours:

```bash
curl -X POST http://localhost:4000/api/v1/ad-views/2/watch \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected Error:**
```json
{
  "success": false,
  "message": "You can watch your next ad in 23.8 hours.",
  "reason": "too_soon",
  "data": {
    "canWatch": false,
    "reason": "too_soon",
    "hoursRemaining": 23.8
  }
}
```

---

### F. Get Referral Information

Check who you've referred and who referred you:

```bash
curl -X GET http://localhost:4000/api/v1/ad-views/referral-info \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "referralCode": "A1B2C3D4",
    "totalReferrals": 1,
    "referrals": [
      {
        "id": 2,
        "name": "Bob Smith",
        "email": "bob@test.com",
        "createdAt": "2025-10-08T10:00:00.000Z"
      }
    ],
    "referredBy": null
  }
}
```

---

### G. Get Ad Watching History

View all the ads you've watched:

```bash
curl -X GET http://localhost:4000/api/v1/ad-views/history?page=1&limit=10 \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "history": [
      {
        "id": 1,
        "user_id": 1,
        "ad_id": 1,
        "watched_at": "2025-10-08T10:30:00.000Z",
        "ad": {
          "id": 1,
          "title": "iPhone 13 Pro",
          "price": "999.00",
          "user": {
            "name": "Seller Name"
          }
        }
      }
    ],
    "pagination": {
      "currentPage": 1,
      "totalPages": 1,
      "totalRecords": 1,
      "limit": 10
    }
  }
}
```

---

## Testing the 7-Day Cycle Feature

### Option 1: Manual Testing (for production-like testing)

1. Watch an ad to start the cycle
2. Wait 24 hours and watch another ad
3. Repeat for 7 days
4. On day 8, try to watch an ad → should get "cycle_expired" error
5. Add a new member to reset the cycle

### Option 2: Database Testing (for quick testing)

Manually update the `current_cycle_started_at` field in the database to simulate 7 days passing:

```sql
-- Simulate 8 days have passed (cycle expired)
UPDATE users 
SET current_cycle_started_at = NOW() - INTERVAL '8 days'
WHERE email = 'alice@test.com';
```

Now try to watch an ad:

```bash
curl -X POST http://localhost:4000/api/v1/ad-views/1/watch \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected Error:**
```json
{
  "success": false,
  "message": "Your 7-day cycle has expired. Please add a new member to continue watching ads.",
  "reason": "cycle_expired",
  "data": {
    "canWatch": false,
    "daysExpired": 1
  }
}
```

---

## Adding a Member to Reset Cycle

When the cycle expires, add a new member to reset it:

```bash
curl -X POST http://localhost:4000/api/v1/ad-views/add-member \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "referralCode": "X9Y8Z7W6"
  }'
```

**Success Response:**
```json
{
  "success": true,
  "message": "Member added successfully! Your 7-day cycle has been reset.",
  "data": {
    "totalReferrals": 2,
    "newCycleStartDate": "2025-10-08T11:00:00.000Z",
    "adWatchingStatus": {
      "canWatchAd": true,
      "daysRemainingInCycle": 7,
      "message": "You can watch an ad now!"
    }
  }
}
```

---

## Verification Checklist

✅ **Users get referral codes on registration**
- Check: Response includes `referralCode` field

✅ **Users can register with referral codes**
- Register User A
- Register User B with User A's code
- Check: User B's `referred_by` = User A's ID

✅ **Users can watch 1 ad per 24 hours**
- Watch an ad
- Try to watch another immediately
- Check: Get "too_soon" error

✅ **Cycle starts on first ad watch**
- Watch first ad
- Check status: `cycleStartDate` is set

✅ **Cycle expires after 7 days**
- Simulate 8 days passing (update DB)
- Try to watch ad
- Check: Get "cycle_expired" error

✅ **Adding member resets cycle**
- After cycle expires
- Add a new member
- Check: `current_cycle_started_at` is reset to now
- Can watch ads again

✅ **Users cannot watch own ads**
- Create an ad
- Try to watch your own ad
- Check: Get error "You cannot watch your own ad"

---

## API Endpoints Summary

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/auth/register` | POST | Register with optional referral code |
| `/api/v1/ad-views/:adId/watch` | POST | Watch an ad |
| `/api/v1/ad-views/status` | GET | Get ad watching status |
| `/api/v1/ad-views/history` | GET | Get ad watching history |
| `/api/v1/ad-views/add-member` | POST | Add a new member (reset cycle) |
| `/api/v1/ad-views/referral-info` | GET | Get referral information |

---

## Common Issues & Solutions

### Issue: "User not found" error
**Solution**: Make sure you're using a valid JWT token. Login again if needed.

### Issue: "Ad not found" error
**Solution**: Make sure the ad ID exists in the database. Create some test ads first.

### Issue: "Invalid referral code" error
**Solution**: Double-check the referral code is correct and hasn't been used.

### Issue: Migrations fail
**Solution**: 
1. Check database connection
2. Make sure previous migrations ran successfully
3. Check migration file names are in correct sequence

---

## Next Steps

1. **Frontend Integration**: Use the API endpoints in your frontend
2. **Email Notifications**: Add email alerts when cycle is about to expire
3. **Analytics**: Track which ads are being watched most
4. **UI/UX**: Create intuitive interface for sharing referral codes

---

## Support

For detailed API documentation, see `AD_WATCHING_REFERRAL_SYSTEM.md`

For general API documentation, see `API_DOCUMENTATION.md`

**Last Updated**: October 8, 2025

