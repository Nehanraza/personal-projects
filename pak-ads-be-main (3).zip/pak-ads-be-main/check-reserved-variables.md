# 🔍 Vercel Reserved Variables - Troubleshooting

## ⚠️ Common Reserved Variables in Vercel

These variable names are **RESERVED** by Vercel and will cause errors:

### **System Reserved:**
- ❌ `PORT`
- ❌ `HOST`
- ❌ `PATH`
- ❌ `HOME`
- ❌ `USER`
- ❌ `PWD`
- ❌ `SHELL`
- ❌ `LANG`

### **Vercel Specific:**
- ❌ `VERCEL`
- ❌ `VERCEL_ENV`
- ❌ `VERCEL_URL`
- ❌ `VERCEL_REGION`
- ❌ `NOW_REGION`

---

## 🔍 Which Variable is Causing Your Error?

Let me check each variable in your list:

### **Your Variables:**
1. `DB_CONNECTION` ✅ OK
2. `DB_HOST` ⚠️ **MIGHT BE RESERVED** (HOST is reserved)
3. `DB_PORT` ✅ OK
4. `DB_DATABASE` ✅ OK
5. `DB_USERNAME` ✅ OK
6. `DB_PASSWORD` ✅ OK
7. `JWT_SECRET` ✅ OK
8. `JWT_EXPIRES_IN` ✅ OK
9. `SMTP_HOST` ⚠️ **MIGHT BE RESERVED** (HOST is reserved)
10. `SMTP_PORT` ✅ OK
11. `SMTP_USER` ⚠️ **MIGHT BE RESERVED** (USER is reserved)
12. `SMTP_PASSWORD` ✅ OK
13. `FROM_NAME` ✅ OK
14. `FROM_EMAIL` ✅ OK
15. `NODE_ENV` ✅ OK
16. `TZ` ✅ OK
17. `LOG_LEVEL` ✅ OK
18. `FORCE_SYNC` ✅ OK
19. `CORS_ORIGIN` ✅ OK

---

## 🎯 Likely Culprits:

1. **`DB_HOST`** - Contains "HOST"
2. **`SMTP_HOST`** - Contains "HOST"
3. **`SMTP_USER`** - Contains "USER"

---

## ✅ SOLUTION: Use Alternative Names

### **Option 1: Rename Variables**

Instead of:
```
DB_HOST → DATABASE_HOST
SMTP_HOST → EMAIL_HOST
SMTP_USER → EMAIL_USER
```

### **Option 2: Use Prefixes**

Instead of:
```
DB_HOST → POSTGRES_HOST
SMTP_HOST → MAIL_HOST
SMTP_USER → MAIL_USER
```

---

## 🔧 Try Adding Variables One by One

To find which one is causing the error:

1. Add `DB_CONNECTION` → Works?
2. Add `DB_HOST` → Error? (This is likely the culprit)
3. If error on `DB_HOST`, use `DATABASE_HOST` instead

---

## 📝 Recommended Variable Names (Safe)

Use these names to avoid conflicts:

```
1. DB_CONNECTION = postgres
2. DATABASE_HOST = ep-steep-haze-ado7ayxh-pooler.c-2.us-east-1.aws.neon.tech
3. DB_PORT = 5432
4. DB_DATABASE = neondb
5. DB_USERNAME = neondb_owner
6. DB_PASSWORD = npg_Tm2BZJcYjgw7

7. JWT_SECRET = 26253f321676bc0e3f6b621ac70ce69cde98048c30fac41589e9630171cf53293fafbe18d794f1f8a3316a6a22a04d15e56e064a454a96c6106020f0681c0a1c
8. JWT_EXPIRES_IN = 7d

9. EMAIL_HOST = smtp.gmail.com
10. EMAIL_PORT = 587
11. EMAIL_USER = faisalcomedychanel@gmail.com
12. EMAIL_PASSWORD = faisal0618
13. FROM_NAME = Pak Ads
14. FROM_EMAIL = faisalcomedychanel@gmail.com

15. NODE_ENV = production
16. TZ = Asia/Karachi
17. LOG_LEVEL = info
18. FORCE_SYNC = false
19. CORS_ORIGIN = *
```

---

## ⚠️ If Using Different Names, Update Code!

If you change variable names, you need to update your code too.

