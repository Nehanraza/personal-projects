/**
 * Script to check user's rank rewards, balance, and earnings
 * Usage: node check-user-rank-rewards.js
 */

require('dotenv').config();
const { User, Earning, RankReward, Deposit } = require('./src/models');
const { sequelize } = require('./src/config/database');
const { Op } = require('sequelize');
const constants = require('./src/config/constants');

async function checkUserDetails() {
  try {
    const email = 'faisalcomedychanel@gmail.com';
    const phone = '03497210618';

    console.log('\n========================================');
    console.log('🔍 USER RANK REWARD VERIFICATION');
    console.log('========================================\n');

    // Find user by email or phone
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: email },
          { phone: phone }
        ]
      }
    });

    if (!user) {
      console.log('❌ User not found!');
      return;
    }

    console.log('✅ USER FOUND:');
    console.log(`   ID: ${user.id}`);
    console.log(`   Name: ${user.name}`);
    console.log(`   Email: ${user.email}`);
    console.log(`   Phone: ${user.phone}`);
    console.log(`   Referred By: ${user.referred_by || 'None'}`);
    console.log(`   Created At: ${user.created_at}`);

    // Get user's direct referrals count
    const directReferralsCount = await User.count({
      where: { referred_by: user.id }
    });

    console.log(`\n📊 REFERRAL STATS:`);
    console.log(`   Total Referrals (direct): ${directReferralsCount}`);
    console.log(`   Total Referrals (user.total_referrals): ${user.total_referrals || 0}`);

    // Get current balance
    console.log(`\n💰 CURRENT BALANCE:`);
    console.log(`   Wallet Balance: ${parseFloat(user.wallet_balance || 0)} PKR (${constants.convertPkrToUsd(parseFloat(user.wallet_balance || 0))} USD)`);
    console.log(`   Total Earnings: ${parseFloat(user.total_earnings || 0)} PKR (${constants.convertPkrToUsd(parseFloat(user.total_earnings || 0))} USD)`);
    console.log(`   Total Withdrawn: ${parseFloat(user.total_withdrawn || 0)} PKR (${constants.convertPkrToUsd(parseFloat(user.total_withdrawn || 0))} USD)`);

    // Check if user has approved deposit
    const approvedDeposits = await Deposit.count({
      where: {
        user_id: user.id,
        status: 'approved'
      }
    });

    console.log(`\n💳 DEPOSIT STATUS:`);
    console.log(`   Approved Deposits: ${approvedDeposits}`);
    console.log(`   Has Approved Deposit: ${approvedDeposits > 0 ? '✅ YES' : '❌ NO'}`);

    // Get all rank rewards claimed
    const rankRewards = await RankReward.findAll({
      where: { user_id: user.id },
      order: [['rank', 'ASC']],
      include: [
        {
          model: Earning,
          as: 'earning',
          attributes: ['id', 'amount', 'description', 'created_at', 'status']
        }
      ]
    });

    console.log(`\n🏆 RANK REWARDS CLAIMED:`);
    if (rankRewards.length === 0) {
      console.log('   ❌ No rank rewards claimed yet!');
    } else {
      let totalRankRewards = 0;
      rankRewards.forEach(reward => {
        const amount = parseFloat(reward.reward_amount);
        totalRankRewards += amount;
        console.log(`   ✅ Rank ${reward.rank} (${reward.rank_name}):`);
        console.log(`      - Required: ${reward.required_members} members`);
        console.log(`      - Actual: ${reward.actual_members} members`);
        console.log(`      - Reward: ${amount} PKR (${parseFloat(reward.reward_amount_usd)} USD)`);
        console.log(`      - Claimed At: ${reward.claimed_at}`);
        console.log(`      - Earning ID: ${reward.earning_id}`);
        if (reward.earning) {
          console.log(`      - Earning Status: ${reward.earning.status}`);
          console.log(`      - Earning Amount: ${parseFloat(reward.earning.amount)} PKR`);
        }
        console.log('');
      });
      console.log(`   📊 Total Rank Rewards: ${totalRankRewards} PKR (${constants.convertPkrToUsd(totalRankRewards)} USD)`);
    }

    // Check eligible ranks
    console.log(`\n🎯 ELIGIBLE RANKS (Based on ${directReferralsCount} direct referrals):`);
    const ranks = constants.RANK_REWARDS;
    let highestEligibleRank = null;
    
    for (const [rankNumber, rankData] of Object.entries(ranks)) {
      const isEligible = directReferralsCount >= rankData.members;
      const isClaimed = rankRewards.some(r => r.rank === parseInt(rankNumber));
      const status = isClaimed ? '✅ CLAIMED' : (isEligible ? '⚠️  ELIGIBLE (NOT CLAIMED)' : '❌ Not Eligible');
      
      console.log(`   ${status} - Rank ${rankNumber}: ${rankData.members} members → ${rankData.rewardUSD} USD (${rankData.rewardPKR} PKR)`);
      
      if (isEligible && !isClaimed) {
        highestEligibleRank = {
          rank: parseInt(rankNumber),
          ...rankData
        };
      }
    }

    if (highestEligibleRank && !rankRewards.some(r => r.rank === highestEligibleRank.rank)) {
      console.log(`\n⚠️  WARNING: User is eligible for ${highestEligibleRank.name} but hasn't claimed it!`);
      console.log(`   User has ${directReferralsCount} referrals, needs ${highestEligibleRank.members}`);
      console.log(`   Should receive: ${highestEligibleRank.rewardUSD} USD (${highestEligibleRank.rewardPKR} PKR)`);
    }

    // Get all earnings by type
    console.log(`\n📈 EARNINGS BREAKDOWN:`);
    const earningsByType = await Earning.findAll({
      where: { 
        user_id: user.id,
        status: 'completed'
      },
      attributes: [
        'type',
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['type'],
      raw: true,
    });

    let totalEarningsFromDB = 0;
    earningsByType.forEach(item => {
      const total = parseFloat(item.total || 0);
      totalEarningsFromDB += total;
      console.log(`   ${item.type}: ${total} PKR (${item.count} transactions)`);
    });
    console.log(`\n   📊 Total Earnings (from DB): ${totalEarningsFromDB} PKR`);

    // Get rank_reward type earnings specifically
    const rankRewardEarnings = await Earning.findAll({
      where: {
        user_id: user.id,
        type: 'rank_reward',
        status: 'completed'
      },
      order: [['created_at', 'DESC']]
    });

    console.log(`\n🏆 RANK REWARD EARNINGS (from earnings table):`);
    if (rankRewardEarnings.length === 0) {
      console.log('   ❌ No rank_reward type earnings found!');
    } else {
      let totalFromEarnings = 0;
      rankRewardEarnings.forEach(earning => {
        const amount = parseFloat(earning.amount);
        totalFromEarnings += amount;
        console.log(`   ✅ ${earning.description}`);
        console.log(`      Amount: ${amount} PKR`);
        console.log(`      Level: ${earning.level}`);
        console.log(`      Status: ${earning.status}`);
        console.log(`      Created: ${earning.created_at}`);
        console.log('');
      });
      console.log(`   📊 Total from earnings: ${totalFromEarnings} PKR`);
    }

    // Verification
    console.log(`\n✅ VERIFICATION:`);
    const totalRankRewardsAmount = rankRewards.reduce((sum, r) => sum + parseFloat(r.reward_amount), 0);
    const totalRankEarningsAmount = rankRewardEarnings.reduce((sum, e) => sum + parseFloat(e.amount), 0);
    
    console.log(`   Rank Rewards Total (from rank_rewards table): ${totalRankRewardsAmount} PKR`);
    console.log(`   Rank Rewards Total (from earnings table): ${totalRankEarningsAmount} PKR`);
    console.log(`   Match: ${totalRankRewardsAmount === totalRankEarningsAmount ? '✅ YES' : '❌ NO'}`);
    
    console.log(`\n   Expected in wallet (if all rewards added): ${totalRankRewardsAmount} PKR`);
    console.log(`   Current wallet balance: ${parseFloat(user.wallet_balance || 0)} PKR`);
    
    // Check if balance includes rank rewards
    const rankRewardInBalance = totalRankRewardsAmount > 0 ? 
      (parseFloat(user.wallet_balance || 0) >= totalRankRewardsAmount ? '✅ YES (or more)' : '⚠️  PARTIAL') : 
      'N/A';
    console.log(`   Rank rewards in balance: ${rankRewardInBalance}`);

    console.log('\n========================================\n');

    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error);
    await sequelize.close();
    process.exit(1);
  }
}

// Models are already associated in src/models/index.js
checkUserDetails();

