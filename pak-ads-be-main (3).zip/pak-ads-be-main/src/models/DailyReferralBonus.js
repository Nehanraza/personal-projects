const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class DailyReferralBonus extends Model {}

DailyReferralBonus.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    bonus_date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      comment: 'Date when the bonus was earned (YYYY-MM-DD)',
    },
    referrals_count: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Number of referrals made on this date',
    },
    bonus_amount: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
      comment: 'Total bonus amount awarded in PKR',
    },
    bonus_count: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
      comment: 'Number of bonuses awarded (1 bonus per threshold)',
    },
    earning_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'earnings',
        key: 'id',
      },
      onDelete: 'SET NULL',
      comment: 'Reference to the earning record for this bonus',
    },
  },
  {
    sequelize,
    modelName: 'DailyReferralBonus',
    tableName: 'daily_referral_bonuses',
    timestamps: true,
    underscored: true,
    indexes: [
      { fields: ['user_id'] },
      { fields: ['bonus_date'] },
      { 
        fields: ['user_id', 'bonus_date'], 
        unique: true,
        name: 'unique_user_date_bonus',
      },
    ],
  }
);

module.exports = DailyReferralBonus;
