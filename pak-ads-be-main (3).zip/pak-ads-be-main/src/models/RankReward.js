const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class RankReward extends Model {}

RankReward.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    rank: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Rank number (1-7)',
    },
    rank_name: {
      type: DataTypes.STRING,
      allowNull: false,
      comment: 'Rank name (e.g., Rank 1, Rank 2)',
    },
    required_members: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Number of direct members required for this rank',
    },
    actual_members: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Actual number of direct members when reward was claimed',
    },
    reward_amount: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
      comment: 'Reward amount in PKR',
    },
    reward_amount_usd: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
      comment: 'Reward amount in USD',
    },
    earning_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'earnings',
        key: 'id',
      },
      onDelete: 'SET NULL',
      comment: 'Reference to the earning record for this reward',
    },
    claimed_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
      comment: 'When the reward was claimed',
    },
  },
  {
    sequelize,
    modelName: 'RankReward',
    tableName: 'rank_rewards',
    timestamps: true,
    underscored: true,
    indexes: [
      { fields: ['user_id'] },
      { fields: ['rank'] },
      { fields: ['claimed_at'] },
      { 
        fields: ['user_id', 'rank'], 
        unique: true,
        name: 'unique_user_rank_reward',
      },
    ],
  }
);

module.exports = RankReward;
