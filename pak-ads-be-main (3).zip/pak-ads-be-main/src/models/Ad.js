const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class Ad extends Model {}

Ad.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    title: {
      type: DataTypes.STRING(200),
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'Ad title is required',
        },
      },
    },
    slug: {
      type: DataTypes.STRING(250),
      allowNull: false,
      unique: true,
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    price: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
      defaultValue: 0,
    },
    is_negotiable: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    condition: {
      type: DataTypes.ENUM('new', 'used', 'refurbished'),
      allowNull: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    category_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'categories',
        key: 'id',
      },
      onDelete: 'RESTRICT',
    },
    location_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'locations',
        key: 'id',
      },
      onDelete: 'RESTRICT',
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    phone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM('pending', 'active', 'sold', 'expired', 'rejected'),
      defaultValue: 'pending',
    },
    is_featured: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    featured_until: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    views_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    favorites_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    expires_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    rejection_reason: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    external_url: {
      type: DataTypes.STRING(500),
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'External URL is required',
        },
        isUrl: {
          msg: 'External URL must be a valid URL',
        },
      },
      comment: 'External link for the ad (YouTube, website, etc.) - REQUIRED',
    },
  },
  {
    sequelize,
    modelName: 'Ad',
    tableName: 'ads',
    timestamps: true,
    underscored: true,  // Match database snake_case column naming
    indexes: [
      { fields: ['user_id'] },
      { fields: ['category_id'] },
      { fields: ['location_id'] },
      { fields: ['status'] },
      { fields: ['is_featured'] },
      { fields: ['created_at'] },
    ],
  }
);

module.exports = Ad;

