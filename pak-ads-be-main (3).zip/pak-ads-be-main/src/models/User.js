const { DataTypes, Model } = require('sequelize');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { sequelize } = require('../config/database');

class User extends Model {
  // Method to generate JWT token
  getSignedJwtToken() {
    return jwt.sign({ id: this.id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    });
  }

  // Method to match user entered password to hashed password
  async matchPassword(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
  }

  // Generate unique referral code
  static generateReferralCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  // Check if user can watch an ad
  async canWatchAd() {
    const now = new Date();
    
    // If never watched an ad before, can watch
    if (!this.current_cycle_started_at) {
      return { canWatch: true, reason: 'first_time' };
    }

    // Use UTC dates for consistent day comparison (same as second ad logic)
    const cycleStartDate = new Date(this.current_cycle_started_at);
    const cycleStartUTC = new Date(Date.UTC(
      cycleStartDate.getUTCFullYear(),
      cycleStartDate.getUTCMonth(),
      cycleStartDate.getUTCDate()
    ));
    const nowUTC = new Date(Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate()
    ));
    
    // Calculate calendar days since cycle started
    const daysSinceCycleStart = Math.floor((nowUTC - cycleStartUTC) / (1000 * 60 * 60 * 24));

    // FIXED: Check and reset cycle if needed (7 days passed without direct joining)
    const cycleWasReset = await this.checkAndResetCycleIfNeeded();
    
    if (cycleWasReset) {
      // Cycle was reset, recalculate days
      const newCycleStartDate = new Date(this.current_cycle_started_at);
      const newCycleStartUTC = new Date(Date.UTC(
        newCycleStartDate.getUTCFullYear(),
        newCycleStartDate.getUTCMonth(),
        newCycleStartDate.getUTCDate()
      ));
      const newDaysSinceCycleStart = Math.floor((nowUTC - newCycleStartUTC) / (1000 * 60 * 60 * 24));
      
      // After reset, check 24-hour cooldown
      if (this.last_ad_watched_at) {
        const lastWatchDate = new Date(this.last_ad_watched_at);
        const hoursSinceLastWatch = (now - lastWatchDate) / (1000 * 60 * 60);
        
        if (hoursSinceLastWatch < 24) {
          const hoursRemaining = 24 - hoursSinceLastWatch;
          return {
            canWatch: false,
            reason: 'too_soon',
            message: `You can watch your next ad in ${hoursRemaining.toFixed(1)} hours.`,
            hoursRemaining: hoursRemaining
          };
        }
      }
      
      return { 
        canWatch: true, 
        reason: 'cycle_reset',
        message: 'Your cycle has been reset. You can watch ads again.',
        daysRemainingInCycle: 7
      };
    }
    
    // If cycle expired and wasn't reset (user has direct joins), block watching
    if (daysSinceCycleStart >= 7) {
      return { 
        canWatch: false, 
        reason: 'cycle_expired',
        message: 'Your 7-day cycle has expired. Please add a new member to continue watching ads.',
        daysExpired: daysSinceCycleStart - 7
      };
    }

    // Check if 24 hours have passed since last ad watch
    if (this.last_ad_watched_at) {
      const lastWatchDate = new Date(this.last_ad_watched_at);
      const hoursSinceLastWatch = (now - lastWatchDate) / (1000 * 60 * 60);
      
      if (hoursSinceLastWatch < 24) {
        const hoursRemaining = 24 - hoursSinceLastWatch;
        return {
          canWatch: false,
          reason: 'too_soon',
          message: `You can watch your next ad in ${hoursRemaining.toFixed(1)} hours.`,
          hoursRemaining: hoursRemaining
        };
      }
    }

    // User can watch an ad (within 7-day cycle and 24 hours have passed)
    return { 
      canWatch: true, 
      reason: 'eligible',
      daysRemainingInCycle: 7 - daysSinceCycleStart
    };
  }

  // Check and reset cycle if needed (helper method)
  // FIXED: Do NOT auto-reset cycle after 7 days
  // Cycle should only reset when new approved direct joining happens (incrementDailyDirectJoins)
  // After 7 days without approved direct joining, first ad and spinner should be BLOCKED
  async checkAndResetCycleIfNeeded() {
    // Do NOT auto-reset cycle
    // Cycle only resets when incrementDailyDirectJoins() is called (when new direct joining is approved)
    return false; // Cycle was not reset
  }

  // Get ad watching status
  async getAdWatchingStatus() {
    // Check and reset cycle if needed
    await this.checkAndResetCycleIfNeeded();
    
    const now = new Date();
    const status = {
      canWatchAd: false,
      cycleStartDate: this.current_cycle_started_at,
      lastAdWatchedAt: this.last_ad_watched_at,
      totalReferrals: this.total_referrals,
      referralCode: this.referral_code,
    };

    if (!this.current_cycle_started_at) {
      status.canWatchAd = true;
      status.message = 'You can watch your first ad now!';
      status.daysRemainingInCycle = 7;
      return status;
    }

    // Use UTC dates for consistent day comparison (same as canWatchAd logic)
    const cycleStartDate = new Date(this.current_cycle_started_at);
    const cycleStartUTC = new Date(Date.UTC(
      cycleStartDate.getUTCFullYear(),
      cycleStartDate.getUTCMonth(),
      cycleStartDate.getUTCDate()
    ));
    const nowUTC = new Date(Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate()
    ));
    
    // Calculate calendar days since cycle started
    const daysSinceCycleStart = Math.floor((nowUTC - cycleStartUTC) / (1000 * 60 * 60 * 24));
    const daysRemainingInCycle = 7 - daysSinceCycleStart;

    status.daysRemainingInCycle = daysRemainingInCycle;
    status.daysSinceCycleStart = daysSinceCycleStart;

    if (daysSinceCycleStart >= 7) {
      status.message = 'Your 7-day cycle has expired. Please add a new member to continue.';
      status.cycleExpired = true;
      status.daysExpired = daysSinceCycleStart - 7;
      return status;
    }

    if (this.last_ad_watched_at) {
      const lastWatchDate = new Date(this.last_ad_watched_at);
      const hoursSinceLastWatch = (now - lastWatchDate) / (1000 * 60 * 60);
      
      if (hoursSinceLastWatch < 24) {
        const hoursRemaining = 24 - hoursSinceLastWatch;
        status.message = `You can watch your next ad in ${hoursRemaining.toFixed(1)} hours.`;
        status.hoursUntilNextAd = hoursRemaining;
        return status;
      }
    }

    status.canWatchAd = true;
    status.message = 'You can watch an ad now!';
    return status;
  }

  // Get spinner cycle status (7-day window similar to first ad)
  async getSpinCycleStatus() {
    const now = new Date();
    const cycleLengthDays = 7;

    let cycleStartDate = this.current_cycle_started_at || this.createdAt || now;

    // Ensure the cycle start is persisted so subsequent checks stay in sync
    if (!this.current_cycle_started_at) {
      this.current_cycle_started_at = cycleStartDate;
      await this.save();
    }

    // Normalize to UTC dates for calendar day comparisons
    cycleStartDate = new Date(cycleStartDate);

    const cycleStartUTC = new Date(Date.UTC(
      cycleStartDate.getUTCFullYear(),
      cycleStartDate.getUTCMonth(),
      cycleStartDate.getUTCDate()
    ));
    const nowUTC = new Date(Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth(),
      now.getUTCDate()
    ));

    const daysSinceCycleStart = Math.floor((nowUTC - cycleStartUTC) / (1000 * 60 * 60 * 24));
    const cycleExpired = daysSinceCycleStart >= cycleLengthDays;
    const daysRemainingInCycle = cycleExpired
      ? 0
      : Math.max(0, cycleLengthDays - daysSinceCycleStart);
    const cycleEndDate = new Date(cycleStartDate.getTime() + cycleLengthDays * 24 * 60 * 60 * 1000);

    return {
      cycleStartDate,
      cycleEndDate,
      daysSinceCycleStart,
      daysRemainingInCycle,
      cycleExpired,
      message: cycleExpired
        ? 'Your 7-day spinner access has expired. Add a direct member to unlock another cycle.'
        : `You have ${daysRemainingInCycle} day${daysRemainingInCycle === 1 ? '' : 's'} left in your spinner cycle.`,
    };
  }

  // Check if user can spin today
  async canSpinToday() {
    const spinCycleStatus = await this.getSpinCycleStatus();

    if (spinCycleStatus.cycleExpired) {
      return {
        canSpin: false,
        spinsRemaining: 0,
        message: 'Your 7-day spinner cycle has expired. Please add a direct member to continue.',
        cycle: spinCycleStatus,
      };
    }

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // Reset daily count if it's a new day
    if (!this.last_spin_reset_date || new Date(this.last_spin_reset_date) < today) {
      this.today_spins_count = 0;
      this.last_spin_reset_date = today;
      await this.save();
    }

    const spinsUsed = this.today_spins_count || 0;
    const dailyLimit = this.daily_spin_limit || 5;
    const extraSpins = this.extra_spins || 0;
    
    // Calculate remaining spins: daily limit + extra spins - used spins
    const spinsRemaining = Math.max(0, (dailyLimit + extraSpins) - spinsUsed);

    if (spinsRemaining <= 0) {
      return {
        canSpin: false,
        spinsRemaining: 0,
        message: 'No spins remaining today. Come back tomorrow!',
        cycle: spinCycleStatus,
      };
    }

    return {
      canSpin: true,
      spinsRemaining,
      message: `You have ${spinsRemaining} spin${spinsRemaining === 1 ? '' : 's'} remaining today.`,
      cycle: spinCycleStatus,
    };
  }

  // Use a spin (called when user spins)
  async useSpin() {
    const spinStatus = await this.canSpinToday();
    
    if (!spinStatus.canSpin) {
      return false;
    }

    // Use extra spin first, then daily spins
    if (this.extra_spins > 0) {
      this.extra_spins -= 1;
    } else {
      this.today_spins_count = (this.today_spins_count || 0) + 1;
    }

    this.last_spin_at = new Date();
    this.total_spins = (this.total_spins || 0) + 1;
    
    await this.save();
    return true;
  }

  // Reset daily counters if it's a new day
  // FIXED: For direct joins, reset after 24 hours from last join (not calendar day)
  async resetDailyCounters() {
    const now = new Date();
    
    // Reset daily direct joins if 24 hours have passed since last direct join
    // This gives users 24 hours to watch second ads after adding a direct member
    if (this.last_direct_join_at) {
      const hoursSinceLastJoin = (now - new Date(this.last_direct_join_at)) / (1000 * 60 * 60);
      if (hoursSinceLastJoin >= 24) {
        this.today_direct_joins = 0;
        this.last_direct_join_at = null;
        // Also reset second ad views when direct joins reset
        this.today_second_ad_views = 0;
      }
    } else {
      // If no last_direct_join_at but we have joins, reset them (legacy data)
      if (this.today_direct_joins > 0) {
        this.today_direct_joins = 0;
        this.today_second_ad_views = 0;
      }
    }

    // Use UTC date for consistent day comparison for second ad views reset (backup)
    // This is kept for backward compatibility but primary logic is 24-hour based
    const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    if (!this.last_ad_view_reset_date || new Date(this.last_ad_view_reset_date) < today) {
      // Only reset if we haven't already reset due to 24-hour rule above
      if (!this.last_direct_join_at || (now - new Date(this.last_direct_join_at)) / (1000 * 60 * 60) >= 24) {
        this.today_second_ad_views = 0;
        this.last_ad_view_reset_date = today;
      }
    }

    await this.save();
  }

  // Increment daily direct joins
  // FIXED: Set last_direct_join_at timestamp for 24-hour tracking
  // FIXED: Reset cycle when direct joining happens
  async incrementDailyDirectJoins() {
    await this.resetDailyCounters();
    const now = new Date();
    this.today_direct_joins = (this.today_direct_joins || 0) + 1;
    this.last_direct_join_at = now; // Track when this join was added (24-hour window starts)
    
    // FIXED: Reset 7-day cycle when direct joining happens
    // This allows user to continue watching first ads for another 7 days
    this.current_cycle_started_at = now;
    
    await this.save();
  }

  // Check if user can watch second ad
  // Note: resetDailyCounters() should be called before this method in the controller
  canWatchSecondAd() {
    const directJoinsToday = this.today_direct_joins || 0;
    const secondAdViewsToday = this.today_second_ad_views || 0;

    if (directJoinsToday === 0) {
      return {
        canWatch: false,
        reason: 'no_direct_joins',
        message: 'You need to add a direct member today to unlock the second ad.',
        directJoinsToday: 0,
        secondAdViewsToday: 0,
        remainingViews: 0
      };
    }

    const remainingViews = directJoinsToday - secondAdViewsToday;

    if (remainingViews <= 0) {
      return {
        canWatch: false,
        reason: 'daily_limit_reached',
        message: `You have used all your second ad views for today (${directJoinsToday} views).`,
        directJoinsToday: directJoinsToday,
        secondAdViewsToday: secondAdViewsToday,
        remainingViews: 0
      };
    }

    return {
      canWatch: true,
      reason: 'eligible',
      message: `You can watch ${remainingViews} more second ad(s) today.`,
      directJoinsToday: directJoinsToday,
      secondAdViewsToday: secondAdViewsToday,
      remainingViews: remainingViews
    };
  }

  // Use a second ad view
  async useSecondAdView() {
    const status = this.canWatchSecondAd();
    
    if (!status.canWatch) {
      return false;
    }

    this.today_second_ad_views = (this.today_second_ad_views || 0) + 1;
    await this.save();
    return true;
  }

  // Override toJSON to exclude password from JSON responses
  toJSON() {
    const values = { ...this.get() };
    delete values.password;
    return values;
  }
}

User.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(50),
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'Please add a name',
        },
        len: {
          args: [1, 50],
          msg: 'Name cannot be more than 50 characters',
        },
      },
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: {
        msg: 'Email already exists',
      },
      validate: {
        isEmail: {
          msg: 'Please add a valid email',
        },
        notEmpty: {
          msg: 'Please add an email',
        },
      },
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'Please add a password',
        },
        len: {
          args: [1, 255],
          msg: 'Password cannot be empty',
        },
      },
    },
    role: {
      type: DataTypes.ENUM('user', 'admin'),
      defaultValue: 'user',
      allowNull: false,
    },
    phone: {
      type: DataTypes.STRING(20),
      allowNull: false,
      unique: {
        msg: 'Phone number already exists',
      },
      validate: {
        notEmpty: {
          msg: 'Please add a phone number',
        },
      },
    },
    avatar: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    is_email_verified: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    is_admin_approved: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    email_verification_token: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    email_verification_expire: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    reset_password_token: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    reset_password_expire: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    referred_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'SET NULL',
    },
    referral_code: {
      type: DataTypes.STRING(20),
      allowNull: true,
      unique: true,
    },
    last_ad_watched_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    current_cycle_started_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    total_referrals: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    wallet_balance: {
      type: DataTypes.DECIMAL(12, 2),
      defaultValue: 0.00,
      allowNull: false,
    },
    total_earnings: {
      type: DataTypes.DECIMAL(12, 2),
      defaultValue: 0.00,
      allowNull: false,
    },
    total_withdrawn: {
      type: DataTypes.DECIMAL(12, 2),
      defaultValue: 0.00,
      allowNull: false,
    },
    joining_fee_paid: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
      allowNull: false,
    },
    joining_fee_paid_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    joining_fee_amount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: true,
    },
    total_spins: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    extra_spins: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    last_spin_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    daily_spin_limit: {
      type: DataTypes.INTEGER,
      defaultValue: 5,
      allowNull: false,
    },
    today_spins_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    last_spin_reset_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    today_direct_joins: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    last_join_reset_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    last_direct_join_at: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Timestamp of when the last direct join was added (for 24-hour tracking)',
    },
    today_second_ad_views: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    last_ad_view_reset_date: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    last_plan_upgrade_at: {
      type: DataTypes.DATE,
      allowNull: true,
      comment: 'Timestamp of the last plan purchase or upgrade (for 30-day withdrawal rule)',
    },
  },
  {
    sequelize,
    modelName: 'User',
    tableName: 'users',
    timestamps: true,
    underscored: true,  // Match database snake_case column naming
    hooks: {
      // Hash password before creating user
      beforeCreate: async (user) => {
        if (user.password) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
      // Hash password before updating user
      beforeUpdate: async (user) => {
        if (user.changed('password')) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
    },
  }
);

module.exports = User;
