const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class InvestmentPlan extends Model {}

InvestmentPlan.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    investment_amount: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    total_return: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    daily_profit: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    referral_bonus: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    duration_days: {
      type: DataTypes.INTEGER,
      defaultValue: 30,
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  },
  {
    sequelize,
    modelName: 'InvestmentPlan',
    tableName: 'investment_plans',
    timestamps: true,
    underscored: true,
  }
);

module.exports = InvestmentPlan;
