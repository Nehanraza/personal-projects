const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class Earning extends Model {}

Earning.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    from_user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    amount: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    level: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    type: {
      type: DataTypes.ENUM('referral_commission', 'bonus', 'withdrawal', 'refund', 'lucky_draw_win', 'ad_watching', 'daily_referral_bonus', 'rank_reward', 'deposit', 'deposit_reward', 'roi_daily_profit'),
      defaultValue: 'referral_commission',
      allowNull: false,
    },
    description: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM('pending', 'completed', 'cancelled', 'approved', 'rejected', 'sent'),
      defaultValue: 'completed',
      allowNull: false,
    },
    metadata: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: 'JSON string containing additional information (payment method, account details, etc.)',
    },
  },
  {
    sequelize,
    modelName: 'Earning',
    tableName: 'earnings',
    timestamps: true,
    underscored: true,  // This matches the database column naming (created_at, updated_at)
    indexes: [
      { fields: ['user_id'] },
      { fields: ['from_user_id'] },
      { fields: ['level'] },
      { fields: ['type'] },
      { fields: ['created_at'] },
      { fields: ['user_id', 'created_at'] },
    ],
  }
);

module.exports = Earning;

