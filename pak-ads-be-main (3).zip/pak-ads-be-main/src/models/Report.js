const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class Report extends Model {}

Report.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    ad_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'ads',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    reporter_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    reason: {
      type: DataTypes.ENUM(
        'spam',
        'inappropriate',
        'fraud',
        'duplicate',
        'wrong_category',
        'other'
      ),
      allowNull: false,
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM('pending', 'reviewed', 'action_taken', 'dismissed'),
      defaultValue: 'pending',
    },
    admin_notes: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    reviewed_by: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'SET NULL',
    },
    reviewed_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: 'Report',
    tableName: 'reports',
    timestamps: true,
    underscored: true,  // Match database snake_case column naming
    indexes: [
      { fields: ['ad_id'] },
      { fields: ['reporter_id'] },
      { fields: ['status'] },
    ],
  }
);

module.exports = Report;

