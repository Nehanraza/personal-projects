const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class AdView extends Model {}

AdView.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    ad_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'ads',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    watched_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    sequelize,
    modelName: 'AdView',
    tableName: 'ad_views',
    timestamps: true,
    underscored: true,  // This matches the database column naming (created_at, updated_at)
    indexes: [
      { fields: ['user_id'] },
      { fields: ['ad_id'] },
      { fields: ['watched_at'] },
      { fields: ['user_id', 'watched_at'] },
    ],
  }
);

module.exports = AdView;

