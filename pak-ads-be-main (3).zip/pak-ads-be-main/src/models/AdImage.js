const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class AdImage extends Model {}

AdImage.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    ad_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'ads',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    image_url: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    thumbnail_url: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    is_primary: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    display_order: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
  },
  {
    sequelize,
    modelName: 'AdImage',
    tableName: 'ad_images',
    timestamps: true,
    underscored: true,  // Match database snake_case column naming
  }
);

module.exports = AdImage;

