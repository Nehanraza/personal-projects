const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class UserPlan extends Model {}

UserPlan.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
    },
    plan_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'investment_plans',
        key: 'id',
      },
    },
    status: {
      type: DataTypes.ENUM('active', 'completed', 'cancelled'),
      defaultValue: 'active',
    },
    investment_amount: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    daily_profit: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    total_returned: {
      type: DataTypes.DECIMAL(12, 2),
      defaultValue: 0.00,
    },
    max_return: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
    },
    activated_at: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
    expires_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    last_earning_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: 'UserPlan',
    tableName: 'user_plans',
    timestamps: true,
    underscored: true,
  }
);

module.exports = UserPlan;
