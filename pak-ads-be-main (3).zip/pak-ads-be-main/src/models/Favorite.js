const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class Favorite extends Model {}

Favorite.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    ad_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'ads',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
  },
  {
    sequelize,
    modelName: 'Favorite',
    tableName: 'favorites',
    timestamps: true,
    underscored: true,  // Match database snake_case column naming
    indexes: [
      {
        unique: true,
        fields: ['user_id', 'ad_id'],
      },
      { fields: ['user_id'] },
      { fields: ['ad_id'] },
    ],
  }
);

module.exports = Favorite;
