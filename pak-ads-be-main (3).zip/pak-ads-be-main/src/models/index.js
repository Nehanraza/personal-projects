const { sequelize } = require('../config/database');
const User = require('./User');
const Category = require('./Category');
const Location = require('./Location');
const Ad = require('./Ad');
const AdImage = require('./AdImage');
const Package = require('./Package');
const Review = require('./Review');
const Message = require('./Message');
const Report = require('./Report');
const Favorite = require('./Favorite');
const Notification = require('./Notification');
const AdView = require('./AdView');
const Earning = require('./Earning');
const DailyReferralBonus = require('./DailyReferralBonus');
const RankReward = require('./RankReward');
const Notice = require('./Notice');
const Deposit = require('./Deposit');
const DepositReward = require('./DepositReward');
const Transfer = require('./Transfer');
const InvestmentPlan = require('./InvestmentPlan');
const UserPlan = require('./UserPlan');

// Define associations

// User associations
User.hasMany(Ad, { foreignKey: 'user_id', as: 'ads' });
User.hasMany(Review, { foreignKey: 'user_id', as: 'reviews_given' });
User.hasMany(Review, { foreignKey: 'seller_id', as: 'reviews_received' });
User.hasMany(Message, { foreignKey: 'sender_id', as: 'messages_sent' });
User.hasMany(Message, { foreignKey: 'receiver_id', as: 'messages_received' });
User.hasMany(Report, { foreignKey: 'reporter_id', as: 'reports_made' });

// Ad associations
Ad.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
Ad.belongsTo(Category, { foreignKey: 'category_id', as: 'category' });
Ad.belongsTo(Location, { foreignKey: 'location_id', as: 'location' });
Ad.hasMany(AdImage, { foreignKey: 'ad_id', as: 'images' });
Ad.hasMany(Review, { foreignKey: 'ad_id', as: 'reviews' });
Ad.hasMany(Message, { foreignKey: 'ad_id', as: 'messages' });
Ad.hasMany(Report, { foreignKey: 'ad_id', as: 'reports' });

// AdImage associations
AdImage.belongsTo(Ad, { foreignKey: 'ad_id', as: 'ad' });

// Category associations
Category.hasMany(Ad, { foreignKey: 'category_id', as: 'ads' });

// Location associations
Location.hasMany(Ad, { foreignKey: 'location_id', as: 'ads' });

// Review associations
Review.belongsTo(Ad, { foreignKey: 'ad_id', as: 'ad' });
Review.belongsTo(User, { foreignKey: 'user_id', as: 'reviewer' });
Review.belongsTo(User, { foreignKey: 'seller_id', as: 'seller' });

// Message associations
Message.belongsTo(Ad, { foreignKey: 'ad_id', as: 'ad' });
Message.belongsTo(User, { foreignKey: 'sender_id', as: 'sender' });
Message.belongsTo(User, { foreignKey: 'receiver_id', as: 'receiver' });

// Report associations
Report.belongsTo(Ad, { foreignKey: 'ad_id', as: 'ad' });
Report.belongsTo(User, { foreignKey: 'reporter_id', as: 'reporter' });
Report.belongsTo(User, { foreignKey: 'reviewed_by', as: 'reviewer' });

// Favorite associations
Favorite.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
Favorite.belongsTo(Ad, { foreignKey: 'ad_id', as: 'ad' });
User.hasMany(Favorite, { foreignKey: 'user_id', as: 'favorites' });
Ad.hasMany(Favorite, { foreignKey: 'ad_id', as: 'favorites' });

// Notification associations
Notification.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
User.hasMany(Notification, { foreignKey: 'user_id', as: 'notifications' });

// AdView associations
AdView.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
AdView.belongsTo(Ad, { foreignKey: 'ad_id', as: 'ad' });
User.hasMany(AdView, { foreignKey: 'user_id', as: 'ad_views' });
Ad.hasMany(AdView, { foreignKey: 'ad_id', as: 'views' });

// Referral associations (self-referencing)
User.hasMany(User, { foreignKey: 'referred_by', as: 'referrals' });
User.belongsTo(User, { foreignKey: 'referred_by', as: 'referrer' });

// Earning associations
Earning.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
Earning.belongsTo(User, { foreignKey: 'from_user_id', as: 'fromUser' });
User.hasMany(Earning, { foreignKey: 'user_id', as: 'earnings' });
User.hasMany(Earning, { foreignKey: 'from_user_id', as: 'earningsGenerated' });

// DailyReferralBonus associations
DailyReferralBonus.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
DailyReferralBonus.belongsTo(Earning, { foreignKey: 'earning_id', as: 'earning' });
User.hasMany(DailyReferralBonus, { foreignKey: 'user_id', as: 'dailyReferralBonuses' });
Earning.hasMany(DailyReferralBonus, { foreignKey: 'earning_id', as: 'dailyReferralBonuses' });

// RankReward associations
RankReward.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
RankReward.belongsTo(Earning, { foreignKey: 'earning_id', as: 'earning' });
User.hasMany(RankReward, { foreignKey: 'user_id', as: 'rankRewards' });
Earning.hasMany(RankReward, { foreignKey: 'earning_id', as: 'rankRewards' });

// DepositReward associations
DepositReward.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
DepositReward.belongsTo(Earning, { foreignKey: 'earning_id', as: 'earning' });
User.hasMany(DepositReward, { foreignKey: 'user_id', as: 'depositRewards' });
Earning.hasMany(DepositReward, { foreignKey: 'earning_id', as: 'depositRewards' });

// Notice associations
Notice.belongsTo(User, { foreignKey: 'createdBy', as: 'creator' });
Notice.belongsTo(User, { foreignKey: 'updatedBy', as: 'updater' });
User.hasMany(Notice, { foreignKey: 'createdBy', as: 'noticesCreated' });
User.hasMany(Notice, { foreignKey: 'updatedBy', as: 'noticesUpdated' });

// Deposit associations
Deposit.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
Deposit.belongsTo(User, { foreignKey: 'approved_by', as: 'approver' });
Deposit.belongsTo(User, { foreignKey: 'rejected_by', as: 'rejector' });
User.hasMany(Deposit, { foreignKey: 'user_id', as: 'deposits' });
User.hasMany(Deposit, { foreignKey: 'approved_by', as: 'depositsApproved' });
User.hasMany(Deposit, { foreignKey: 'rejected_by', as: 'depositsRejected' });

// Transfer associations
Transfer.belongsTo(User, { foreignKey: 'sender_id', as: 'sender' });
Transfer.belongsTo(User, { foreignKey: 'receiver_id', as: 'receiver' });
User.hasMany(Transfer, { foreignKey: 'sender_id', as: 'transfersSent' });
User.hasMany(Transfer, { foreignKey: 'receiver_id', as: 'transfersReceived' });

// Investment Plans associations
User.hasMany(UserPlan, { foreignKey: 'user_id', as: 'userPlans' });
UserPlan.belongsTo(User, { foreignKey: 'user_id', as: 'user' });
InvestmentPlan.hasMany(UserPlan, { foreignKey: 'plan_id', as: 'userPlans' });
UserPlan.belongsTo(InvestmentPlan, { foreignKey: 'plan_id', as: 'plan' });

// Deposit and Investment Plans association
Deposit.belongsTo(InvestmentPlan, { foreignKey: 'plan_id', as: 'investmentPlan' });
InvestmentPlan.hasMany(Deposit, { foreignKey: 'plan_id', as: 'deposits' });

const models = {
  User,
  Category,
  Location,
  Ad,
  AdImage,
  Package,
  Review,
  Message,
  Report,
  Favorite,
  Notification,
  AdView,
  Earning,
  DailyReferralBonus,
  RankReward,
  Notice,
  Deposit,
  DepositReward,
  Transfer,
  InvestmentPlan,
  UserPlan,
};

module.exports = {
  sequelize,
  ...models,
};
