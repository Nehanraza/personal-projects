const { DataTypes, Model } = require('sequelize');
const { sequelize } = require('../config/database');

class DepositReward extends Model {}

DepositReward.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
      comment: 'User who earned the deposit reward',
    },
    reward_amount: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
      comment: 'Reward amount in PKR',
    },
    referrals_count: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Total referrals when reward was earned',
    },
    earning_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'earnings',
        key: 'id',
      },
      onDelete: 'SET NULL',
      comment: 'Reference to the earning record for this reward',
    },
  },
  {
    sequelize,
    modelName: 'DepositReward',
    tableName: 'deposit_rewards',
    timestamps: true,
    underscored: true,
    indexes: [
      { fields: ['user_id'] },
      { fields: ['created_at'] },
    ],
  }
);

module.exports = DepositReward;

