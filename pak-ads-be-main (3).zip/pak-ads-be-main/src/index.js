const app = require('./app');
const { connectDB } = require('./config/database');
const logger = require('./config/logger');

// Load environment variables
require('dotenv').config();

// Set default environment variables if not provided
process.env.NODE_ENV = process.env.NODE_ENV || 'production';
process.env.JWT_SECRET = process.env.JWT_SECRET || '26253f321676bc0e3f6b621ac70ce69cde98048c30fac41589e9630171cf53293fafbe18d794f1f8a3316a6a22a04d15e56e064a454a96c6106020f0681c0a1c';
process.env.JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
process.env.LOG_LEVEL = process.env.LOG_LEVEL || 'info';
process.env.TZ = process.env.TZ || 'Asia/Karachi';
process.env.FORCE_SYNC = process.env.FORCE_SYNC || 'false';
process.env.CORS_ORIGIN = process.env.CORS_ORIGIN || '*';

// Email configuration defaults
process.env.SMTP_HOST = process.env.SMTP_HOST || 'smtp.gmail.com';
process.env.SMTP_PORT = process.env.SMTP_PORT || '587';
process.env.SMTP_USER = process.env.SMTP_USER || 'faisalcomedychanel@gmail.com';
process.env.SMTP_PASSWORD = process.env.SMTP_PASSWORD || 'faisal0618';
process.env.FROM_NAME = process.env.FROM_NAME || 'Pak Ads';
process.env.FROM_EMAIL = process.env.FROM_EMAIL || 'faisalcomedychanel@gmail.com';

const PORT = process.env.PORT || 4000;

// Connect to database only if not in Vercel
if (process.env.VERCEL !== '1') {
  connectDB();
}

// Start server only if not in Vercel environment
if (process.env.VERCEL !== '1') {
  const server = app.listen(PORT, () => {
    logger.info(`🚀 ${process.env.APP_NAME || 'Server'} running in ${process.env.NODE_ENV} mode on port ${PORT}`);
    logger.info(`📍 API URL: ${process.env.APP_URL || `http://localhost:${PORT}`}`);
    logger.info(`🌍 Timezone: ${process.env.TZ || 'UTC'}`);
    
    // Initialize ROI distribution background service
    const { initROICron } = require('./cron/roiCron');
    initROICron();
  });
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  logger.error('UNHANDLED REJECTION! Shutting down...', {
    name: err.name,
    message: err.message,
    stack: err.stack,
  });
  server.close(() => {
    process.exit(1);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  logger.error('UNCAUGHT EXCEPTION! Shutting down...', {
    name: err.name,
    message: err.message,
    stack: err.stack,
  });
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM RECEIVED. Shutting down gracefully');
  server.close(() => {
    logger.info('Process terminated!');
  });
});
