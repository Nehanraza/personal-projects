const fs = require('fs').promises;
const path = require('path');
const { sequelize } = require('../config/database');
const logger = require('../config/logger');

// Import seeders
const seedAdmin = require('../database/seeders/adminSeeder');
const seedCategories = require('../database/seeders/categorySeeder');
const seedLocations = require('../database/seeders/locationSeeder');
const seedPackages = require('../database/seeders/packageSeeder');
const seedInvestmentPlans = require('../database/seeders/investmentPlanSeeder');

const initDatabase = async () => {
  try {
    logger.info('🚀 Starting Database Initialization...');

    // 1. Test Connection
    await sequelize.authenticate();
    logger.info('✓ Database connection established');

    // 2. Run Migrations
    logger.info('📂 Running migrations...');
    const migrationsPath = path.join(__dirname, '../database/migrations');
    const migrationFiles = await fs.readdir(migrationsPath);
    
    // Sort files to ensure correct order
    for (const file of migrationFiles.sort()) {
      try {
        const migration = require(path.join(migrationsPath, file));
        if (migration.up && typeof migration.up === 'function') {
          logger.info(`  - Executing migration: ${file}`);
          await migration.up(sequelize.getQueryInterface(), sequelize.Sequelize);
        }
      } catch (error) {
        logger.error(`  ✗ Error in migration ${file}: ${error.message}`);
        // Continue with other migrations if one fails (some might be partial or redundant)
      }
    }
    logger.info('✓ Migrations completed');

    // 3. Run Seeders
    logger.info('🌱 Running seeders...');
    try {
      await seedAdmin();
      await seedCategories();
      await seedLocations();
      await seedPackages();
      if (typeof seedInvestmentPlans === 'function') {
        await seedInvestmentPlans();
      }
      logger.info('✓ Seeding completed successfully!');
    } catch (error) {
      logger.error('✗ Seeding failed:', error.message);
    }

    logger.info('✨ Database initialization finished successfully!');
    process.exit(0);
  } catch (error) {
    logger.error('✗ Database initialization failed:', error);
    process.exit(1);
  }
};

// Run the initialization
initDatabase();
