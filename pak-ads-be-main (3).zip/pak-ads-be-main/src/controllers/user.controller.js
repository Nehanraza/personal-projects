const User = require('../models/User');
const { Op } = require('sequelize');

// @desc    Get all users
// @route   GET /api/v1/users
// @access  Private/Admin
exports.getUsers = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || parseInt(process.env.DEFAULT_PAGE_SIZE, 10) || 10;
    const offset = (page - 1) * limit;

    // Build where clause for search
    const where = {};
    if (req.query.search) {
      where[Op.or] = [
        { name: { [Op.iLike]: `%${req.query.search}%` } },
        { email: { [Op.iLike]: `%${req.query.search}%` } },
      ];
    }

    // Get users with pagination
    const { count, rows: users } = await User.findAndCountAll({
      where,
      attributes: { exclude: ['password'] },
      limit,
      offset,
      order: [['created_at', 'DESC']],
    });

    res.status(200).json({
      success: true,
      count: users.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: users,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single user
// @route   GET /api/v1/users/:id
// @access  Private
exports.getUser = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.params.id, {
      attributes: { exclude: ['password'] },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Make sure user can only see their own profile or admin can see all
    if (user.id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this user',
      });
    }

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user
// @route   PUT /api/v1/users/:id
// @access  Private
exports.updateUser = async (req, res, next) => {
  try {
    // Make sure user can only update their own profile or admin can update all
    if (parseInt(req.params.id) !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this user',
      });
    }

    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Fields to update
    const fieldsToUpdate = {
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
      avatar: req.body.avatar,
    };

    // Only admin can update role and active status
    if (req.user.role === 'admin') {
      if (req.body.role !== undefined) fieldsToUpdate.role = req.body.role;
      if (req.body.is_active !== undefined) fieldsToUpdate.is_active = req.body.is_active;
    }

    // Remove undefined fields
    Object.keys(fieldsToUpdate).forEach(
      (key) => fieldsToUpdate[key] === undefined && delete fieldsToUpdate[key]
    );

    await user.update(fieldsToUpdate);

    // Reload to get updated data
    await user.reload({ attributes: { exclude: ['password'] } });

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete user
// @route   DELETE /api/v1/users/:id
// @access  Private
exports.deleteUser = async (req, res, next) => {
  try {
    // Make sure user can only delete their own profile or admin can delete all
    if (parseInt(req.params.id) !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this user',
      });
    }

    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    await user.destroy();

    res.status(200).json({
      success: true,
      message: 'User deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get my referrals
// @route   GET /api/v1/users/my-referrals
// @access  Private
exports.getMyReferrals = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows: referrals } = await User.findAndCountAll({
      where: { referred_by: req.user.id },
      attributes: ['id', 'name', 'email', 'created_at', 'joining_fee_paid', 'total_referrals'],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    res.status(200).json({
      success: true,
      count: referrals.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: referrals,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get referral stats
// @route   GET /api/v1/users/referral-stats
// @access  Private
exports.getReferralStats = async (req, res, next) => {
  try {
    const totalReferrals = await User.count({
      where: { referred_by: req.user.id },
    });

    const activeReferrals = await User.count({
      where: { 
        referred_by: req.user.id,
        is_active: true,
      },
    });

    const paidReferrals = await User.count({
      where: { 
        referred_by: req.user.id,
        joining_fee_paid: true,
      },
    });

    res.status(200).json({
      success: true,
      data: {
        total_referrals: totalReferrals,
        active_referrals: activeReferrals,
        paid_referrals: paidReferrals,
        referral_code: req.user.referral_code,
      },
    });
  } catch (error) {
    next(error);
  }
};
