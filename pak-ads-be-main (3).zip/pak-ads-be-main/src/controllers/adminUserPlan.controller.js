const { UserPlan, InvestmentPlan, User, Earning } = require('../models');
const logger = require('../config/logger');
const { Op } = require('sequelize');

/**
 * @desc    Get all user plans (Admin only)
 * @route   GET /api/v1/admin/user-plans
 * @access  Private/Admin
 */
exports.getAllUserPlans = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (status) {
      where.status = status;
    }

    const { count, rows } = await UserPlan.findAndCountAll({
      where,
      include: [
        {
          model: InvestmentPlan,
          as: 'plan',
          attributes: ['id', 'name', 'investment_amount', 'daily_profit'],
        },
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.status(200).json({
      success: true,
      data: rows,
      pagination: {
        total: count,
        page: parseInt(page),
        pages: Math.ceil(count / limit),
      },
    });
  } catch (error) {
    logger.error('Error fetching all user plans:', error);
    next(error);
  }
};

/**
 * @desc    Get single user plan details with history
 * @route   GET /api/v1/admin/user-plans/:id
 * @access  Private/Admin
 */
exports.getUserPlanById = async (req, res, next) => {
  try {
    const { id } = req.params;

    const userPlan = await UserPlan.findByPk(id, {
      include: [
        {
          model: InvestmentPlan,
          as: 'plan',
        },
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'wallet_balance'],
        },
      ],
    });

    if (!userPlan) {
      return res.status(404).json({
        success: false,
        message: 'User plan not found',
      });
    }

    // Get earning history for this specific plan
    const earnings = await Earning.findAll({
      where: {
        user_id: userPlan.user_id,
        type: 'roi_daily_profit',
        metadata: {
          [Op.like]: `%${userPlan.id}%`,
        },
      },
      order: [['created_at', 'DESC']],
      limit: 50,
    });

    res.status(200).json({
      success: true,
      data: {
        ...userPlan.toJSON(),
        earning_history: earnings,
      },
    });
  } catch (error) {
    logger.error('Error fetching user plan details:', error);
    next(error);
  }
};

/**
 * @desc    Get ROI distribution statistics (Admin only)
 * @route   GET /api/v1/admin/user-plans/stats/roi
 * @access  Private/Admin
 */
exports.getROIStats = async (req, res, next) => {
  try {
    const totalROIPaid = await Earning.sum('amount', {
      where: { type: 'roi_daily_profit' },
    });

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayROIPaid = await Earning.sum('amount', {
      where: {
        type: 'roi_daily_profit',
        created_at: { [Op.gte]: today },
      },
    });

    const activePlansCount = await UserPlan.count({
      where: { status: 'active' },
    });

    res.status(200).json({
      success: true,
      data: {
        total_roi_paid: parseFloat(totalROIPaid || 0),
        today_roi_paid: parseFloat(todayROIPaid || 0),
        active_plans_count: activePlansCount,
      },
    });
  } catch (error) {
    logger.error('Error fetching ROI stats:', error);
    next(error);
  }
};
