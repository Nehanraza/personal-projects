/**
 * Commission Controller
 * Handles all commission-related operations and API endpoints
 */

const {
  getUserCommissionStats,
  getOverallCommissionStats,
  getTopCommissionEarners,
  previewCommissionDistribution,
  distributeCommission,
} = require('../utils/commissionService');
const { Earning, User } = require('../models');
const { sequelize } = require('../config/database');
const logger = require('../config/logger');

/**
 * @desc    Get current user's commission statistics
 * @route   GET /api/commissions/my-stats
 * @access  Private
 */
exports.getMyCommissionStats = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const stats = await getUserCommissionStats(userId);

    
    res.status(200).json({
      success: true,
      data: stats,
    });
  } catch (error) {
    logger.error('Error in getMyCommissionStats:', error);
    next(error);
  }
};

/**
 * @desc    Get user's commission history with pagination
 * @route   GET /api/commissions/my-history
 * @access  Private
 */
exports.getMyCommissionHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const level = req.query.level ? parseInt(req.query.level) : null;
    const offset = (page - 1) * limit;

    const whereClause = {
      user_id: userId,
      type: 'referral_commission',
    };

    if (level) {
      whereClause.level = level;
    }

    const { count, rows } = await Earning.findAndCountAll({
      where: whereClause,
      include: [
        {
          model: User,
          as: 'fromUser',
          attributes: ['id', 'name', 'email'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const commissions = rows.map((c) => ({
      id: c.id,
      amount: parseFloat(c.amount),
      level: c.level,
      fromUser: c.fromUser
        ? {
            id: c.fromUser.id,
            name: c.fromUser.name,
            email: c.fromUser.email,
          }
        : null,
      description: c.description,
      status: c.status,
      metadata: c.metadata ? JSON.parse(c.metadata) : null,
      createdAt: c.created_at,
    }));

    res.status(200).json({
      success: true,
      data: {
        commissions,
        pagination: {
          page,
          limit,
          total: count,
          totalPages: Math.ceil(count / limit),
        },
      },
    });
  } catch (error) {
    logger.error('Error in getMyCommissionHistory:', error);
    next(error);
  }
};

/**
 * @desc    Get user's downline (referral network)
 * @route   GET /api/commissions/my-network
 * @access  Private
 */
exports.getMyNetwork = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const maxLevels = parseInt(req.query.levels) || 7;

    // Build referral network recursively
    const buildNetwork = async (referrerId, currentLevel = 1) => {
      if (currentLevel > maxLevels) {
        return [];
      }

      const referrals = await User.findAll({
        where: { referred_by: referrerId },
        attributes: ['id', 'name', 'email', 'created_at', 'total_referrals'],
        raw: true,
      });

      const network = [];
      for (const referral of referrals) {
        const children = await buildNetwork(referral.id, currentLevel + 1);
        network.push({
          ...referral,
          level: currentLevel,
          children: children,
        });
      }

      return network;
    };

    const network = await buildNetwork(userId);

    // Calculate network statistics
    const calculateNetworkStats = (nodes, stats = { total: 0, byLevel: {} }) => {
      nodes.forEach((node) => {
        stats.total += 1;
        stats.byLevel[node.level] = (stats.byLevel[node.level] || 0) + 1;
        
        if (node.children && node.children.length > 0) {
          calculateNetworkStats(node.children, stats);
        }
      });
      return stats;
    };

    const networkStats = calculateNetworkStats(network);

    res.status(200).json({
      success: true,
      data: {
        network,
        stats: {
          totalMembers: networkStats.total,
          byLevel: networkStats.byLevel,
        },
      },
    });
  } catch (error) {
    logger.error('Error in getMyNetwork:', error);
    next(error);
  }
};

/**
 * @desc    Preview commission distribution for a transaction
 * @route   POST /api/commissions/preview
 * @access  Private
 */
exports.previewCommission = async (req, res, next) => {
  try {
    const { fromUserId, baseAmount, calculationType } = req.body;

    // Validate inputs
    if (!fromUserId || !baseAmount) {
      return res.status(400).json({
        success: false,
        message: 'Please provide fromUserId and baseAmount',
      });
    }

    const preview = await previewCommissionDistribution(
      fromUserId,
      parseFloat(baseAmount),
      calculationType || 'percentage'
    );

    res.status(200).json({
      success: true,
      data: preview,
    });
  } catch (error) {
    logger.error('Error in previewCommission:', error);
    next(error);
  }
};

/**
 * @desc    Manually trigger commission distribution (Admin only)
 * @route   POST /api/commissions/distribute
 * @access  Private/Admin
 */
exports.manuallyDistributeCommission = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const { fromUserId, baseAmount, activityType, calculationType, metadata } = req.body;

    // Validate inputs
    if (!fromUserId || !baseAmount) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Please provide fromUserId and baseAmount',
      });
    }

    // Verify the user exists
    const user = await User.findByPk(fromUserId);
    if (!user) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const result = await distributeCommission(
      fromUserId,
      parseFloat(baseAmount),
      activityType || 'manual',
      calculationType || 'percentage',
      { transaction, metadata: metadata || {} }
    );

    await transaction.commit();

    res.status(200).json({
      success: true,
      message: 'Commission distributed successfully',
      data: result,
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error in manuallyDistributeCommission:', error);
    next(error);
  }
};

/**
 * @desc    Get overall commission statistics (Admin only)
 * @route   GET /api/commissions/admin/overall-stats
 * @access  Private/Admin
 */
exports.getOverallStats = async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;
    
    const stats = await getOverallCommissionStats({
      startDate,
      endDate,
    });

    res.status(200).json({
      success: true,
      data: stats,
    });
  } catch (error) {
    logger.error('Error in getOverallStats:', error);
    next(error);
  }
};

/**
 * @desc    Get top commission earners (Admin only)
 * @route   GET /api/commissions/admin/top-earners
 * @access  Private/Admin
 */
exports.getTopEarners = async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const { startDate, endDate } = req.query;

    const topEarners = await getTopCommissionEarners(limit, {
      startDate,
      endDate,
    });

    res.status(200).json({
      success: true,
      data: {
        topEarners,
        limit,
      },
    });
  } catch (error) {
    logger.error('Error in getTopEarners:', error);
    next(error);
  }
};

/**
 * @desc    Get commission statistics for a specific user (Admin only)
 * @route   GET /api/commissions/admin/user/:userId
 * @access  Private/Admin
 */
exports.getUserStats = async (req, res, next) => {
  try {
    const { userId } = req.params;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const stats = await getUserCommissionStats(userId);

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          totalReferrals: user.total_referrals,
        },
        stats,
      },
    });
  } catch (error) {
    logger.error('Error in getUserStats:', error);
    next(error);
  }
};

/**
 * @desc    Get commission structure and configuration
 * @route   GET /api/commissions/structure
 * @access  Public
 */
exports.getCommissionStructure = async (req, res, next) => {
  try {
    const { COMMISSION_LEVELS, COMMISSION_CONFIG } = require('../config/constants');

    res.status(200).json({
      success: true,
      data: {
        levels: COMMISSION_LEVELS,
        config: COMMISSION_CONFIG,
      },
    });
  } catch (error) {
    logger.error('Error in getCommissionStructure:', error);
    next(error);
  }
};

/**
 * @desc    Get daily commission earnings
 * @route   GET /api/commissions/daily-earnings
 * @access  Private
 */
exports.getDailyCommissionEarnings = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const days = parseInt(req.query.days) || 30;

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const earnings = await Earning.findAll({
      where: {
        user_id: userId,
        type: 'referral_commission',
        created_at: {
          [sequelize.Op.gte]: startDate,
        },
      },
      attributes: [
        [sequelize.fn('DATE', sequelize.col('created_at')), 'date'],
        [sequelize.fn('SUM', sequelize.col('amount')), 'total_amount'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: [sequelize.fn('DATE', sequelize.col('created_at'))],
      order: [[sequelize.fn('DATE', sequelize.col('created_at')), 'DESC']],
      raw: true,
    });

    const formattedEarnings = earnings.map((e) => ({
      date: e.date,
      amount: parseFloat(e.total_amount),
      count: parseInt(e.count),
    }));

    res.status(200).json({
      success: true,
      data: {
        days,
        earnings: formattedEarnings,
      },
    });
  } catch (error) {
    logger.error('Error in getDailyCommissionEarnings:', error);
    next(error);
  }
};

module.exports = exports;
