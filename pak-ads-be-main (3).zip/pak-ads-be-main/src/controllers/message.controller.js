const Message = require('../models/Message');
const User = require('../models/User');
const Ad = require('../models/Ad');
const { Op } = require('sequelize');

// @desc    Get all messages
// @route   GET /api/v1/messages
// @access  Private
exports.getMessages = async (req, res, next) => {
  try {
    const { ad_id } = req.query;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 50;
    const offset = (page - 1) * limit;

    const where = {
      [Op.or]: [
        { sender_id: req.user.id },
        { receiver_id: req.user.id },
      ],
    };

    if (ad_id) {
      where.ad_id = ad_id;
    }

    const { count, rows: messages } = await Message.findAndCountAll({
      where,
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: User,
          as: 'sender',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: User,
          as: 'receiver',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug'],
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: messages.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: messages,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get conversation between two users about an ad
// @route   GET /api/v1/messages/conversation/:adId/:userId
// @access  Private
exports.getConversation = async (req, res, next) => {
  try {
    const { adId, userId } = req.params;

    const messages = await Message.findAll({
      where: {
        ad_id: adId,
        [Op.or]: [
          { sender_id: req.user.id, receiver_id: userId },
          { sender_id: userId, receiver_id: req.user.id },
        ],
      },
      order: [['created_at', 'ASC']],
      include: [
        {
          model: User,
          as: 'sender',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: User,
          as: 'receiver',
          attributes: ['id', 'name', 'avatar'],
        },
      ],
    });

    // Mark messages as read
    await Message.update(
      { is_read: true, read_at: new Date() },
      {
        where: {
          ad_id: adId,
          sender_id: userId,
          receiver_id: req.user.id,
          is_read: false,
        },
      }
    );

    res.status(200).json({
      success: true,
      count: messages.length,
      data: messages,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Send message
// @route   POST /api/v1/messages
// @access  Private
exports.sendMessage = async (req, res, next) => {
  try {
    req.body.sender_id = req.user.id;

    const message = await Message.create(req.body);

    // Fetch complete message with associations
    const completeMessage = await Message.findByPk(message.id, {
      include: [
        {
          model: User,
          as: 'sender',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: User,
          as: 'receiver',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug'],
        },
      ],
    });

    res.status(201).json({
      success: true,
      data: completeMessage,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Mark message as read
// @route   PUT /api/v1/messages/:id/read
// @access  Private
exports.markAsRead = async (req, res, next) => {
  try {
    const message = await Message.findByPk(req.params.id);

    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found',
      });
    }

    // Only receiver can mark as read
    if (message.receiver_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized',
      });
    }

    await message.update({
      is_read: true,
      read_at: new Date(),
    });

    res.status(200).json({
      success: true,
      data: message,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get unread message count
// @route   GET /api/v1/messages/unread/count
// @access  Private
exports.getUnreadCount = async (req, res, next) => {
  try {
    const count = await Message.count({
      where: {
        receiver_id: req.user.id,
        is_read: false,
      },
    });

    res.status(200).json({
      success: true,
      data: { unread_count: count },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete message
// @route   DELETE /api/v1/messages/:id
// @access  Private
exports.deleteMessage = async (req, res, next) => {
  try {
    const message = await Message.findByPk(req.params.id);

    if (!message) {
      return res.status(404).json({
        success: false,
        message: 'Message not found',
      });
    }

    // Only sender or receiver can delete
    if (message.sender_id !== req.user.id && message.receiver_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this message',
      });
    }

    await message.destroy();

    res.status(200).json({
      success: true,
      message: 'Message deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

