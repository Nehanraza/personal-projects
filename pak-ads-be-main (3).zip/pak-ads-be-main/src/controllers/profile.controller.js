const User = require('../models/User');
const Ad = require('../models/Ad');
const Review = require('../models/Review');
const Category = require('../models/Category');
const Location = require('../models/Location');
const AdImage = require('../models/AdImage');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');

// @desc    Get public user profile
// @route   GET /api/v1/profile/:userId
// @access  Public
exports.getUserProfile = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.params.userId, {
      attributes: ['id', 'name', 'avatar', 'created_at'],
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Get user's active ads count
    const totalAds = await Ad.count({
      where: { user_id: user.id, status: 'active' },
    });

    // Get user's reviews
    const reviewsResult = await Review.findOne({
      attributes: [
        [sequelize.fn('COUNT', sequelize.col('id')), 'total_reviews'],
        [sequelize.fn('AVG', sequelize.col('rating')), 'avg_rating'],
      ],
      where: { seller_id: user.id },
      raw: true,
    });

    // Get member since (formatted)
    const memberSince = new Date(user.created_at);

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user.id,
          name: user.name,
          avatar: user.avatar,
          member_since: memberSince,
        },
        stats: {
          total_ads: totalAds,
          total_reviews: parseInt(reviewsResult.total_reviews) || 0,
          average_rating: parseFloat(reviewsResult.avg_rating || 0).toFixed(1),
        },
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user's public ads
// @route   GET /api/v1/profile/:userId/ads
// @access  Public
exports.getUserAds = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 12;
    const offset = (page - 1) * limit;

    const { count, rows: ads } = await Ad.findAndCountAll({
      where: {
        user_id: req.params.userId,
        status: 'active',
      },
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: Category,
          as: 'category',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: Location,
          as: 'location',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: AdImage,
          as: 'images',
          limit: 1,
          where: { is_primary: true },
          required: false,
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: ads.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: ads,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user's reviews
// @route   GET /api/v1/profile/:userId/reviews
// @access  Public
exports.getUserReviews = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows: reviews } = await Review.findAndCountAll({
      where: {
        seller_id: req.params.userId,
        is_approved: true,
      },
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: User,
          as: 'reviewer',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug'],
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: reviews.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: reviews,
    });
  } catch (error) {
    next(error);
  }
};
