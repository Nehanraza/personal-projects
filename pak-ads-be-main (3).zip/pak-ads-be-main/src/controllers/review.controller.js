const Review = require('../models/Review');
const Ad = require('../models/Ad');
const User = require('../models/User');
const { Op } = require('sequelize');

// @desc    Get all reviews
// @route   GET /api/v1/reviews
// @access  Public
exports.getReviews = async (req, res, next) => {
  try {
    const { ad_id, seller_id, user_id, is_approved } = req.query;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    const offset = (page - 1) * limit;

    const where = {};
    if (ad_id) where.ad_id = ad_id;
    if (seller_id) where.seller_id = seller_id;
    if (user_id) where.user_id = user_id;
    if (is_approved !== undefined) where.is_approved = is_approved === 'true';

    const { count, rows: reviews } = await Review.findAndCountAll({
      where,
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: User,
          as: 'reviewer',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug'],
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: reviews.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: reviews,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single review
// @route   GET /api/v1/reviews/:id
// @access  Public
exports.getReview = async (req, res, next) => {
  try {
    const review = await Review.findByPk(req.params.id, {
      include: [
        {
          model: User,
          as: 'reviewer',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: User,
          as: 'seller',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: Ad,
          as: 'ad',
        },
      ],
    });

    if (!review) {
      return res.status(404).json({
        success: false,
        message: 'Review not found',
      });
    }

    res.status(200).json({
      success: true,
      data: review,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create review
// @route   POST /api/v1/reviews
// @access  Private
exports.createReview = async (req, res, next) => {
  try {
    // Set user_id from authenticated user
    req.body.user_id = req.user.id;

    // Get the ad to determine seller
    const ad = await Ad.findByPk(req.body.ad_id);
    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    req.body.seller_id = ad.user_id;

    // Check if user already reviewed this ad
    const existingReview = await Review.findOne({
      where: {
        ad_id: req.body.ad_id,
        user_id: req.user.id,
      },
    });

    if (existingReview) {
      return res.status(400).json({
        success: false,
        message: 'You have already reviewed this ad',
      });
    }

    const review = await Review.create(req.body);

    // Fetch complete review with associations
    const completeReview = await Review.findByPk(review.id, {
      include: [
        {
          model: User,
          as: 'reviewer',
          attributes: ['id', 'name', 'avatar'],
        },
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug'],
        },
      ],
    });

    res.status(201).json({
      success: true,
      data: completeReview,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update review
// @route   PUT /api/v1/reviews/:id
// @access  Private
exports.updateReview = async (req, res, next) => {
  try {
    const review = await Review.findByPk(req.params.id);

    if (!review) {
      return res.status(404).json({
        success: false,
        message: 'Review not found',
      });
    }

    // Only review owner can update
    if (review.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this review',
      });
    }

    await review.update(req.body);

    res.status(200).json({
      success: true,
      data: review,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete review
// @route   DELETE /api/v1/reviews/:id
// @access  Private
exports.deleteReview = async (req, res, next) => {
  try {
    const review = await Review.findByPk(req.params.id);

    if (!review) {
      return res.status(404).json({
        success: false,
        message: 'Review not found',
      });
    }

    // Only review owner or admin can delete
    if (review.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this review',
      });
    }

    await review.destroy();

    res.status(200).json({
      success: true,
      message: 'Review deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Approve review (Admin only)
// @route   PUT /api/v1/reviews/:id/approve
// @access  Private/Admin
exports.approveReview = async (req, res, next) => {
  try {
    const review = await Review.findByPk(req.params.id);

    if (!review) {
      return res.status(404).json({
        success: false,
        message: 'Review not found',
      });
    }

    await review.update({ is_approved: true });

    res.status(200).json({
      success: true,
      data: review,
    });
  } catch (error) {
    next(error);
  }
};

