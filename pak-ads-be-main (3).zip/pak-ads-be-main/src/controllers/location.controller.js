const Location = require('../models/Location');
const { Op } = require('sequelize');

// @desc    Get all locations
// @route   GET /api/v1/locations
// @access  Public
exports.getLocations = async (req, res, next) => {
  try {
    const { type, parent_id, search, is_active } = req.query;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 100;
    const offset = (page - 1) * limit;

    const where = {};
    
    if (type) {
      where.type = type;
    }
    
    if (parent_id !== undefined) {
      where.parent_id = parent_id === 'null' ? null : parent_id;
    }
    
    if (search) {
      where.name = { [Op.iLike]: `%${search}%` };
    }
    
    if (is_active !== undefined) {
      where.is_active = is_active === 'true';
    }

    const { count, rows: locations } = await Location.findAndCountAll({
      where,
      limit,
      offset,
      order: [['display_order', 'ASC'], ['name', 'ASC']],
    });

    res.status(200).json({
      success: true,
      count: locations.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: locations,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get location tree (hierarchical)
// @route   GET /api/v1/locations/tree
// @access  Public
exports.getLocationTree = async (req, res, next) => {
  try {
    const locations = await Location.findAll({
      where: { parent_id: null, is_active: true },
      order: [['display_order', 'ASC'], ['name', 'ASC']],
      include: [
        {
          model: Location,
          as: 'sublocations',
          where: { is_active: true },
          required: false,
        },
      ],
    });

    res.status(200).json({
      success: true,
      data: locations,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single location
// @route   GET /api/v1/locations/:id
// @access  Public
exports.getLocation = async (req, res, next) => {
  try {
    const location = await Location.findByPk(req.params.id, {
      include: [
        {
          model: Location,
          as: 'sublocations',
        },
        {
          model: Location,
          as: 'parent',
        },
      ],
    });

    if (!location) {
      return res.status(404).json({
        success: false,
        message: 'Location not found',
      });
    }

    res.status(200).json({
      success: true,
      data: location,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create location
// @route   POST /api/v1/locations
// @access  Private/Admin
exports.createLocation = async (req, res, next) => {
  try {
    const location = await Location.create(req.body);

    res.status(201).json({
      success: true,
      data: location,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update location
// @route   PUT /api/v1/locations/:id
// @access  Private/Admin
exports.updateLocation = async (req, res, next) => {
  try {
    const location = await Location.findByPk(req.params.id);

    if (!location) {
      return res.status(404).json({
        success: false,
        message: 'Location not found',
      });
    }

    await location.update(req.body);

    res.status(200).json({
      success: true,
      data: location,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete location
// @route   DELETE /api/v1/locations/:id
// @access  Private/Admin
exports.deleteLocation = async (req, res, next) => {
  try {
    const location = await Location.findByPk(req.params.id);

    if (!location) {
      return res.status(404).json({
        success: false,
        message: 'Location not found',
      });
    }

    await location.destroy();

    res.status(200).json({
      success: true,
      message: 'Location deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

