const { InvestmentPlan, UserPlan, Deposit, User } = require('../models');
const logger = require('../config/logger');
const { distributeDailyROIEarnings } = require('../utils/earningService');

/**
 * @desc    Get all investment plans
 * @route   GET /api/v1/plans
 * @access  Public
 */
exports.getPlans = async (req, res, next) => {
  try {
    const plans = await InvestmentPlan.findAll({
      where: { is_active: true },
      order: [['investment_amount', 'ASC']],
    });

    res.status(200).json({
      success: true,
      data: plans,
    });
  } catch (error) {
    logger.error('Error fetching investment plans:', error);
    next(error);
  }
};

/**
 * @desc    Get my active investment plan
 * @route   GET /api/v1/plans/my-plan
 * @access  Private
 */
exports.getMyPlan = async (req, res, next) => {
  try {
    const activePlan = await UserPlan.findOne({
      where: {
        user_id: req.user.id,
        status: 'active',
      },
      include: [
        {
          model: InvestmentPlan,
          as: 'plan',
        },
      ],
    });

    let nextEarningAt = null;
    let timerRemainingMs = null;

    if (activePlan) {
      const lastEarning = activePlan.last_earning_at || activePlan.activated_at;
      nextEarningAt = new Date(new Date(lastEarning).getTime() + (24 * 60 * 60 * 1000));
      timerRemainingMs = Math.max(0, nextEarningAt.getTime() - new Date().getTime());
    }

    res.status(200).json({
      success: true,
      data: activePlan ? {
        ...activePlan.toJSON(),
        timer: {
          next_earning_at: nextEarningAt,
          remaining_ms: timerRemainingMs,
          total_cycle_ms: 24 * 60 * 60 * 1000
        }
      } : null,
    });
  } catch (error) {
    logger.error('Error fetching user active plan:', error);
    next(error);
  }
};

/**
 * @desc    Purchase (request) an investment plan
 * @route   POST /api/v1/plans/purchase
 * @access  Private
 */
exports.purchasePlan = async (req, res, next) => {
  try {
    const { planId, paymentMethod, transactionId, description } = req.body;
    const userId = req.user.id;

    // 1. Check if plan exists
    const plan = await InvestmentPlan.findByPk(planId);
    if (!plan) {
      return res.status(404).json({
        success: false,
        message: req.t('PLAN_NOT_FOUND'),
      });
    }

    // 2. Check if user already has an active plan
    const activePlan = await UserPlan.findOne({
      where: {
        user_id: userId,
        status: 'active',
      },
    });

    if (activePlan) {
      return res.status(400).json({
        success: false,
        message: req.t('ALREADY_HAS_ACTIVE_PLAN'),
      });
    }

    // 3. Create a Deposit record linked to the plan
    // Get proof image URL if uploaded
    let proofImageUrl = null;
    if (req.file) {
      proofImageUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
    }

    const deposit = await Deposit.create({
      user_id: userId,
      plan_id: planId,
      amount: plan.investment_amount,
      payment_method: paymentMethod,
      transaction_id: transactionId,
      description: description || `Purchase request for ${plan.name}`,
      proof_image_url: proofImageUrl,
      status: 'pending',
    });

    res.status(201).json({
      success: true,
      message: req.t('PURCHASE_SUCCESS'),
      data: {
        depositId: deposit.id,
        planName: plan.name,
        amount: plan.investment_amount,
        status: 'pending',
      },
    });
  } catch (error) {
    logger.error('Error purchasing investment plan:', error);
    next(error);
  }
};

