const { User, Earning, DailyReferralBonus, Deposit } = require('../models');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const constants = require('../config/constants');
const logger = require('../config/logger');
const { hasApprovedDeposit } = require('../utils/depositGuard');

/**
 * @desc    Check and award daily referral bonuses
 * @route   POST /api/daily-referral-bonus/check
 * @access  Private (User)
 */
exports.checkAndAwardDailyBonus = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const userId = req.user.id;
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Start of day
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999); // End of day

    // Require at least one approved deposit before awarding referral bonuses
    const depositApproved = await hasApprovedDeposit(userId, transaction);
    if (!depositApproved) {
      await transaction.rollback();
      return res.status(403).json({
        success: false,
        code: 'DEPOSIT_REQUIRED',
        message: 'You must have at least one approved deposit to earn referral bonuses',
        help: 'Submit a deposit and wait for admin approval, then try again.'
      });
    }

    // Get user's referrals made today
    const todayReferrals = await User.count({
      where: {
        referred_by: userId,
        created_at: {
          [Op.between]: [today, endOfDay],
        },
      },
      transaction,
    });

    if (todayReferrals === 0) {
      await transaction.rollback();
      return res.status(200).json({
        success: true,
        message: 'No referrals made today',
        data: {
          todayReferrals: 0,
          bonusEarned: 0,
          bonusAmount: 0,
        },
      });
    }

    // Check if bonus already awarded for today
    const existingBonus = await DailyReferralBonus.findOne({
      where: {
        user_id: userId,
        bonus_date: today,
      },
      transaction,
    });

    if (existingBonus) {
      await transaction.rollback();
      return res.status(200).json({
        success: true,
        message: 'Daily bonus already awarded for today',
        data: {
          todayReferrals,
          bonusEarned: existingBonus.bonus_count,
          bonusAmount: parseFloat(existingBonus.bonus_amount),
          alreadyAwarded: true,
        },
      });
    }

    // Calculate bonus based on referral count
    const bonusCalculation = calculateDailyBonus(todayReferrals);
    
    if (bonusCalculation.totalBonusCount === 0) {
      await transaction.rollback();
      return res.status(200).json({
        success: true,
        message: `You have ${todayReferrals} referrals today. You need ${constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD} referrals to get your first bonus!`,
        data: {
          todayReferrals,
          bonusEarned: 0,
          bonusAmount: 0,
          nextThreshold: constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD - todayReferrals,
        },
      });
    }

    // Get user's current balance
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_earnings'],
      transaction,
    });

    if (!user) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Create earning record for the bonus
    const earning = await Earning.create({
      user_id: userId,
      amount: bonusCalculation.totalBonusAmount,
      type: 'daily_referral_bonus',
      level: null,
      from_user_id: null,
      description: `Daily referral bonus: ${bonusCalculation.totalBonusCount} bonus(es) for ${todayReferrals} referrals on ${today.toDateString()}`,
      status: 'completed',
      metadata: JSON.stringify({
        referralsCount: todayReferrals,
        bonusCount: bonusCalculation.totalBonusCount,
        bonusBreakdown: bonusCalculation.breakdown,
        date: today.toISOString().split('T')[0],
      }),
    }, { transaction });

    // Create daily referral bonus record
    await DailyReferralBonus.create({
      user_id: userId,
      bonus_date: today,
      referrals_count: todayReferrals,
      bonus_amount: bonusCalculation.totalBonusAmount,
      bonus_count: bonusCalculation.totalBonusCount,
      earning_id: earning.id,
    }, { transaction });

    // Update user's wallet balance and total earnings
    await user.update({
      wallet_balance: parseFloat(user.wallet_balance) + bonusCalculation.totalBonusAmount,
      total_earnings: parseFloat(user.total_earnings) + bonusCalculation.totalBonusAmount,
    }, { transaction });

    await transaction.commit();

    res.status(200).json({
      success: true,
      message: `Congratulations! You earned ${bonusCalculation.totalBonusCount} daily referral bonus(es) worth ${bonusCalculation.totalBonusAmount} PKR!`,
      data: {
        todayReferrals,
        bonusEarned: bonusCalculation.totalBonusCount,
        bonusAmount: {
          pkr: bonusCalculation.totalBonusAmount,
          usd: constants.convertPkrToUsd(bonusCalculation.totalBonusAmount),
        },
        bonusBreakdown: bonusCalculation.breakdown,
        remainingBalance: {
          pkr: parseFloat(user.wallet_balance) + bonusCalculation.totalBonusAmount,
          usd: constants.convertPkrToUsd(parseFloat(user.wallet_balance) + bonusCalculation.totalBonusAmount),
        },
        earningId: earning.id,
      },
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error checking daily referral bonus:', error);
    next(error);
  }
};

/**
 * @desc    Get daily referral bonus history
 * @route   GET /api/daily-referral-bonus/history?page=1&limit=10
 * @access  Private (User)
 */
exports.getDailyBonusHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows } = await DailyReferralBonus.findAndCountAll({
      where: { user_id: userId },
      include: [
        {
          model: Earning,
          as: 'earning',
          attributes: ['id', 'amount', 'description', 'created_at'],
        },
      ],
      order: [['bonus_date', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    // Calculate total bonuses earned
    const totalBonuses = await DailyReferralBonus.sum('bonus_count', {
      where: { user_id: userId },
    });

    const totalBonusAmount = await DailyReferralBonus.sum('bonus_amount', {
      where: { user_id: userId },
    });

    res.status(200).json({
      success: true,
      data: {
        bonuses: rows.map(bonus => ({
          id: bonus.id,
          bonusDate: bonus.bonus_date,
          referralsCount: bonus.referrals_count,
          bonusCount: bonus.bonus_count,
          bonusAmount: {
            pkr: parseFloat(bonus.bonus_amount),
            usd: constants.convertPkrToUsd(parseFloat(bonus.bonus_amount)),
          },
          earning: bonus.earning,
          createdAt: bonus.created_at,
        })),
        summary: {
          totalBonuses,
          totalBonusAmount: {
            pkr: parseFloat(totalBonusAmount || 0),
            usd: constants.convertPkrToUsd(parseFloat(totalBonusAmount || 0)),
          },
        },
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting daily bonus history:', error);
    next(error);
  }
};

/**
 * @desc    Get today's referral status
 * @route   GET /api/daily-referral-bonus/status
 * @access  Private (User)
 */
exports.getTodayReferralStatus = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999);

    // FIXED: Count referrals by deposit approval date (not user creation date)
    // This matches the auto-award logic and ensures progress bar shows correct count
    const todayReferrals = await Deposit.count({
      include: [
        {
          model: User,
          as: 'user',
          where: {
            referred_by: userId,
          },
          attributes: [],
        },
      ],
      where: {
        status: 'approved',
        approved_at: {
          [Op.between]: [today, endOfDay],
        },
      },
      distinct: true,
      col: 'user_id',
    });

    // Check if bonus already awarded
    const existingBonus = await DailyReferralBonus.findOne({
      where: {
        user_id: userId,
        bonus_date: today,
      },
    });

    // Calculate potential bonus
    const potentialBonus = calculateDailyBonus(todayReferrals);

    // Calculate progress to next bonus
    let progressToNextBonus = 0;
    let referralsNeededForNextBonus = 0;

    if (todayReferrals < constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD) {
      referralsNeededForNextBonus = constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD - todayReferrals;
      progressToNextBonus = (todayReferrals / constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD) * 100;
    } else {
      const nextThreshold = Math.ceil((todayReferrals - constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD) / constants.DAILY_REFERRAL_BONUS.SUBSEQUENT_BONUS_THRESHOLD) * constants.DAILY_REFERRAL_BONUS.SUBSEQUENT_BONUS_THRESHOLD + constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD;
      referralsNeededForNextBonus = nextThreshold - todayReferrals;
      progressToNextBonus = ((todayReferrals - constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD) % constants.DAILY_REFERRAL_BONUS.SUBSEQUENT_BONUS_THRESHOLD / constants.DAILY_REFERRAL_BONUS.SUBSEQUENT_BONUS_THRESHOLD) * 100;
    }

    res.status(200).json({
      success: true,
      data: {
        currentDate: today.toISOString().split('T')[0], // YYYY-MM-DD format for frontend to detect date changes
        todayReferrals,
        bonusAwarded: !!existingBonus,
        bonusAwardedCount: existingBonus ? existingBonus.bonus_count : 0,
        bonusAwardedAmount: existingBonus ? {
          pkr: parseFloat(existingBonus.bonus_amount),
          usd: constants.convertPkrToUsd(parseFloat(existingBonus.bonus_amount)),
        } : null,
        potentialBonus: {
          count: potentialBonus.totalBonusCount,
          amount: {
            pkr: potentialBonus.totalBonusAmount,
            usd: constants.convertPkrToUsd(potentialBonus.totalBonusAmount),
          },
          breakdown: potentialBonus.breakdown,
        },
        progress: {
          toNextBonus: progressToNextBonus,
          referralsNeeded: referralsNeededForNextBonus,
        },
        bonusRules: {
          firstBonusThreshold: constants.DAILY_REFERRAL_BONUS.FIRST_BONUS_THRESHOLD,
          subsequentBonusThreshold: constants.DAILY_REFERRAL_BONUS.SUBSEQUENT_BONUS_THRESHOLD,
          bonusAmount: {
            pkr: constants.DAILY_REFERRAL_BONUS.BONUS_AMOUNT_PKR,
            usd: constants.DAILY_REFERRAL_BONUS.BONUS_AMOUNT_USD,
          },
        },
      },
    });
  } catch (error) {
    logger.error('Error getting today referral status:', error);
    next(error);
  }
};

/**
 * Helper function to calculate daily bonus based on referral count
 * @param {number} referralCount - Number of referrals made today
 * @returns {object} - Bonus calculation result
 */
function calculateDailyBonus(referralCount) {
  const { FIRST_BONUS_THRESHOLD, SUBSEQUENT_BONUS_THRESHOLD, BONUS_AMOUNT_PKR, MAX_REFERRALS_FOR_BONUS } = constants.DAILY_REFERRAL_BONUS;
  
  let totalBonusCount = 0;
  let totalBonusAmount = 0;
  const breakdown = [];

  // Cap referrals at maximum allowed for bonus (8 referrals)
  const cappedReferralCount = Math.min(referralCount, MAX_REFERRALS_FOR_BONUS);

  // New bonus structure:
  // 3 referrals = 1 bonus ($1)
  // 3 to 6 referrals = 1 bonus ($1) 
  // 6 to 8 referrals = 1 bonus ($1)
  // Total: 3 bonuses maximum for 8 referrals

  if (cappedReferralCount >= 3) {
    totalBonusCount = 1; // First bonus at 3 referrals
    totalBonusAmount = BONUS_AMOUNT_PKR;
    
    breakdown.push({
      bonusNumber: 1,
      thresholdReached: 3,
      bonusAmount: BONUS_AMOUNT_PKR,
      description: `First bonus for 3 referrals`,
    });

    if (cappedReferralCount >= 6) {
      totalBonusCount = 2; // Second bonus at 6 referrals
      totalBonusAmount = 2 * BONUS_AMOUNT_PKR;
      
      breakdown.push({
        bonusNumber: 2,
        thresholdReached: 6,
        bonusAmount: BONUS_AMOUNT_PKR,
        description: `Second bonus for 6 referrals`,
      });

      if (cappedReferralCount >= 8) {
        totalBonusCount = 3; // Third bonus at 8 referrals
        totalBonusAmount = 3 * BONUS_AMOUNT_PKR;
        
        breakdown.push({
          bonusNumber: 3,
          thresholdReached: 8,
          bonusAmount: BONUS_AMOUNT_PKR,
          description: `Third bonus for 8 referrals`,
        });
      }
    }
  }

  return {
    totalBonusCount,
    totalBonusAmount,
    breakdown,
    cappedReferralCount,
    originalReferralCount: referralCount,
  };
}

/**
 * Auto-award daily bonus for referrer when their referral is approved
 * This is called automatically from admin approval
 * @param {number} referrerId - ID of the user who referred the new user
 * @returns {Promise<object>} - Bonus result
 */
exports.autoAwardDailyBonus = async (referrerId) => {
  const transaction = await sequelize.transaction();
  
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999);

    // CRITICAL FIX: Count referrals based on deposits approved TODAY, not user creation date
    // This ensures bonus is awarded when deposits are approved, not when users sign up
    const todayReferrals = await Deposit.count({
      include: [
        {
          model: User,
          as: 'user',
          where: {
            referred_by: referrerId,
          },
          attributes: [],
        },
      ],
      where: {
        status: 'approved',
        approved_at: {
          [Op.between]: [today, endOfDay],
        },
      },
      transaction,
      distinct: true,
      col: 'user_id',
    });

    logger.info(`Auto-award daily bonus check for referrer ${referrerId}: Found ${todayReferrals} approved deposits today`);

    if (todayReferrals === 0) {
      await transaction.rollback();
      return { awarded: false, reason: 'no_referrals_today' };
    }

    // Check if user has approved deposit
    const depositApproved = await hasApprovedDeposit(referrerId, transaction);
    if (!depositApproved) {
      await transaction.rollback();
      return { awarded: false, reason: 'deposit_required' };
    }

    // Check if bonus already awarded for today
    const existingBonus = await DailyReferralBonus.findOne({
      where: {
        user_id: referrerId,
        bonus_date: today,
      },
      transaction,
    });

    // Calculate bonus based on referral count
    const bonusCalculation = calculateDailyBonus(todayReferrals);
    
    if (bonusCalculation.totalBonusCount === 0) {
      await transaction.rollback();
      return { awarded: false, reason: 'not_enough_referrals', todayReferrals };
    }

    // CRITICAL FIX: If bonus already awarded, calculate only the difference
    if (existingBonus) {
      const alreadyAwardedCount = existingBonus.bonus_count;
      const newBonusCount = bonusCalculation.totalBonusCount;
      
      // If no new bonuses, skip
      if (newBonusCount <= alreadyAwardedCount) {
        await transaction.rollback();
        return { awarded: false, reason: 'no_new_bonus', existingBonus };
      }
      
      // Award only the difference
      const bonusToAward = newBonusCount - alreadyAwardedCount;
      const amountToAward = bonusToAward * constants.DAILY_REFERRAL_BONUS.BONUS_AMOUNT_PKR;
      
      logger.info(`Incremental bonus for referrer ${referrerId}: Awarding ${bonusToAward} additional bonus(es) worth ${amountToAward} PKR`);
      
      // Get referrer's current balance
      const referrer = await User.findByPk(referrerId, {
        attributes: ['id', 'wallet_balance', 'total_earnings'],
        transaction,
      });

      if (!referrer) {
        await transaction.rollback();
        return { awarded: false, reason: 'referrer_not_found' };
      }

      // Create earning record for the incremental bonus
      const earning = await Earning.create({
        user_id: referrerId,
        amount: amountToAward,
        type: 'daily_referral_bonus',
        level: null,
        from_user_id: null,
        description: `Daily referral bonus: ${bonusToAward} additional bonus(es) for reaching ${todayReferrals} referrals on ${today.toDateString()}`,
        status: 'completed',
        metadata: JSON.stringify({
          referralsCount: todayReferrals,
          bonusCount: bonusToAward,
          totalBonusCount: bonusCalculation.totalBonusCount,
          previousBonusCount: alreadyAwardedCount,
          date: today.toISOString().split('T')[0],
        }),
      }, { transaction });

      // Update existing bonus record
      await existingBonus.update({
        referrals_count: todayReferrals,
        bonus_amount: bonusCalculation.totalBonusAmount,
        bonus_count: bonusCalculation.totalBonusCount,
      }, { transaction });

      // Update user's wallet balance and total earnings
      await referrer.update({
        wallet_balance: parseFloat(referrer.wallet_balance) + amountToAward,
        total_earnings: parseFloat(referrer.total_earnings) + amountToAward,
      }, { transaction });

      await transaction.commit();

      logger.info(`Auto-awarded incremental daily bonus to referrer ${referrerId}: ${bonusToAward} bonus(es) worth ${amountToAward} PKR`);

      return {
        awarded: true,
        bonusCount: bonusToAward,
        bonusAmount: amountToAward,
        referralsCount: todayReferrals,
        incremental: true,
      };
    }

    // First time bonus award
    const referrer = await User.findByPk(referrerId, {
      attributes: ['id', 'wallet_balance', 'total_earnings'],
      transaction,
    });

    if (!referrer) {
      await transaction.rollback();
      return { awarded: false, reason: 'referrer_not_found' };
    }

    // Create earning record for the bonus
    const earning = await Earning.create({
      user_id: referrerId,
      amount: bonusCalculation.totalBonusAmount,
      type: 'daily_referral_bonus',
      level: null,
      from_user_id: null,
      description: `Daily referral bonus: ${bonusCalculation.totalBonusCount} bonus(es) for ${todayReferrals} referrals on ${today.toDateString()}`,
      status: 'completed',
      metadata: JSON.stringify({
        referralsCount: todayReferrals,
        bonusCount: bonusCalculation.totalBonusCount,
        bonusBreakdown: bonusCalculation.breakdown,
        date: today.toISOString().split('T')[0],
      }),
    }, { transaction });

    // Create daily referral bonus record
    await DailyReferralBonus.create({
      user_id: referrerId,
      bonus_date: today,
      referrals_count: todayReferrals,
      bonus_amount: bonusCalculation.totalBonusAmount,
      bonus_count: bonusCalculation.totalBonusCount,
      earning_id: earning.id,
    }, { transaction });

    // Update user's wallet balance and total earnings
    await referrer.update({
      wallet_balance: parseFloat(referrer.wallet_balance) + bonusCalculation.totalBonusAmount,
      total_earnings: parseFloat(referrer.total_earnings) + bonusCalculation.totalBonusAmount,
    }, { transaction });

    await transaction.commit();

    logger.info(`Auto-awarded daily bonus to referrer ${referrerId}: ${bonusCalculation.totalBonusCount} bonus(es) worth ${bonusCalculation.totalBonusAmount} PKR`);

    return {
      awarded: true,
      bonusCount: bonusCalculation.totalBonusCount,
      bonusAmount: bonusCalculation.totalBonusAmount,
      referralsCount: todayReferrals,
    };
  } catch (error) {
    await transaction.rollback();
    logger.error(`Error auto-awarding daily bonus to referrer ${referrerId}:`, error);
    return { awarded: false, reason: 'error', error: error.message };
  }
};

module.exports = {
  checkAndAwardDailyBonus: exports.checkAndAwardDailyBonus,
  getDailyBonusHistory: exports.getDailyBonusHistory,
  getTodayReferralStatus: exports.getTodayReferralStatus,
  autoAwardDailyBonus: exports.autoAwardDailyBonus,
  calculateDailyBonus,
};
