const Category = require('../models/Category');
const { Op } = require('sequelize');

// @desc    Get all categories
// @route   GET /api/v1/categories
// @access  Public
exports.getCategories = async (req, res, next) => {
  try {
    const { parent_id, search, is_active } = req.query;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 50;
    const offset = (page - 1) * limit;

    const where = {};
    
    if (parent_id !== undefined) {
      where.parent_id = parent_id === 'null' ? null : parent_id;
    }
    
    if (search) {
      where.name = { [Op.iLike]: `%${search}%` };
    }
    
    if (is_active !== undefined) {
      where.is_active = is_active === 'true';
    }

    const { count, rows: categories } = await Category.findAndCountAll({
      where,
      limit,
      offset,
      order: [['display_order', 'ASC'], ['name', 'ASC']],
      include: [
        {
          model: Category,
          as: 'subcategories',
          where: { is_active: true },
          required: false,
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: categories.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: categories,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get category tree (hierarchical)
// @route   GET /api/v1/categories/tree
// @access  Public
exports.getCategoryTree = async (req, res, next) => {
  try {
    const categories = await Category.findAll({
      where: { parent_id: null, is_active: true },
      order: [['display_order', 'ASC'], ['name', 'ASC']],
      include: [
        {
          model: Category,
          as: 'subcategories',
          where: { is_active: true },
          required: false,
        },
      ],
    });

    res.status(200).json({
      success: true,
      data: categories,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single category
// @route   GET /api/v1/categories/:id
// @access  Public
exports.getCategory = async (req, res, next) => {
  try {
    const category = await Category.findByPk(req.params.id, {
      include: [
        {
          model: Category,
          as: 'subcategories',
        },
        {
          model: Category,
          as: 'parent',
        },
      ],
    });

    if (!category) {
      return res.status(404).json({
        success: false,
        message: 'Category not found',
      });
    }

    res.status(200).json({
      success: true,
      data: category,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create category
// @route   POST /api/v1/categories
// @access  Private/Admin
exports.createCategory = async (req, res, next) => {
  try {
    const category = await Category.create(req.body);

    res.status(201).json({
      success: true,
      data: category,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update category
// @route   PUT /api/v1/categories/:id
// @access  Private/Admin
exports.updateCategory = async (req, res, next) => {
  try {
    const category = await Category.findByPk(req.params.id);

    if (!category) {
      return res.status(404).json({
        success: false,
        message: 'Category not found',
      });
    }

    await category.update(req.body);

    res.status(200).json({
      success: true,
      data: category,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete category
// @route   DELETE /api/v1/categories/:id
// @access  Private/Admin
exports.deleteCategory = async (req, res, next) => {
  try {
    const category = await Category.findByPk(req.params.id);

    if (!category) {
      return res.status(404).json({
        success: false,
        message: 'Category not found',
      });
    }

    await category.destroy();

    res.status(200).json({
      success: true,
      message: 'Category deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

