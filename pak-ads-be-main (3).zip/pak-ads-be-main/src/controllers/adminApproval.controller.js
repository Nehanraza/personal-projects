const { User } = require('../models');
const logger = require('../config/logger');
const commissionService = require('../utils/commissionService');
const { autoAwardDailyBonus } = require('./dailyReferralBonus.controller');
const { autoAwardRankReward } = require('./rankReward.controller');
const { autoAwardDepositReward } = require('./depositReward.controller');

// @desc    Get all pending users for approval
// @route   GET /api/v1/admin/approval/pending
// @access  Private/Admin
exports.getPendingUsers = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const users = await User.findAndCountAll({
      where: {
        is_admin_approved: false,
        role: 'user', // Only regular users need approval
      },
      attributes: [
        'id', 'name', 'email', 'phone', 'referral_code', 
        'referred_by', 'joining_fee_paid', 'joining_fee_paid_at',
        'created_at', 'is_active'
      ],
      include: [
        {
          model: User,
          as: 'referrer',
          attributes: ['id', 'name', 'email'],
          required: false,
        },
      ],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.status(200).json({
      success: true,
      data: users.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(users.count / limit),
        totalUsers: users.count,
        hasNext: offset + parseInt(limit) < users.count,
        hasPrev: page > 1,
      },
    });
  } catch (error) {
    logger.error('Error fetching pending users:', error);
    next(error);
  }
};

// @desc    Get all approved users
// @route   GET /api/v1/admin/approval/approved
// @access  Private/Admin
exports.getApprovedUsers = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const users = await User.findAndCountAll({
      where: {
        is_admin_approved: true,
        role: 'user',
      },
      attributes: [
        'id', 'name', 'email', 'phone', 'referral_code', 
        'referred_by', 'joining_fee_paid', 'joining_fee_paid_at',
        'created_at', 'is_active', 'is_email_verified'
      ],
      include: [
        {
          model: User,
          as: 'referrer',
          attributes: ['id', 'name', 'email'],
          required: false,
        },
      ],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.status(200).json({
      success: true,
      data: users.rows,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(users.count / limit),
        totalUsers: users.count,
        hasNext: offset + parseInt(limit) < users.count,
        hasPrev: page > 1,
      },
    });
  } catch (error) {
    logger.error('Error fetching approved users:', error);
    next(error);
  }
};

// @desc    Get user approval statistics
// @route   GET /api/v1/admin/approval/stats
// @access  Private/Admin
exports.getUserApprovalStats = async (req, res, next) => {
  try {
    const totalUsers = await User.count({ where: { role: 'user' } });
    const pendingUsers = await User.count({ 
      where: { 
        is_admin_approved: false, 
        role: 'user' 
      } 
    });
    const approvedUsers = await User.count({ 
      where: { 
        is_admin_approved: true, 
        role: 'user' 
      } 
    });
    const activeUsers = await User.count({ 
      where: { 
        is_admin_approved: true, 
        is_active: true,
        role: 'user' 
      } 
    });

    res.status(200).json({
      success: true,
      data: {
        totalUsers,
        pendingUsers,
        approvedUsers,
        activeUsers,
        approvalRate: totalUsers > 0 ? ((approvedUsers / totalUsers) * 100).toFixed(2) : 0,
      },
    });
  } catch (error) {
    logger.error('Error fetching approval stats:', error);
    next(error);
  }
};

// @desc    Approve a user
// @route   PUT /api/v1/admin/approval/:id/approve
// @access  Private/Admin
exports.approveUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    const adminId = req.user.id;

    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    if (user.is_admin_approved) {
      return res.status(400).json({
        success: false,
        message: 'User is already approved',
      });
    }

    // Approve user and mark email as verified
    await user.update({
      is_admin_approved: true,
      is_email_verified: true, // Admin approval means email is verified
      email_verification_token: null,
      email_verification_expire: null,
    });

    // Reload user to get updated data
    await user.reload();

    // CRITICAL FIX: If user was referred, increment their referrer's today_direct_joins
    // This unlocks second ad views for the referrer
    if (user.referred_by) {
      try {
        const referrer = await User.findByPk(user.referred_by);
        if (referrer) {
          await referrer.incrementDailyDirectJoins();
          logger.info(`Incremented today_direct_joins for referrer ${user.referred_by} after approving user ${user.id}`);
        }
      } catch (error) {
        logger.error(`Error incrementing daily direct joins for referrer:`, error);
        // Don't fail the approval if increment fails
      }
    }

    // CRITICAL FIX: Distribute commissions now that user is approved
    // IMPORTANT: We call this AFTER updating and reloading user
    try {
      logger.info(`Starting commission distribution for approved user ${user.id}...`);
      const commissionResult = await commissionService.distributeApprovalCommissions(user.id);
      logger.info(`Commission distribution result for approved user ${user.id}:`, JSON.stringify(commissionResult, null, 2));
    } catch (error) {
      logger.error(`Error distributing commissions for approved user ${user.id}:`, error);
      // Don't fail the approval if commission distribution fails
    }

    // CRITICAL FIX: Auto-award daily referral bonus if referrer has 3+ referrals today
    // This automatically adds bonus to wallet when 3+ direct joinings are approved
    if (user.referred_by) {
      try {
        const bonusResult = await autoAwardDailyBonus(user.referred_by);
        if (bonusResult.awarded) {
          logger.info(`Auto-awarded daily bonus to referrer ${user.referred_by}: ${bonusResult.bonusCount} bonus(es) worth ${bonusResult.bonusAmount} PKR`);
        }
      } catch (error) {
        logger.error(`Error auto-awarding daily bonus to referrer ${user.referred_by}:`, error);
        // Don't fail the approval if bonus award fails
      }
    }

    // CRITICAL FIX: Auto-award rank reward and deposit reward if referrer reaches threshold
    // These rewards are automatically added to wallet
    if (user.referred_by) {
      try {
        // Auto-award rank reward (only when deposit is approved - will check in function)
        const rankResult = await autoAwardRankReward(user.referred_by);
        if (rankResult.awarded) {
          if (rankResult.ranksAwarded > 1) {
            logger.info(`Auto-awarded ${rankResult.ranksAwarded} rank rewards to referrer ${user.referred_by}: ${rankResult.totalRewardAmount} PKR total for ${rankResult.referralsCount} referrals (${rankResult.ranks.map(r => r.name).join(', ')})`);
          } else if (rankResult.ranksAwarded === 1) {
            logger.info(`Auto-awarded ${rankResult.ranks[0].name} reward to referrer ${user.referred_by}: ${rankResult.totalRewardAmount} PKR for ${rankResult.referralsCount} referrals`);
          }
        }

        // Auto-award deposit reward (when user reaches 15+ referrals after deposit)
        const depositResult = await autoAwardDepositReward(user.referred_by);
        if (depositResult.awarded) {
          logger.info(`Auto-awarded deposit reward to referrer ${user.referred_by}: ${depositResult.rewardAmount} PKR for ${depositResult.referralsCount} referrals`);
        }
      } catch (error) {
        logger.error(`Error auto-awarding rewards to referrer ${user.referred_by}:`, error);
        // Don't fail the approval if reward award fails
      }
    }

    logger.info(`User ${user.email} approved by admin ${adminId}`);

    res.status(200).json({
      success: true,
      message: 'User approved successfully',
      data: {
        id: user.id,
        name: user.name,
        email: user.email,
        is_admin_approved: true,
        is_email_verified: true,
      },
    });
  } catch (error) {
    logger.error(`Error approving user ${req.params.id}:`, error);
    next(error);
  }
};

// @desc    Reject a user
// @route   PUT /api/v1/admin/approval/:id/reject
// @access  Private/Admin
exports.rejectUser = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const adminId = req.user.id;

    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    if (user.is_admin_approved) {
      return res.status(400).json({
        success: false,
        message: 'User is already approved',
      });
    }

    // Deactivate user instead of deleting
    await user.update({
      is_active: false,
      is_admin_approved: false,
    });

    logger.info(`User ${user.email} rejected by admin ${adminId}. Reason: ${reason || 'No reason provided'}`);

    res.status(200).json({
      success: true,
      message: 'User rejected successfully',
      data: {
        id: user.id,
        name: user.name,
        email: user.email,
        is_active: false,
        rejection_reason: reason,
      },
    });
  } catch (error) {
    logger.error(`Error rejecting user ${req.params.id}:`, error);
    next(error);
  }
};
