const { User, Earning, DepositReward, Deposit } = require('../models');
const { sequelize } = require('../config/database');
const constants = require('../config/constants');
const logger = require('../config/logger');
const { Op } = require('sequelize');

/**
 * @desc    Check and award deposit reward if user has 15 referrals after deposit
 * @route   POST /api/deposit-rewards/check
 * @access  Private (User)
 */
exports.checkAndAwardDepositReward = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const userId = req.user.id;

    // Get user's deposit status
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_earnings', 'total_referrals'],
      transaction,
    });

    if (!user) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if user has at least one approved deposit
    const approvedDeposit = await Deposit.findOne({
      where: {
        user_id: userId,
        status: 'approved',
      },
      order: [['created_at', 'DESC']],
      transaction,
    });

    if (!approvedDeposit) {
      await transaction.rollback();
      return res.status(200).json({
        success: true,
        message: 'No approved deposit found. Deposit required to earn this reward.',
        data: {
          hasDeposit: false,
          totalReferrals: user.total_referrals,
          requiredReferrals: constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD,
          rewardEarned: false,
        },
      });
    }

    // Check if user already got this reward
    const existingReward = await DepositReward.findOne({
      where: { user_id: userId },
      transaction,
    });

    if (existingReward) {
      await transaction.rollback();
      return res.status(200).json({
        success: true,
        message: 'Deposit reward already awarded',
        data: {
          rewardEarned: true,
          alreadyAwarded: true,
          rewardAmount: {
            pkr: parseFloat(existingReward.reward_amount),
            usd: constants.convertPkrToUsd(parseFloat(existingReward.reward_amount)),
          },
          referralsCount: existingReward.referrals_count,
          awardedAt: existingReward.created_at,
        },
      });
    }

    // Check if user has 15 or more referrals
    const currentReferrals = user.total_referrals;

    if (currentReferrals < constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD) {
      await transaction.rollback();
      const remaining = constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD - currentReferrals;
      return res.status(200).json({
        success: true,
        message: `You have ${currentReferrals} referrals. You need ${remaining} more referrals to earn the deposit reward!`,
        data: {
          totalReferrals: currentReferrals,
          requiredReferrals: constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD,
          remainingReferrals: remaining,
          rewardAmount: {
            pkr: constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
            usd: constants.DEPOSIT_REWARD.REWARD_AMOUNT_USD,
          },
          rewardEarned: false,
        },
      });
    }

    // User has 15+ referrals, award the reward
    const rewardAmount = constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR;

    // Create earning record
    const earning = await Earning.create({
      user_id: userId,
      amount: rewardAmount,
      type: 'deposit_reward',
      description: `Deposit reward: ${constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR} PKR for ${currentReferrals} referrals`,
      status: 'completed',
      metadata: JSON.stringify({
        referrals_count: currentReferrals,
        reward_type: 'deposit_reward',
      }),
    }, { transaction });

    // Create deposit reward record
    await DepositReward.create({
      user_id: userId,
      reward_amount: rewardAmount,
      referrals_count: currentReferrals,
      earning_id: earning.id,
    }, { transaction });

    // Update user's wallet balance and total earnings
    await user.update({
      wallet_balance: parseFloat(user.wallet_balance) + rewardAmount,
      total_earnings: parseFloat(user.total_earnings) + rewardAmount,
    }, { transaction });

    await transaction.commit();

    logger.info(`Deposit reward awarded: userId=${userId}, reward=${rewardAmount} PKR, referrals=${currentReferrals}`);

    res.status(200).json({
      success: true,
      message: `Congratulations! You earned ${constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR} PKR deposit reward for ${currentReferrals} referrals!`,
      data: {
        rewardEarned: true,
        rewardAmount: {
          pkr: rewardAmount,
          usd: constants.convertPkrToUsd(rewardAmount),
        },
        referralsCount: currentReferrals,
        remainingBalance: {
          pkr: parseFloat(user.wallet_balance) + rewardAmount,
          usd: constants.convertPkrToUsd(parseFloat(user.wallet_balance) + rewardAmount),
        },
        earningId: earning.id,
      },
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error checking deposit reward:', error);
    next(error);
  }
};

/**
 * @desc    Get deposit reward status
 * @route   GET /api/deposit-rewards/status
 * @access  Private (User)
 */
exports.getDepositRewardStatus = async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Get user info
    const user = await User.findByPk(userId, {
      attributes: ['id', 'total_referrals'],
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if user has approved deposit
    const approvedDeposit = await Deposit.findOne({
      where: {
        user_id: userId,
        status: 'approved',
      },
      order: [['created_at', 'DESC']],
    });

    // Check if reward already earned
    const existingReward = await DepositReward.findOne({
      where: { user_id: userId },
      attributes: ['id', 'reward_amount', 'referrals_count', 'created_at'],
    });

    const hasDeposit = !!approvedDeposit;
    const hasReward = !!existingReward;
    const currentReferrals = user.total_referrals;
    const remainingReferrals = constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD - currentReferrals;

    res.status(200).json({
      success: true,
      data: {
        hasDeposit,
        hasReward,
        totalReferrals: currentReferrals,
        requiredReferrals: constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD,
        remainingReferrals: Math.max(0, remainingReferrals),
        rewardAmount: {
          pkr: constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
          usd: constants.DEPOSIT_REWARD.REWARD_AMOUNT_USD,
        },
        progress: hasReward ? 100 : Math.min(100, (currentReferrals / constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD) * 100),
        rewardDetails: existingReward ? {
          amount: {
            pkr: parseFloat(existingReward.reward_amount),
            usd: constants.convertPkrToUsd(parseFloat(existingReward.reward_amount)),
          },
          referralsCount: existingReward.referrals_count,
          awardedAt: existingReward.created_at,
        } : null,
      },
    });
  } catch (error) {
    logger.error('Error getting deposit reward status:', error);
    next(error);
  }
};

/**
 * @desc    Get deposit reward history
 * @route   GET /api/deposit-rewards/history
 * @access  Private (User)
 */
exports.getDepositRewardHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const reward = await DepositReward.findOne({
      where: { user_id: userId },
      include: [
        {
          model: Earning,
          as: 'earning',
          attributes: ['id', 'amount', 'description', 'created_at'],
        },
      ],
      order: [['created_at', 'DESC']],
    });

    if (!reward) {
      return res.status(200).json({
        success: true,
        data: {
          reward: null,
          summary: {
            totalRewards: 0,
            totalRewardAmount: {
              pkr: 0,
              usd: 0,
            },
          },
        },
      });
    }

    res.status(200).json({
      success: true,
      data: {
        reward: {
          id: reward.id,
          rewardAmount: {
            pkr: parseFloat(reward.reward_amount),
            usd: constants.convertPkrToUsd(parseFloat(reward.reward_amount)),
          },
          referralsCount: reward.referrals_count,
          earning: reward.earning,
          createdAt: reward.created_at,
        },
        summary: {
          totalRewards: 1,
          totalRewardAmount: {
            pkr: parseFloat(reward.reward_amount),
            usd: constants.convertPkrToUsd(parseFloat(reward.reward_amount)),
          },
        },
      },
    });
  } catch (error) {
    logger.error('Error getting deposit reward history:', error);
    next(error);
  }
};

/**
 * Auto-award deposit reward when user reaches threshold
 * This is called automatically from admin approval
 * @param {number} userId - ID of the user who should get the reward
 * @returns {Promise<object>} - Reward result
 */
exports.autoAwardDepositReward = async (userId) => {
  const transaction = await sequelize.transaction();
  
  try {
    // Get user's deposit status
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_earnings', 'total_referrals'],
      transaction,
    });

    if (!user) {
      await transaction.rollback();
      return { awarded: false, reason: 'user_not_found' };
    }

    // Check if user has at least one approved deposit
    const approvedDeposit = await Deposit.findOne({
      where: {
        user_id: userId,
        status: 'approved',
      },
      order: [['created_at', 'DESC']],
      transaction,
    });

    if (!approvedDeposit) {
      await transaction.rollback();
      return { awarded: false, reason: 'no_deposit' };
    }

    // Check if user already got this reward
    const existingReward = await DepositReward.findOne({
      where: { user_id: userId },
      transaction,
    });

    if (existingReward) {
      await transaction.rollback();
      return { awarded: false, reason: 'already_awarded', existingReward };
    }

    // Check if user has 15 or more referrals
    const currentReferrals = user.total_referrals;

    if (currentReferrals < constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD) {
      await transaction.rollback();
      return { awarded: false, reason: 'not_enough_referrals', currentReferrals };
    }

    // Create earning record for the reward
    const earning = await Earning.create({
      user_id: userId,
      amount: constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
      type: 'deposit_reward',
      level: null,
      from_user_id: null,
      description: `Deposit reward for reaching ${constants.DEPOSIT_REWARD.REFERRAL_THRESHOLD} direct referrals after deposit`,
      status: 'completed',
      metadata: JSON.stringify({
        referralsCount: currentReferrals,
        rewardAmount: constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
        depositId: approvedDeposit.id,
      }),
    }, { transaction });

    // Create deposit reward record
    await DepositReward.create({
      user_id: userId,
      referrals_count: currentReferrals,
      reward_amount: constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
      earning_id: earning.id,
    }, { transaction });

    // Update user's wallet balance and total earnings
    await user.update({
      wallet_balance: parseFloat(user.wallet_balance) + constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
      total_earnings: parseFloat(user.total_earnings) + constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
    }, { transaction });

    await transaction.commit();

    logger.info(`Auto-awarded deposit reward to user ${userId}: ${constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR} PKR for ${currentReferrals} referrals`);

    return {
      awarded: true,
      rewardAmount: constants.DEPOSIT_REWARD.REWARD_AMOUNT_PKR,
      referralsCount: currentReferrals,
    };
  } catch (error) {
    await transaction.rollback();
    logger.error(`Error auto-awarding deposit reward to user ${userId}:`, error);
    return { awarded: false, reason: 'error', error: error.message };
  }
};

module.exports = exports;

