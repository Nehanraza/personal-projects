const Package = require('../models/Package');
const { Op } = require('sequelize');

// @desc    Get all packages
// @route   GET /api/v1/packages
// @access  Public
exports.getPackages = async (req, res, next) => {
  try {
    const { is_active, search } = req.query;
    const where = {};
    
    if (is_active !== undefined) {
      where.is_active = is_active === 'true';
    }
    
    if (search) {
      where.name = { [Op.iLike]: `%${search}%` };
    }

    const packages = await Package.findAll({
      where,
      order: [['display_order', 'ASC'], ['price', 'ASC']],
    });

    res.status(200).json({
      success: true,
      count: packages.length,
      data: packages,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single package
// @route   GET /api/v1/packages/:id
// @access  Public
exports.getPackage = async (req, res, next) => {
  try {
    const packageData = await Package.findByPk(req.params.id);

    if (!packageData) {
      return res.status(404).json({
        success: false,
        message: 'Package not found',
      });
    }

    res.status(200).json({
      success: true,
      data: packageData,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create package
// @route   POST /api/v1/packages
// @access  Private/Admin
exports.createPackage = async (req, res, next) => {
  try {
    const packageData = await Package.create(req.body);

    res.status(201).json({
      success: true,
      data: packageData,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update package
// @route   PUT /api/v1/packages/:id
// @access  Private/Admin
exports.updatePackage = async (req, res, next) => {
  try {
    const packageData = await Package.findByPk(req.params.id);

    if (!packageData) {
      return res.status(404).json({
        success: false,
        message: 'Package not found',
      });
    }

    await packageData.update(req.body);

    res.status(200).json({
      success: true,
      data: packageData,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete package
// @route   DELETE /api/v1/packages/:id
// @access  Private/Admin
exports.deletePackage = async (req, res, next) => {
  try {
    const packageData = await Package.findByPk(req.params.id);

    if (!packageData) {
      return res.status(404).json({
        success: false,
        message: 'Package not found',
      });
    }

    await packageData.destroy();

    res.status(200).json({
      success: true,
      message: 'Package deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};