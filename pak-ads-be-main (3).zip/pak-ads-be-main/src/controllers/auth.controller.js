const User = require('../models/User');
const Earning = require('../models/Earning');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const logger = require('../config/logger');
const constants = require('../config/constants');
const commissionService = require('../utils/commissionService');
const sendEmail = require('../utils/sendEmail');
const { generateOTPWithExpiry, hashToken } = require('../utils/generateOTP');
const { emailVerificationTemplate, passwordResetTemplate, welcomeEmailTemplate } = require('../utils/emailTemplates');

// @desc    Register user
// @route   POST /api/v1/auth/register
// @access  Public
exports.register = async (req, res, next) => {
  try {
    const { name, email, phone, referralCode, joiningFeePaid } = req.body;

    // Validate required fields
    if (!phone) {
      return res.status(400).json({
        success: false,
        message: 'Phone number is required',
      });
    }

    // Check if user exists by email
    const existingUserByEmail = await User.findOne({ where: { email } });
    if (existingUserByEmail) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email',
      });
    }

    // Check if user exists by phone (mobile number must be unique)
    const existingUserByPhone = await User.findOne({ where: { phone } });
    if (existingUserByPhone) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this phone number',
      });
    }

    // If referral code is provided, validate it
    let referrerId = null;
    if (referralCode) {
      const referrer = await User.findOne({
        where: { referral_code: referralCode },
      });

      if (!referrer) {
        return res.status(400).json({
          success: false,
          message: 'Invalid referral code',
        });
      }

      referrerId = referrer.id;
    }

    // Check if joining fee is paid
    if (!joiningFeePaid) {
      return res.status(400).json({
        success: false,
        message: `Registration requires a joining fee of ${constants.CURRENCY.JOINING_FEE_PKR} PKR ($${constants.CURRENCY.JOINING_FEE_USD})`,
        joiningFee: {
          amountPKR: constants.CURRENCY.JOINING_FEE_PKR,
          amountUSD: constants.CURRENCY.JOINING_FEE_USD,
        },
      });
    }

    // Generate unique referral code for new user
    let newReferralCode;
    let isUnique = false;
    while (!isUnique) {
      newReferralCode = User.generateReferralCode();
      const existing = await User.findOne({
        where: { referral_code: newReferralCode },
      });
      if (!existing) {
        isUnique = true;
      }
    }

    // Create user (no OTP, admin approval required)
    // Use phone number as password
    const user = await User.create({
      name,
      email,
      password: phone, // Use phone number as password
      phone,
      referred_by: referrerId,
      referral_code: newReferralCode,
      joining_fee_paid: true,
      joining_fee_paid_at: new Date(),
      joining_fee_amount: constants.CURRENCY.JOINING_FEE_PKR,
      is_email_verified: false, // Will be verified by admin approval
      is_admin_approved: false, // Admin needs to approve
      email_verification_token: null, // No OTP for registration
      email_verification_expire: null, // No OTP expiry
    });

    // No email sending for registration - admin approval required

    // If user was referred, update direct referrer's total_referrals count
    // Commission will be distributed ONLY after admin approval
    if (referrerId) {
      try {
        // Update direct referrer's total_referrals count
        await User.increment('total_referrals', { where: { id: referrerId } });
        
        logger.info(`Updated referral count for referrer ${referrerId} - commission will be distributed after admin approval`);
      } catch (error) {
        logger.error('Error updating referral count:', error);
        // Don't fail registration if referral count update fails
      }
    }

    // Return success with token and message to verify email
    const token = user.getSignedJwtToken();

    // Parse JWT_EXPIRES_IN (e.g., "7d" -> 7 days)
    const jwtExpire = process.env.JWT_EXPIRES_IN || '7d';
    const match = jwtExpire.match(/(\d+)([dhms])/);
    let expireMs = 7 * 24 * 60 * 60 * 1000; // default 7 days
    
    if (match) {
      const value = parseInt(match[1]);
      const unit = match[2];
      switch (unit) {
        case 'd': expireMs = value * 24 * 60 * 60 * 1000; break;
        case 'h': expireMs = value * 60 * 60 * 1000; break;
        case 'm': expireMs = value * 60 * 1000; break;
        case 's': expireMs = value * 1000; break;
      }
    }

    const options = {
      expires: new Date(Date.now() + expireMs),
      httpOnly: true,
    };

    if (process.env.NODE_ENV === 'production') {
      options.secure = true;
    }

    res
      .status(201)
      .cookie('token', token, options)
      .json({
        success: true,
        message: 'Registration successful! Your account is pending admin approval.',
        data: {
          user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            referralCode: user.referral_code,
            isEmailVerified: user.is_email_verified,
            totalReferrals: user.total_referrals,
            joiningFeePaid: user.joining_fee_paid,
            joiningFeePaidAt: user.joining_fee_paid_at,
          },
        },
        requiresAdminApproval: true,
        token
      });
  } catch (error) {
    next(error);
  }
};

// @desc    Login user
// @route   POST /api/v1/auth/login
// @access  Public
exports.login = async (req, res, next) => {
  try {
    const { email, phone, password } = req.body;

    // Find user by email or phone
    let user;
    if (email) {
      user = await User.findOne({ where: { email } });
    } else if (phone) {
      user = await User.findOne({ where: { phone } });
    } else {
      return res.status(400).json({
        success: false,
        message: 'Please provide either email or phone number',
      });
    }

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
      });
    }

    // Check if password matches (password should be the phone number)
    const isMatch = await user.matchPassword(password);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
      });
    }

    // Check if user is active
    if (!user.is_active) {
      return res.status(401).json({
        success: false,
        message: 'Your account has been deactivated',
      });
    }

    sendTokenResponse(user, 200, res);
  } catch (error) {
    next(error);
  }
};

// @desc    Logout user / clear cookie
// @route   GET /api/v1/auth/logout
// @access  Private
exports.logout = async (req, res, next) => {
  try {
    res.cookie('token', 'none', {
      expires: new Date(Date.now() + 10 * 1000),
      httpOnly: true,
    });

    res.status(200).json({
      success: true,
      message: 'User logged out successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get current logged in user
// @route   GET /api/v1/auth/me
// @access  Private
exports.getMe = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] },
    });

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update user details
// @route   PUT /api/v1/auth/updatedetails
// @access  Private
exports.updateDetails = async (req, res, next) => {
  try {
    const fieldsToUpdate = {
      name: req.body.name,
      email: req.body.email,
      phone: req.body.phone,
    };

    // Remove undefined fields
    Object.keys(fieldsToUpdate).forEach(
      (key) => fieldsToUpdate[key] === undefined && delete fieldsToUpdate[key]
    );

    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    await user.update(fieldsToUpdate);

    res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update password
// @route   PUT /api/v1/auth/updatepassword
// @access  Private
exports.updatePassword = async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check current password
    const isMatch = await user.matchPassword(req.body.currentPassword);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect',
      });
    }

    user.password = req.body.newPassword;
    await user.save();

    sendTokenResponse(user, 200, res);
  } catch (error) {
    next(error);
  }
};

// @desc    Verify email with OTP
// @route   POST /api/v1/auth/verify-email
// @access  Public
exports.verifyEmail = async (req, res, next) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and OTP',
      });
    }

    // Find user
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if already verified
    if (user.is_email_verified) {
      return res.status(400).json({
        success: false,
        message: 'Email is already verified',
      });
    }

    // Check if OTP matches
    if (user.email_verification_token !== otp) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP code',
      });
    }

    // Check if OTP is expired
    if (new Date() > new Date(user.email_verification_expire)) {
      return res.status(400).json({
        success: false,
        message: 'OTP has expired. Please request a new one.',
        expired: true,
      });
    }

    // Verify email
    await user.update({
      is_email_verified: true,
      email_verification_token: null,
      email_verification_expire: null,
    });

    // Send welcome email
    try {
      const emailContent = welcomeEmailTemplate(user.name, user.referral_code);
      await sendEmail({
        email: user.email,
        subject: emailContent.subject,
        message: emailContent.text,
        html: emailContent.html,
      });
    } catch (error) {
      logger.error('Error sending welcome email:', error);
    }

    // Send token response (log user in after verification)
    sendTokenResponse(user, 200, res);
  } catch (error) {
    next(error);
  }
};

// @desc    Resend verification OTP
// @route   POST /api/v1/auth/resend-otp
// @access  Public
exports.resendOTP = async (req, res, next) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email',
      });
    }

    // Find user
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if already verified
    if (user.is_email_verified) {
      return res.status(400).json({
        success: false,
        message: 'Email is already verified',
      });
    }

    // Generate new OTP
    const { otp, expiry } = generateOTPWithExpiry(10);

    // Update user with new OTP
    await user.update({
      email_verification_token: otp,
      email_verification_expire: expiry,
    });

    // Send verification email
    try {
      const emailContent = emailVerificationTemplate(user.name, otp);
      await sendEmail({
        email: user.email,
        subject: emailContent.subject,
        message: emailContent.text,
        html: emailContent.html,
      });
      logger.info(`Verification OTP resent to ${user.email}`);
    } catch (error) {
      logger.error('Error sending verification email:', error);
      return res.status(500).json({
        success: false,
        message: 'Error sending email. Please try again later.',
      });
    }

    res.status(200).json({
      success: true,
      message: 'Verification code sent to your email',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Forgot password
// @route   POST /api/v1/auth/forgotpassword
// @access  Public
exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email',
      });
    }

    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'No user found with that email',
      });
    }

    // Generate OTP for password reset
    const { otp, expiry } = generateOTPWithExpiry(10); // 10 minutes

    // Update user with reset OTP
    await user.update({
      reset_password_token: otp,
      reset_password_expire: expiry,
    });

    // Send password reset email with OTP
    try {
      const emailContent = passwordResetTemplate(user.name, otp);
      
      // TEMPORARY: Log OTP to console for testing
      console.log('🔑 OTP FOR TESTING:', otp);
      logger.info(`🔑 OTP FOR TESTING: ${otp}`);
      
      const test = await sendEmail({
        email: user.email,
        subject: emailContent.subject,
        message: emailContent.text,
        html: emailContent.html,
      });
      logger.info(`sendEmail ======================================${test}`);
      logger.info(`Password reset OTP sent to ======================================${user.email}`);
    } catch (error) {
      logger.error('Error sending password reset email:=============================================', error);
      return res.status(500).json({
        success: false,
        message: 'Error sending email. Please try again later.',
      });
    }

    res.status(200).json({
      success: true,
      message: 'Password reset code sent to your email',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Reset password with OTP
// @route   POST /api/v1/auth/reset-password
// @access  Public
exports.resetPassword = async (req, res, next) => {
  try {
    const { email, otp, newPassword } = req.body;

    if (!email || !otp || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email, OTP, and new password',
      });
    }

    // Validate new password length
    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters',
      });
    }

    // Find user
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if OTP matches
    if (user.reset_password_token !== otp) {
      return res.status(400).json({
        success: false,
        message: 'Invalid OTP code',
      });
    }

    // Check if OTP is expired
    if (new Date() > new Date(user.reset_password_expire)) {
      return res.status(400).json({
        success: false,
        message: 'OTP has expired. Please request a new one.',
        expired: true,
      });
    }

    // Update password and clear reset token
    await user.update({
      password: newPassword, // Will be hashed by beforeSave hook
      reset_password_token: null,
      reset_password_expire: null,
    });

    logger.info(`Password reset successful for user ${user.id}`);

    res.status(200).json({
      success: true,
      message: 'Password reset successful. You can now login with your new password.',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get joining fee information
// @route   GET /api/v1/auth/joining-fee-info
// @access  Public
exports.getJoiningFeeInfo = async (req, res, next) => {
  try {
    res.status(200).json({
      success: true,
      data: {
        joiningFee: {
          amountPKR: constants.CURRENCY.JOINING_FEE_PKR,
          amountUSD: constants.CURRENCY.JOINING_FEE_USD,
        },
        currencyRate: {
          usdToPkr: constants.CURRENCY.USD_TO_PKR_RATE,
          description: `1 USD = ${constants.CURRENCY.USD_TO_PKR_RATE} PKR`,
        },
        commissionStructure: constants.COMMISSION_LEVELS,
      },
    });
  } catch (error) {
    next(error);
  }
};

// Helper function to get token from model, create cookie and send response
const sendTokenResponse = (user, statusCode, res) => {
  // Create token
  const token = user.getSignedJwtToken();

  // Parse JWT_EXPIRES_IN (e.g., "7d" -> 7 days)
  const jwtExpire = process.env.JWT_EXPIRES_IN || '7d';
  const match = jwtExpire.match(/(\d+)([dhms])/);
  let expireMs = 7 * 24 * 60 * 60 * 1000; // default 7 days
  
  if (match) {
    const value = parseInt(match[1]);
    const unit = match[2];
    switch (unit) {
      case 'd': expireMs = value * 24 * 60 * 60 * 1000; break;
      case 'h': expireMs = value * 60 * 60 * 1000; break;
      case 'm': expireMs = value * 60 * 1000; break;
      case 's': expireMs = value * 1000; break;
    }
  }

  const options = {
    expires: new Date(Date.now() + expireMs),
    httpOnly: true,
  };

  if (process.env.NODE_ENV === 'production') {
    options.secure = true;
  }

  res
    .status(statusCode)
    .cookie('token', token, options)
    .json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        referralCode: user.referral_code,
        totalReferrals: user.total_referrals,
        joiningFeePaid: user.joining_fee_paid,
        joiningFeePaidAt: user.joining_fee_paid_at,
      },
    });
};
