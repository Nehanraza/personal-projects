const cloudinary = require('../config/cloudinary');
const logger = require('../config/logger');

/**
 * @desc    Upload image to Cloudinary
 * @route   POST /api/v1/upload
 * @access  Private
 */
exports.uploadImage = async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file provided',
      });
    }

    // Upload to Cloudinary
    const result = await cloudinary.uploader.upload(req.file.buffer, {
      resource_type: 'auto',
      folder: 'pak-ads',
      transformation: [
        { quality: 'auto', fetch_format: 'auto' }
      ]
    });

    res.status(200).json({
      success: true,
      message: 'Image uploaded successfully',
      data: {
        filename: req.file.originalname,
        originalName: req.file.originalname,
        size: req.file.size,
        mimetype: req.file.mimetype,
        imageUrl: result.secure_url,
        publicId: result.public_id,
        uploadedAt: new Date(),
      },
    });
  } catch (error) {
    logger.error('Error uploading image:', error);
    next(error);
  }
};

/**
 * @desc    Delete image from Cloudinary
 * @route   DELETE /api/v1/upload/:publicId
 * @access  Private
 */
exports.deleteImage = async (req, res, next) => {
  try {
    const publicId = req.params.publicId;

    if (!publicId) {
      return res.status(400).json({
        success: false,
        message: 'Public ID is required',
      });
    }

    // Delete from Cloudinary
    const result = await cloudinary.uploader.destroy(publicId);

    if (result.result === 'not found') {
      return res.status(404).json({
        success: false,
        message: 'Image not found',
      });
    }

    res.status(200).json({
      success: true,
      message: 'Image deleted successfully',
      data: {
        publicId: publicId,
        deletedAt: new Date(),
      },
    });
  } catch (error) {
    logger.error('Error deleting image:', error);
    next(error);
  }
};

