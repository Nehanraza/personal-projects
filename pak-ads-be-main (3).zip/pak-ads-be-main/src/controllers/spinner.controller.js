const User = require('../models/User');
const Earning = require('../models/Earning');
const { sequelize } = require('../config/database');
const logger = require('../config/logger');
const constants = require('../config/constants');
const { hasApprovedDeposit } = require('../utils/depositGuard');

// @desc    Spin the lucky wheel
// @route   POST /api/v1/spinner/spin
// @access  Private (User)
exports.spinWheel = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Check if user has paid joining fee
    if (!user.joining_fee_paid) {
      return res.status(403).json({
        success: false,
        code: 'JOINING_FEE_REQUIRED',
        message: 'Please pay the joining fee to participate in lucky draw',
        help: 'Create a deposit and get it approved, or contact support if you already paid.'
      });
    }

    // Require at least one approved deposit before awarding any spinner earnings
    const depositApproved = await hasApprovedDeposit(userId);
    if (!depositApproved) {
      return res.status(403).json({
        success: false,
        code: 'DEPOSIT_REQUIRED',
        message: 'You must have at least one approved deposit to earn from lucky draw',
        help: 'Submit a deposit proof and wait for admin approval, then try again.'
      });
    }

    // Enforce strict 1 spin per 24 hours
    if (user.last_spin_at) {
      const last = new Date(user.last_spin_at);
      const hoursSince = (Date.now() - last.getTime()) / (1000 * 60 * 60);
      if (hoursSince < 24) {
        const hoursRemaining = (24 - hoursSince).toFixed(1);
        return res.status(429).json({
          success: false,
          code: 'SPIN_LIMIT_24H',
          message: `You can spin again in ${hoursRemaining} hours`,
          retryAfterHours: parseFloat(hoursRemaining),
        });
      }
    }

    // Check if user can spin today
    const canSpinResult = await user.canSpinToday();
    if (!canSpinResult.canSpin) {
      return res.status(400).json({
        success: false,
        message: canSpinResult.message,
        spinsRemaining: canSpinResult.spinsRemaining,
        cycle: canSpinResult.cycle,
      });
    }

    // Define spinner segments (USD-based) - only three rewards
    const segments = [
      { id: 1, reward: '0.003 USD', probability: 0.33, amountUSD: 0.003, color: 'gold' },
      { id: 2, reward: '0.007 USD', probability: 0.33, amountUSD: 0.007, color: 'silver' },
      { id: 3, reward: '0.010 USD', probability: 0.34, amountUSD: 0.010, color: 'bronze' },
    ];

    // Require color parameter from frontend (accept body or query), and match to segments
    const colorParamRaw = (req.body && req.body.color) || (req.query && req.query.color) || '';
    const colorParam = String(colorParamRaw).trim().toLowerCase();

    if (!colorParam) {
      return res.status(400).json({
        success: false,
        message: 'Parameter "color" is required',
        allowedColors: segments.map((s) => s.color),
      });
    }

    const spinResult = segments.find((s) => s.color.toLowerCase() === colorParam);

    if (!spinResult) {
      return res.status(400).json({
        success: false,
        message: `Invalid color: ${colorParam}. Must be one of: ${segments.map((s) => s.color).join(', ')}`,
        allowedColors: segments.map((s) => s.color),
      });
    }

    // Process the reward
    await sequelize.transaction(async (t) => {
      let updatedUser = user;
      let extraSpins = 0;

      // Calculate amount in PKR
      const amountUSD = parseFloat(spinResult.amountUSD);
      const amountPKR = constants.convertUsdToPkr(amountUSD);

      // Prepare wallet update fields
      const walletUpdateFields = {
        last_spin_at: new Date(),
        total_spins: (user.total_spins || 0) + 1,
      };

      // Add wallet balance if won
      if (amountPKR > 0) {
        walletUpdateFields.wallet_balance = parseFloat(user.wallet_balance) + amountPKR;
        walletUpdateFields.total_earnings = parseFloat(user.total_earnings) + amountPKR;
      }

      // Handle extra spins vs daily spins
      if (user.extra_spins > 0) {
        walletUpdateFields.extra_spins = user.extra_spins - 1;
      } else {
        walletUpdateFields.today_spins_count = (user.today_spins_count || 0) + 1;
      }

      // Update user in single operation
      await user.update(walletUpdateFields, { transaction: t });

      // Create earning record for lucky draw win (if won)
      if (amountPKR > 0) {
        await Earning.create({
          user_id: userId,
          from_user_id: userId, // Set to self for lucky draw wins
          amount: amountPKR,
          level: 0, // Level 0 for lucky draw wins
          type: 'lucky_draw_win',
          description: `Won ${spinResult.reward} from Lucky Draw`,
          status: 'completed',
        }, { transaction: t });

        logger.info(`User ${userId} won ${spinResult.reward} (${amountPKR} PKR) from Lucky Draw`);
      }

      // Reload user to get updated values
      updatedUser = await User.findByPk(userId, { transaction: t });
    });

    // Get updated user data
    const updatedUser = await User.findByPk(userId);
    const refreshedSpinStatus = await updatedUser.canSpinToday();

    res.status(200).json({
      success: true,
      data: {
        spinResult: {
          segmentId: spinResult.id,
          reward: spinResult.reward,
          amountUSD: spinResult.amountUSD || 0,
          amountPKR: spinResult.amountUSD ? constants.convertUsdToPkr(spinResult.amountUSD) : 0,
          color: spinResult.color,
        },
        user: {
          walletBalance: parseFloat(updatedUser.wallet_balance),
          walletBalanceUSD: constants.convertPkrToUsd(parseFloat(updatedUser.wallet_balance)),
          totalEarnings: parseFloat(updatedUser.total_earnings),
          totalSpins: updatedUser.total_spins || 0,
          extraSpins: updatedUser.extra_spins || 0,
        },
        spinInfo: {
          canSpinAgain: refreshedSpinStatus.canSpin,
          spinsRemaining: refreshedSpinStatus.spinsRemaining,
          dailyLimit: updatedUser.daily_spin_limit || 5,
          message: refreshedSpinStatus.message,
          cycle: refreshedSpinStatus.cycle,
        },
        message: (spinResult.amountPKR && spinResult.amountPKR > 0)
          ? `Congratulations! You won ${spinResult.reward}!`
          : 'Better luck next time!',
      },
    });

  } catch (error) {
    logger.error('Error in spin wheel:', error);
    next(error);
  }
};

// @desc    Get spinner information and user's spin status
// @route   GET /api/v1/spinner/info
// @access  Private (User)
exports.getSpinnerInfo = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Define available rewards for display
    const availableRewards = [
      { id: 1, reward: '$0.10', amountUSD: 0.10, color: 'lightblue', probability: 30 },
      { id: 2, reward: '$0.25', amountUSD: 0.25, color: 'orange', probability: 25 },
      { id: 3, reward: '$0.50', amountUSD: 0.50, color: 'green', probability: 20 },
      { id: 4, reward: 'Extra Spin', amountUSD: 0, color: 'purple', probability: 10 },
      { id: 5, reward: '$0.05', amountUSD: 0.05, color: 'pink', probability: 10 },
      { id: 6, reward: 'No Reward', amountUSD: 0, color: 'red', probability: 3 },
      { id: 7, reward: '$1', amountUSD: 1.00, color: 'teal', probability: 1.5 },
      { id: 8, reward: '$2', amountUSD: 2.00, color: 'gray', probability: 0.5 },
    ];

    const canSpinResult = await user.canSpinToday();

    res.status(200).json({
      success: true,
      data: {
        user: {
          walletBalance: parseFloat(user.wallet_balance),
          walletBalanceUSD: constants.convertPkrToUsd(parseFloat(user.wallet_balance)),
          totalSpins: user.total_spins || 0,
          extraSpins: user.extra_spins || 0,
          joiningFeePaid: user.joining_fee_paid,
        },
        spinner: {
          availableRewards,
          canSpin: canSpinResult.canSpin,
          spinsRemaining: canSpinResult.spinsRemaining,
          dailyLimit: user.daily_spin_limit || 5,
          message: canSpinResult.message,
          cycle: canSpinResult.cycle,
        },
        currencyRate: {
          usdToPkr: constants.CURRENCY.USD_TO_PKR_RATE,
        },
      },
    });

  } catch (error) {
    logger.error('Error getting spinner info:', error);
    next(error);
  }
};

// Helper function to get random reward based on probabilities
function getRandomReward(segments) {
  const random = Math.random();
  let cumulative = 0;

  for (const segment of segments) {
    cumulative += segment.probability;
    if (random <= cumulative) {
      return segment;
    }
  }

  // Fallback to last segment if something goes wrong
  return segments[segments.length - 1];
}
