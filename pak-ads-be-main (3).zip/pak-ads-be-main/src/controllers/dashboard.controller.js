const Ad = require('../models/Ad');
const Review = require('../models/Review');
const Message = require('../models/Message');
const Favorite = require('../models/Favorite');
const Notification = require('../models/Notification');
const { User, Earning } = require('../models');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const constants = require('../config/constants');
const { getUserCommissionStats, getOverallCommissionStats } = require('../utils/commissionService');

// @desc    Get user dashboard statistics
// @route   GET /api/v1/dashboard/stats
// @access  Private
exports.getUserDashboard = async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Get user's ads stats
    const totalAds = await Ad.count({ where: { user_id: userId } });
    const activeAds = await Ad.count({ where: { user_id: userId, status: 'active' } });
    const pendingAds = await Ad.count({ where: { user_id: userId, status: 'pending' } });
    const soldAds = await Ad.count({ where: { user_id: userId, status: 'sold' } });

    // Get total views across all user's ads
    const viewsResult = await Ad.findOne({
      attributes: [[sequelize.fn('SUM', sequelize.col('views_count')), 'total_views']],
      where: { user_id: userId },
      raw: true,
    });

    // Get favorites count
    const favoritesCount = await Favorite.count({ where: { user_id: userId } });

    // Get unread messages
    const unreadMessages = await Message.count({
      where: { receiver_id: userId, is_read: false },
    });

    // Get unread notifications
    const unreadNotifications = await Notification.count({
      where: { user_id: userId, is_read: false },
    });

    // Get reviews received
    const reviewsReceived = await Review.count({ where: { seller_id: userId } });

    // Get average rating
    const ratingResult = await Review.findOne({
      attributes: [[sequelize.fn('AVG', sequelize.col('rating')), 'avg_rating']],
      where: { seller_id: userId },
      raw: true,
    });

    res.status(200).json({
      success: true,
      data: {
        ads: {
          total: totalAds,
          active: activeAds,
          pending: pendingAds,
          sold: soldAds,
        },
        total_views: parseInt(viewsResult.total_views) || 0,
        favorites: favoritesCount,
        unread_messages: unreadMessages,
        unread_notifications: unreadNotifications,
        reviews: {
          count: reviewsReceived,
          average_rating: parseFloat(ratingResult.avg_rating || 0).toFixed(1),
        },
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user financial dashboard
// @route   GET /api/v1/dashboard/financial
// @access  Private
exports.getFinancialDashboard = async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Get user's wallet information
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_earnings', 'total_withdrawn', 'total_referrals'],
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Get reward earnings (referral commissions + bonuses + lucky draw wins)
    const rewardEarnings = await Earning.sum('amount', {
      where: {
        user_id: userId,
        type: {
          [Op.in]: ['referral_commission', 'bonus', 'lucky_draw_win'],
        },
        status: 'completed',
      },
    });

    // Get ad watching earnings (if tracked separately)
    // Note: Currently ad watching might not create earnings in the Earning table
    // This would need to be implemented if not already done
    const adEarnings = await Earning.sum('amount', {
      where: {
        user_id: userId,
        type: 'ad_watching',
        status: 'completed',
      },
    });

    // Get total completed earnings by type
    const earningsByType = await Earning.findAll({
      where: { 
        user_id: userId,
        status: 'completed',
      },
      attributes: [
        'type',
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['type'],
      raw: true,
    });

    // Get pending earnings
    const pendingEarnings = await Earning.sum('amount', {
      where: {
        user_id: userId,
        status: 'pending',
      },
    });

    // Get total withdrawals (negative amounts)
    const totalWithdrawals = await Earning.sum('amount', {
      where: {
        user_id: userId,
        type: 'withdrawal',
      },
    });

    res.status(200).json({
      success: true,
      data: {
        currentBalance: {
          pkr: parseFloat(user.wallet_balance),
          usd: constants.convertPkrToUsd(parseFloat(user.wallet_balance)),
        },
        totalWithdrawal: {
          pkr: parseFloat(user.total_withdrawn),
          usd: constants.convertPkrToUsd(parseFloat(user.total_withdrawn)),
        },
        rewardEarning: {
          pkr: parseFloat(rewardEarnings || 0),
          usd: constants.convertPkrToUsd(parseFloat(rewardEarnings || 0)),
        },
        totalAdsEarning: {
          pkr: parseFloat(adEarnings || 0),
          usd: constants.convertPkrToUsd(parseFloat(adEarnings || 0)),
        },
        totalEarnings: {
          pkr: parseFloat(user.total_earnings),
          usd: constants.convertPkrToUsd(parseFloat(user.total_earnings)),
        },
        pendingEarnings: {
          pkr: parseFloat(pendingEarnings || 0),
          usd: constants.convertPkrToUsd(parseFloat(pendingEarnings || 0)),
        },
        earningsByType: earningsByType.map(item => ({
          type: item.type,
          total: {
            pkr: parseFloat(item.total || 0),
            usd: constants.convertPkrToUsd(parseFloat(item.total || 0)),
          },
          count: parseInt(item.count, 10),
        })),
        totalReferrals: user.total_referrals,
        currencyRate: {
          usdToPkr: constants.CURRENCY.USD_TO_PKR_RATE,
        },
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get admin dashboard statistics
// @route   GET /api/v1/dashboard/admin/stats
// @access  Private/Admin
exports.getAdminDashboard = async (req, res, next) => {
  try {
    const User = require('../models/User');
    const Category = require('../models/Category');
    const Report = require('../models/Report');

    // Total counts
    const totalUsers = await User.count();
    const totalAds = await Ad.count();
    const totalCategories = await Category.count();
    const activeAds = await Ad.count({ where: { status: 'active' } });
    const pendingAds = await Ad.count({ where: { status: 'pending' } });
    const featuredAds = await Ad.count({ where: { is_featured: true } });
    
    // Pending reports
    const pendingReports = await Report.count({ where: { status: 'pending' } });

    // Ads by status
    const adsByStatus = await Ad.findAll({
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['status'],
      raw: true,
    });

    // Recent users (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const recentUsers = await User.count({
      where: {
        created_at: {
          [Op.gte]: sevenDaysAgo,
        },
      },
    });

    // Recent ads (last 7 days)
    const recentAds = await Ad.count({
      where: {
        created_at: {
          [Op.gte]: sevenDaysAgo,
        },
      },
    });

    // Top categories by ad count
    const topCategories = await Ad.findAll({
      attributes: [
        'category_id',
        [sequelize.fn('COUNT', sequelize.col('Ad.id')), 'ads_count'],
      ],
      include: [
        {
          model: Category,
          as: 'category',
          attributes: ['id', 'name', 'slug'],
        },
      ],
      group: ['category_id', 'category.id'],
      order: [[sequelize.fn('COUNT', sequelize.col('Ad.id')), 'DESC']],
      limit: 5,
      raw: false,
    });

    res.status(200).json({
      success: true,
      data: {
        overview: {
          total_users: totalUsers,
          total_ads: totalAds,
          total_categories: totalCategories,
          active_ads: activeAds,
          pending_ads: pendingAds,
          featured_ads: featuredAds,
          pending_reports: pendingReports,
        },
        recent: {
          new_users_7days: recentUsers,
          new_ads_7days: recentAds,
        },
        ads_by_status: adsByStatus,
        top_categories: topCategories,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get public home page data
// @route   GET /api/v1/dashboard/home
// @access  Public
exports.getHomePageData = async (req, res, next) => {
  try {
    const Category = require('../models/Category');
    const Location = require('../models/Location');

    // Featured ads
    const featuredAds = await Ad.findAll({
      where: {
        status: 'active',
        is_featured: true,
        featured_until: {
          [Op.gte]: new Date(),
        },
      },
      limit: 8,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: Category,
          as: 'category',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: Location,
          as: 'location',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: AdImage,
          as: 'images',
          limit: 1,
          where: { is_primary: true },
          required: false,
        },
      ],
    });

    // Recent ads
    const recentAds = await Ad.findAll({
      where: { status: 'active' },
      limit: 12,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: Category,
          as: 'category',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: Location,
          as: 'location',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: AdImage,
          as: 'images',
          limit: 1,
          where: { is_primary: true },
          required: false,
        },
      ],
    });

    // Popular categories (by ad count)
    const popularCategories = await Category.findAll({
      where: { is_active: true, parent_id: null },
      order: [['display_order', 'ASC']],
      limit: 10,
    });

    // Popular locations
    const popularLocations = await Location.findAll({
      where: { is_active: true, type: 'city' },
      order: [['display_order', 'ASC']],
      limit: 10,
    });

    res.status(200).json({
      success: true,
      data: {
        featured_ads: featuredAds,
        recent_ads: recentAds,
        popular_categories: popularCategories,
        popular_locations: popularLocations,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user commission dashboard
// @route   GET /api/v1/dashboard/commissions
// @access  Private
exports.getCommissionDashboard = async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Get commission stats
    const commissionStats = await getUserCommissionStats(userId);

    // Get user info
    const user = await User.findByPk(userId, {
      attributes: ['id', 'name', 'email', 'referral_code', 'total_referrals'],
    });

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user.id,
          name: user.name,
          referralCode: user.referral_code,
          totalReferrals: user.total_referrals,
        },
        commissions: commissionStats,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get admin commission dashboard (overall statistics)
// @route   GET /api/v1/dashboard/admin/commissions
// @access  Private/Admin
exports.getAdminCommissionDashboard = async (req, res, next) => {
  try {
    const { startDate, endDate } = req.query;

    // Get overall commission stats
    const overallStats = await getOverallCommissionStats({
      startDate,
      endDate,
    });

    res.status(200).json({
      success: true,
      data: overallStats,
    });
  } catch (error) {
    next(error);
  }
};
