const { Earning, User } = require('../models');
const { Op } = require('sequelize');
const constants = require('../config/constants');
const logger = require('../config/logger');

/**
 * @desc    Get all withdrawal requests (Admin only)
 * @route   GET /api/v1/admin/withdrawals
 * @access  Private/Admin
 */
exports.getAllWithdrawals = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    const offset = (page - 1) * limit;
    const status = req.query.status; // pending, approved, rejected, sent
    const search = req.query.search;

    // Build where clause
    const whereClause = {
      type: 'withdrawal',
    };

    if (status) {
      whereClause.status = status;
    }

    if (search) {
      whereClause[Op.or] = [
        { description: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Earning.findAndCountAll({
      where: whereClause,
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        withdrawals: rows.map(withdrawal => ({
          id: withdrawal.id,
          userId: withdrawal.user_id,
          user: withdrawal.user,
          amount: Math.abs(parseFloat(withdrawal.amount)),
          amountUSD: constants.convertPkrToUsd(Math.abs(parseFloat(withdrawal.amount))),
          status: withdrawal.status,
          description: withdrawal.description,
          createdAt: withdrawal.created_at,
          updatedAt: withdrawal.updated_at,
          metadata: withdrawal.metadata ? JSON.parse(withdrawal.metadata) : null,
        })),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting all withdrawals:', error);
    next(error);
  }
};

/**
 * @desc    Approve withdrawal request (Admin only)
 * @route   PUT /api/v1/admin/withdrawals/:id/approve
 * @access  Private/Admin
 */
exports.approveWithdrawal = async (req, res, next) => {
  try {
    const withdrawalId = req.params.id;
    const { adminNotes } = req.body;

    const withdrawal = await Earning.findByPk(withdrawalId, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'wallet_balance'],
        },
      ],
    });

    if (!withdrawal) {
      return res.status(404).json({
        success: false,
        message: 'Withdrawal request not found',
      });
    }

    if (withdrawal.type !== 'withdrawal') {
      return res.status(400).json({
        success: false,
        message: 'This is not a withdrawal request',
      });
    }

    if (withdrawal.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: `Withdrawal request is already ${withdrawal.status}`,
      });
    }

    // Update withdrawal status
    await withdrawal.update({
      status: 'approved',
      metadata: JSON.stringify({
        ...JSON.parse(withdrawal.metadata || '{}'),
        adminNotes,
        approvedBy: req.user.id,
        approvedAt: new Date(),
      }),
    });

    res.status(200).json({
      success: true,
      message: 'Withdrawal request approved successfully',
      data: {
        id: withdrawal.id,
        userId: withdrawal.user_id,
        user: withdrawal.user,
        amount: Math.abs(parseFloat(withdrawal.amount)),
        amountUSD: constants.convertPkrToUsd(Math.abs(parseFloat(withdrawal.amount))),
        status: 'approved',
        approvedAt: new Date(),
        adminNotes,
      },
    });
  } catch (error) {
    logger.error('Error approving withdrawal:', error);
    next(error);
  }
};

/**
 * @desc    Reject withdrawal request (Admin only)
 * @route   PUT /api/v1/admin/withdrawals/:id/reject
 * @access  Private/Admin
 */
exports.rejectWithdrawal = async (req, res, next) => {
  try {
    const withdrawalId = req.params.id;
    const { reason, adminNotes } = req.body;

    if (!reason) {
      return res.status(400).json({
        success: false,
        message: 'Rejection reason is required',
      });
    }

    const withdrawal = await Earning.findByPk(withdrawalId, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'wallet_balance'],
        },
      ],
    });

    if (!withdrawal) {
      return res.status(404).json({
        success: false,
        message: 'Withdrawal request not found',
      });
    }

    if (withdrawal.type !== 'withdrawal') {
      return res.status(400).json({
        success: false,
        message: 'This is not a withdrawal request',
      });
    }

    if (withdrawal.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: `Withdrawal request is already ${withdrawal.status}`,
      });
    }

    const withdrawalAmount = Math.abs(parseFloat(withdrawal.amount));

    // Refund the amount back to user's wallet
    await withdrawal.user.update({
      wallet_balance: parseFloat(withdrawal.user.wallet_balance) + withdrawalAmount,
    });

    // Update withdrawal status
    await withdrawal.update({
      status: 'rejected',
      metadata: JSON.stringify({
        ...JSON.parse(withdrawal.metadata || '{}'),
        reason,
        adminNotes,
        rejectedBy: req.user.id,
        rejectedAt: new Date(),
      }),
    });

    res.status(200).json({
      success: true,
      message: 'Withdrawal request rejected successfully',
      data: {
        id: withdrawal.id,
        userId: withdrawal.user_id,
        user: withdrawal.user,
        amount: withdrawalAmount,
        amountUSD: constants.convertPkrToUsd(withdrawalAmount),
        status: 'rejected',
        reason,
        rejectedAt: new Date(),
        adminNotes,
      },
    });
  } catch (error) {
    logger.error('Error rejecting withdrawal:', error);
    next(error);
  }
};

/**
 * @desc    Mark withdrawal as sent (Admin only)
 * @route   PUT /api/v1/admin/withdrawals/:id/sent
 * @access  Private/Admin
 */
exports.markWithdrawalAsSent = async (req, res, next) => {
  try {
    const withdrawalId = req.params.id;
    const { transactionId, adminNotes } = req.body;

    const withdrawal = await Earning.findByPk(withdrawalId, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    if (!withdrawal) {
      return res.status(404).json({
        success: false,
        message: 'Withdrawal request not found',
      });
    }

    if (withdrawal.type !== 'withdrawal') {
      return res.status(400).json({
        success: false,
        message: 'This is not a withdrawal request',
      });
    }

    if (withdrawal.status !== 'approved') {
      return res.status(400).json({
        success: false,
        message: 'Withdrawal must be approved before marking as sent',
      });
    }

    // Update withdrawal status
    await withdrawal.update({
      status: 'sent',
      metadata: JSON.stringify({
        ...JSON.parse(withdrawal.metadata || '{}'),
        transactionId,
        adminNotes,
        sentBy: req.user.id,
        sentAt: new Date(),
      }),
    });

    res.status(200).json({
      success: true,
      message: 'Withdrawal marked as sent successfully',
      data: {
        id: withdrawal.id,
        userId: withdrawal.user_id,
        user: withdrawal.user,
        amount: Math.abs(parseFloat(withdrawal.amount)),
        amountUSD: constants.convertPkrToUsd(Math.abs(parseFloat(withdrawal.amount))),
        status: 'sent',
        transactionId,
        sentAt: new Date(),
        adminNotes,
      },
    });
  } catch (error) {
    logger.error('Error marking withdrawal as sent:', error);
    next(error);
  }
};

/**
 * @desc    Get withdrawal statistics (Admin only)
 * @route   GET /api/v1/admin/withdrawals/stats
 * @access  Private/Admin
 */
exports.getWithdrawalStats = async (req, res, next) => {
  try {
    const stats = await Earning.findAll({
      where: { type: 'withdrawal' },
      attributes: [
        'status',
        [Earning.sequelize.fn('COUNT', Earning.sequelize.col('id')), 'count'],
        [Earning.sequelize.fn('SUM', Earning.sequelize.col('amount')), 'totalAmount'],
      ],
      group: ['status'],
      raw: true,
    });

    const totalWithdrawals = await Earning.count({
      where: { type: 'withdrawal' },
    });

    const totalAmount = await Earning.sum('amount', {
      where: { 
        type: 'withdrawal',
        status: { [Op.in]: ['approved', 'sent'] }
      },
    });

    const statsObject = {
      pending: { count: 0, amount: 0 },
      approved: { count: 0, amount: 0 },
      rejected: { count: 0, amount: 0 },
      sent: { count: 0, amount: 0 },
    };

    stats.forEach(stat => {
      const status = stat.status;
      const count = parseInt(stat.count);
      const amount = Math.abs(parseFloat(stat.totalAmount || 0));
      
      statsObject[status] = {
        count,
        amount,
        amountUSD: constants.convertPkrToUsd(amount),
      };
    });

    res.status(200).json({
      success: true,
      data: {
        totalWithdrawals,
        totalAmount: Math.abs(totalAmount || 0),
        totalAmountUSD: constants.convertPkrToUsd(Math.abs(totalAmount || 0)),
        byStatus: statsObject,
      },
    });
  } catch (error) {
    logger.error('Error getting withdrawal stats:', error);
    next(error);
  }
};

