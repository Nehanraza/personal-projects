const { Transfer, User, Earning } = require('../models');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const constants = require('../config/constants');
const logger = require('../config/logger');

/**
 * @desc    Transfer money between users
 * @route   POST /api/v1/transfers
 * @access  Private (User)
 */
exports.transferMoney = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const senderId = req.user.id;
    const { receiverEmail, amount, description } = req.body;

    // Validate input
    if (!receiverEmail || !amount) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Receiver email and amount are required',
      });
    }

    const transferAmount = parseFloat(amount);

    if (transferAmount <= 0) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Transfer amount must be greater than 0',
      });
    }

    // Check minimum transfer amount (283 PKR = 1 USD)
    if (transferAmount < constants.CURRENCY.MIN_WITHDRAWAL_PKR) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `Minimum transfer amount is ${constants.CURRENCY.MIN_WITHDRAWAL_PKR} PKR ($${constants.CURRENCY.MIN_WITHDRAWAL_USD})`,
        minimumAmount: {
          pkr: constants.CURRENCY.MIN_WITHDRAWAL_PKR,
          usd: constants.CURRENCY.MIN_WITHDRAWAL_USD,
        },
      });
    }

    // Find receiver by email
    const receiver = await User.findOne({
      where: { email: receiverEmail },
      attributes: ['id', 'name', 'email', 'wallet_balance'],
      transaction,
    });

    if (!receiver) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Receiver not found',
      });
    }

    if (receiver.id === senderId) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'You cannot transfer money to yourself',
      });
    }

    // Get sender's current balance
    const sender = await User.findByPk(senderId, {
      attributes: ['id', 'name', 'email', 'wallet_balance'],
      transaction,
    });

    if (!sender) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Sender not found',
      });
    }

    const senderBalance = parseFloat(sender.wallet_balance);

    // Check if sender has sufficient balance
    if (senderBalance < transferAmount) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Insufficient wallet balance',
        availableBalance: {
          pkr: senderBalance,
          usd: constants.convertPkrToUsd(senderBalance),
        },
        requestedAmount: {
          pkr: transferAmount,
          usd: constants.convertPkrToUsd(transferAmount),
        },
      });
    }

    // Create transfer record
    const transfer = await Transfer.create({
      sender_id: senderId,
      receiver_id: receiver.id,
      amount: transferAmount,
      description: description || `Money transfer to ${receiver.name}`,
      status: 'completed',
    }, { transaction });

    // Update sender's balance (deduct)
    await sender.update({
      wallet_balance: senderBalance - transferAmount,
    }, { transaction });

    // Update receiver's balance (add)
    await receiver.update({
      wallet_balance: parseFloat(receiver.wallet_balance) + transferAmount,
    }, { transaction });

    // Create earning records for both users
    // Sender's outgoing transfer record
    await Earning.create({
      user_id: senderId,
      amount: -transferAmount, // Negative amount
      type: 'transfer_out',
      level: null,
      from_user_id: receiver.id,
      description: `Money transfer to ${receiver.name}`,
      status: 'completed',
      metadata: JSON.stringify({
        transferId: transfer.id,
        receiverEmail: receiver.email,
        receiverName: receiver.name,
        transferType: 'outgoing',
      }),
    }, { transaction });

    // Receiver's incoming transfer record
    await Earning.create({
      user_id: receiver.id,
      amount: transferAmount, // Positive amount
      type: 'transfer_in',
      level: null,
      from_user_id: senderId,
      description: `Money transfer from ${sender.name}`,
      status: 'completed',
      metadata: JSON.stringify({
        transferId: transfer.id,
        senderEmail: sender.email,
        senderName: sender.name,
        transferType: 'incoming',
      }),
    }, { transaction });

    await transaction.commit();

    res.status(201).json({
      success: true,
      message: 'Money transferred successfully',
      data: {
        transferId: transfer.id,
        amount: transferAmount,
        amountUSD: constants.convertPkrToUsd(transferAmount),
        receiver: {
          id: receiver.id,
          name: receiver.name,
          email: receiver.email,
        },
        sender: {
          id: sender.id,
          name: sender.name,
          email: sender.email,
        },
        description: transfer.description,
        status: 'completed',
        transferredAt: transfer.created_at,
        senderNewBalance: {
          pkr: senderBalance - transferAmount,
          usd: constants.convertPkrToUsd(senderBalance - transferAmount),
        },
        receiverNewBalance: {
          pkr: parseFloat(receiver.wallet_balance) + transferAmount,
          usd: constants.convertPkrToUsd(parseFloat(receiver.wallet_balance) + transferAmount),
        },
      },
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error transferring money:', error);
    next(error);
  }
};

/**
 * @desc    Get user's transfers
 * @route   GET /api/v1/transfers
 * @access  Private (User)
 */
exports.getTransfers = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;
    const type = req.query.type; // sent, received, all

    // Build where clause
    let whereClause = {};
    if (type === 'sent') {
      whereClause.sender_id = userId;
    } else if (type === 'received') {
      whereClause.receiver_id = userId;
    } else {
      whereClause[Op.or] = [
        { sender_id: userId },
        { receiver_id: userId },
      ];
    }

    const { count, rows } = await Transfer.findAndCountAll({
      where: whereClause,
      include: [
        {
          model: User,
          as: 'sender',
          attributes: ['id', 'name', 'email'],
        },
        {
          model: User,
          as: 'receiver',
          attributes: ['id', 'name', 'email'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        transfers: rows.map(transfer => ({
          id: transfer.id,
          amount: parseFloat(transfer.amount),
          amountUSD: constants.convertPkrToUsd(parseFloat(transfer.amount)),
          description: transfer.description,
          status: transfer.status,
          sender: transfer.sender,
          receiver: transfer.receiver,
          transferType: transfer.sender_id === userId ? 'sent' : 'received',
          createdAt: transfer.created_at,
        })),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting transfers:', error);
    next(error);
  }
};

/**
 * @desc    Get single transfer
 * @route   GET /api/v1/transfers/:id
 * @access  Private (User)
 */
exports.getTransferById = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const transferId = req.params.id;

    const transfer = await Transfer.findOne({
      where: {
        id: transferId,
        [Op.or]: [
          { sender_id: userId },
          { receiver_id: userId },
        ],
      },
      include: [
        {
          model: User,
          as: 'sender',
          attributes: ['id', 'name', 'email'],
        },
        {
          model: User,
          as: 'receiver',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    if (!transfer) {
      return res.status(404).json({
        success: false,
        message: 'Transfer not found',
      });
    }

    res.status(200).json({
      success: true,
      data: {
        id: transfer.id,
        amount: parseFloat(transfer.amount),
        amountUSD: constants.convertPkrToUsd(parseFloat(transfer.amount)),
        description: transfer.description,
        status: transfer.status,
        sender: transfer.sender,
        receiver: transfer.receiver,
        transferType: transfer.sender_id === userId ? 'sent' : 'received',
        createdAt: transfer.created_at,
      },
    });
  } catch (error) {
    logger.error('Error getting transfer by ID:', error);
    next(error);
  }
};

/**
 * @desc    Get transfer statistics (Admin only)
 * @route   GET /api/v1/transfers/admin/stats
 * @access  Private/Admin
 */
exports.getTransferStats = async (req, res, next) => {
  try {
    const stats = await Transfer.findAll({
      attributes: [
        [Transfer.sequelize.fn('COUNT', Transfer.sequelize.col('id')), 'totalTransfers'],
        [Transfer.sequelize.fn('SUM', Transfer.sequelize.col('amount')), 'totalAmount'],
        [Transfer.sequelize.fn('AVG', Transfer.sequelize.col('amount')), 'averageAmount'],
      ],
      raw: true,
    });

    const totalTransfers = await Transfer.count();
    const totalAmount = await Transfer.sum('amount');

    res.status(200).json({
      success: true,
      data: {
        totalTransfers,
        totalAmount: totalAmount || 0,
        totalAmountUSD: constants.convertPkrToUsd(totalAmount || 0),
        averageAmount: parseFloat(stats[0]?.averageAmount || 0),
        averageAmountUSD: constants.convertPkrToUsd(parseFloat(stats[0]?.averageAmount || 0)),
      },
    });
  } catch (error) {
    logger.error('Error getting transfer stats:', error);
    next(error);
  }
};

