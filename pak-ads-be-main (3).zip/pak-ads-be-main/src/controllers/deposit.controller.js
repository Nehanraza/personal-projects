const { Deposit, User, UserPlan, InvestmentPlan, Earning } = require('../models');
const { distributeInvestmentPlanCommission } = require('../utils/commissionService');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const constants = require('../config/constants');
const logger = require('../config/logger');
const commissionService = require('../utils/commissionService');
const { autoAwardDailyBonus } = require('./dailyReferralBonus.controller');
const { autoAwardRankReward } = require('./rankReward.controller');
const { autoAwardDepositReward } = require('./depositReward.controller');

/**
 * @desc    Create deposit request
 * @route   POST /api/v1/deposits
 * @access  Private (User)
 */
exports.createDeposit = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { amount, paymentMethod, transactionId, description } = req.body;

    // Validate amount
    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid deposit amount',
      });
    }

    const depositAmount = parseFloat(amount);

    // Check minimum deposit amount (283 PKR = 1 USD)
    if (depositAmount < constants.CURRENCY.MIN_WITHDRAWAL_PKR) {
      return res.status(400).json({
        success: false,
        message: `Minimum deposit amount is ${constants.CURRENCY.MIN_WITHDRAWAL_PKR} PKR ($${constants.CURRENCY.MIN_WITHDRAWAL_USD})`,
        minimumAmount: {
          pkr: constants.CURRENCY.MIN_WITHDRAWAL_PKR,
          usd: constants.CURRENCY.MIN_WITHDRAWAL_USD,
        },
      });
    }

    // Check if transaction ID already exists
    if (transactionId) {
      const existingDeposit = await Deposit.findOne({
        where: { transaction_id: transactionId },
      });

      if (existingDeposit) {
        return res.status(400).json({
          success: false,
          message: 'This transaction ID has already been used for a deposit',
          error: 'DUPLICATE_TRANSACTION_ID',
        });
      }
    }

    // Get proof image URL
    let proofImageUrl = null;
    if (req.file) {
      proofImageUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
    }

    // Create deposit record
    const deposit = await Deposit.create({
      user_id: userId,
      amount: depositAmount,
      payment_method: paymentMethod,
      transaction_id: transactionId,
      description: description,
      proof_image_url: proofImageUrl,
      status: 'pending',
    });

    res.status(201).json({
      success: true,
      message: 'Deposit request submitted successfully. It will be reviewed within 24-48 hours.',
      data: {
        depositId: deposit.id,
        amount: depositAmount,
        amountUSD: constants.convertPkrToUsd(depositAmount),
        status: 'pending',
        proofImageUrl,
        createdAt: deposit.created_at,
      },
    });
  } catch (error) {
    logger.error('Error creating deposit request:', error);
    next(error);
  }
};

/**
 * @desc    Get user's deposits
 * @route   GET /api/v1/deposits
 * @access  Private (User)
 */
exports.getDeposits = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;
    const status = req.query.status; // pending, approved, rejected

    // Build where clause
    const whereClause = { user_id: userId };
    if (status) {
      whereClause.status = status;
    }

    const { count, rows } = await Deposit.findAndCountAll({
      where: whereClause,
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        deposits: rows.map(deposit => ({
          id: deposit.id,
          amount: parseFloat(deposit.amount),
          amountUSD: constants.convertPkrToUsd(parseFloat(deposit.amount)),
          paymentMethod: deposit.payment_method,
          transactionId: deposit.transaction_id,
          description: deposit.description,
          proofImageUrl: deposit.proof_image_url,
          status: deposit.status,
          createdAt: deposit.created_at,
          updatedAt: deposit.updated_at,
          adminNotes: deposit.admin_notes,
        })),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting deposits:', error);
    next(error);
  }
};

/**
 * @desc    Get single deposit
 * @route   GET /api/v1/deposits/:id
 * @access  Private (User)
 */
exports.getDepositById = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const depositId = req.params.id;

    const deposit = await Deposit.findOne({
      where: {
        id: depositId,
        user_id: userId,
      },
    });

    if (!deposit) {
      return res.status(404).json({
        success: false,
        message: 'Deposit not found',
      });
    }

    res.status(200).json({
      success: true,
      data: {
        id: deposit.id,
        amount: parseFloat(deposit.amount),
        amountUSD: constants.convertPkrToUsd(parseFloat(deposit.amount)),
        paymentMethod: deposit.payment_method,
        transactionId: deposit.transaction_id,
        description: deposit.description,
        proofImageUrl: deposit.proof_image_url,
        status: deposit.status,
        createdAt: deposit.created_at,
        updatedAt: deposit.updated_at,
        adminNotes: deposit.admin_notes,
      },
    });
  } catch (error) {
    logger.error('Error getting deposit by ID:', error);
    next(error);
  }
};

/**
 * @desc    Approve deposit (Admin only)
 * @route   PUT /api/v1/deposits/:id/approve
 * @access  Private/Admin
 */
exports.approveDeposit = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const depositId = req.params.id;
    const { adminNotes } = req.body;

    const deposit = await Deposit.findByPk(depositId, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'wallet_balance', 'referred_by'],
        },
      ],
      transaction,
    });

    if (!deposit) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Deposit request not found',
      });
    }

    if (deposit.status !== 'pending') {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `Deposit request is already ${deposit.status}`,
      });
    }

    const depositAmount = parseFloat(deposit.amount);

    // Update deposit status
    await deposit.update({
      status: 'approved',
      admin_notes: adminNotes,
      approved_by: req.user.id,
      approved_at: new Date(),
    }, { transaction });

    // DISTRIBUTE COMMISSIONS TO REFERRERS (FIXED LEVEL AMOUNTS)
    // On deposit approval, distribute fixed PKR per level matching the chart
    try {
      logger.info(`Starting FIXED commission distribution for deposit approval - User ${deposit.user_id}, Base: ${constants.COMMISSION_CONFIG.BASE_AMOUNT}`);

      const commissionResult = await commissionService.distributeCommission(
        deposit.user_id,
        constants.COMMISSION_CONFIG.BASE_AMOUNT,
        'deposit_approval',
        'fixed',
        { transaction, metadata: { deposit_amount: depositAmount, deposit_id: deposit.id } }
      );

      logger.info(`Fixed commission distribution result for deposit approval:`, JSON.stringify(commissionResult, null, 2));
    } catch (error) {
      logger.error(`Error distributing fixed commissions for deposit approval:`, error);
      // Don't fail the deposit approval if commission distribution fails
    }

    // NOTE: We do NOT add deposit amount to user's wallet_balance
    // Deposit is just a record of money added by admin
    // User's wallet_balance should only contain earnings from:
    // - Referral commissions (when user refers others)
    // - Ad watching
    // - Bonuses
    // - Lucky draw wins
    // 
    // Deposits are separate - they're just admin adding money to user's account
    // but this money should NOT be counted as earnings or wallet balance

    // FOR ROI PLANS, we activate the plan
    if (deposit.plan_id) {
      const plan = await InvestmentPlan.findByPk(deposit.plan_id, { transaction });
      if (plan) {
        // Activate user plan
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + (plan.duration_days || 30));

        await UserPlan.create({
          user_id: deposit.user_id,
          plan_id: plan.id,
          status: 'active',
          investment_amount: plan.investment_amount,
          daily_profit: plan.daily_profit,
          max_return: plan.total_return,
          activated_at: new Date(),
          expires_at: expiresAt,
        }, { transaction });

        // Update user's upgrade timestamp (for 30-day withdrawal rule)
        await deposit.user.update({
          last_plan_upgrade_at: new Date(),
        }, { transaction });
        // Distribute referral bonus (Direct only)
        await distributeInvestmentPlanCommission(deposit.user_id, plan.referral_bonus, { 
          transaction, 
          planName: plan.name,
          purchasedPlanAmount: parseFloat(plan.investment_amount)
        });

        logger.info(`[roi] Activated plan ${plan.name} for user ${deposit.user_id} after deposit approval`);
      }
    }

    await transaction.commit();

    // CRITICAL FIX: If user was referred, increment their referrer's today_direct_joins
    // This unlocks second ad views for the referrer
    if (deposit.user.referred_by) {
      try {
        const referrer = await User.findByPk(deposit.user.referred_by);
        if (referrer) {
          await referrer.incrementDailyDirectJoins();
          logger.info(`Incremented today_direct_joins for referrer ${deposit.user.referred_by} after approving deposit for user ${deposit.user_id}`);
        }
      } catch (error) {
        logger.error(`Error incrementing daily direct joins for referrer:`, error);
        // Don't fail the deposit approval if increment fails
      }
    }

    // CRITICAL FIX: Auto-award daily referral bonus if referrer has 3+ referrals today
    // This automatically adds bonus to wallet when 3+ direct joinings are approved
    if (deposit.user.referred_by) {
      try {
        const bonusResult = await autoAwardDailyBonus(deposit.user.referred_by);
        if (bonusResult.awarded) {
          logger.info(`Auto-awarded daily bonus to referrer ${deposit.user.referred_by}: ${bonusResult.bonusCount} bonus(es) worth ${bonusResult.bonusAmount} PKR`);
        }
      } catch (error) {
        logger.error(`Error auto-awarding daily bonus to referrer ${deposit.user.referred_by}:`, error);
        // Don't fail the deposit approval if bonus award fails
      }
    }

    // CRITICAL FIX: Auto-award rank reward and deposit reward if referrer reaches threshold
    // These rewards are automatically added to wallet
    if (deposit.user.referred_by) {
      try {
        // Auto-award rank reward (only when deposit is approved)
        const rankResult = await autoAwardRankReward(deposit.user.referred_by);
        if (rankResult.awarded) {
          if (rankResult.ranksAwarded > 1) {
            logger.info(`Auto-awarded ${rankResult.ranksAwarded} rank rewards to referrer ${deposit.user.referred_by}: ${rankResult.totalRewardAmount} PKR total for ${rankResult.referralsCount} referrals (${rankResult.ranks.map(r => r.name).join(', ')})`);
          } else if (rankResult.ranksAwarded === 1) {
            logger.info(`Auto-awarded ${rankResult.ranks[0].name} reward to referrer ${deposit.user.referred_by}: ${rankResult.totalRewardAmount} PKR for ${rankResult.referralsCount} referrals`);
          }
        }

        // Auto-award deposit reward (when user reaches 15+ referrals after deposit)
        const depositRewardResult = await autoAwardDepositReward(deposit.user.referred_by);
        if (depositRewardResult.awarded) {
          logger.info(`Auto-awarded deposit reward to referrer ${deposit.user.referred_by}: ${depositRewardResult.rewardAmount} PKR for ${depositRewardResult.referralsCount} referrals`);
        }
      } catch (error) {
        logger.error(`Error auto-awarding rewards to referrer ${deposit.user.referred_by}:`, error);
        // Don't fail the deposit approval if reward award fails
      }
    }

    // Get updated user data for response
    const updatedUser = await User.findByPk(deposit.user_id, {
      attributes: ['id', 'name', 'email', 'wallet_balance'],
    });

    res.status(200).json({
      success: true,
      message: 'Deposit approved successfully',
      data: {
        id: deposit.id,
        userId: deposit.user_id,
        user: updatedUser,
        amount: depositAmount,
        amountUSD: constants.convertPkrToUsd(depositAmount),
        status: 'approved',
        approvedAt: new Date(),
        adminNotes,
        note: 'Deposit amount NOT added to wallet balance - deposits are separate from earnings',
        currentWalletBalance: {
          pkr: parseFloat(updatedUser.wallet_balance),
          usd: constants.convertPkrToUsd(parseFloat(updatedUser.wallet_balance)),
        },
      },
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error approving deposit:', error);
    next(error);
  }
};

/**
 * @desc    Reject deposit (Admin only)
 * @route   PUT /api/v1/deposits/:id/reject
 * @access  Private/Admin
 */
exports.rejectDeposit = async (req, res, next) => {
  try {
    const depositId = req.params.id;
    const { reason, adminNotes } = req.body;

    if (!reason) {
      return res.status(400).json({
        success: false,
        message: 'Rejection reason is required',
      });
    }

    const deposit = await Deposit.findByPk(depositId, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    if (!deposit) {
      return res.status(404).json({
        success: false,
        message: 'Deposit request not found',
      });
    }

    if (deposit.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: `Deposit request is already ${deposit.status}`,
      });
    }

    // Update deposit status
    await deposit.update({
      status: 'rejected',
      admin_notes: adminNotes,
      rejection_reason: reason,
      rejected_by: req.user.id,
      rejected_at: new Date(),
    });

    res.status(200).json({
      success: true,
      message: 'Deposit rejected successfully',
      data: {
        id: deposit.id,
        userId: deposit.user_id,
        user: deposit.user,
        amount: parseFloat(deposit.amount),
        amountUSD: constants.convertPkrToUsd(parseFloat(deposit.amount)),
        status: 'rejected',
        reason,
        rejectedAt: new Date(),
        adminNotes,
      },
    });
  } catch (error) {
    logger.error('Error rejecting deposit:', error);
    next(error);
  }
};

/**
 * @desc    Get all deposits (Admin only)
 * @route   GET /api/v1/deposits/admin/all
 * @access  Private/Admin
 */
exports.getAllDeposits = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    const offset = (page - 1) * limit;
    const status = req.query.status; // pending, approved, rejected
    const search = req.query.search;

    // Build where clause
    const whereClause = {};
    if (status) {
      whereClause.status = status;
    }

    if (search) {
      whereClause[Op.or] = [
        { transaction_id: { [Op.iLike]: `%${search}%` } },
        { description: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Deposit.findAndCountAll({
      where: whereClause,
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'referral_code'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        deposits: rows.map(deposit => ({
          id: deposit.id,
          userId: deposit.user_id,
          user: deposit.user ? {
            id: deposit.user.id,
            name: deposit.user.name,
            email: deposit.user.email,
            phone: deposit.user.phone,
            referralCode: deposit.user.referral_code,
          } : null,
          amount: parseFloat(deposit.amount),
          amountUSD: constants.convertPkrToUsd(parseFloat(deposit.amount)),
          paymentMethod: deposit.payment_method,
          transactionId: deposit.transaction_id,
          description: deposit.description,
          proofImageUrl: deposit.proof_image_url,
          status: deposit.status,
          adminNotes: deposit.admin_notes,
          approvedBy: deposit.approved_by,
          rejectedBy: deposit.rejected_by,
          approvedAt: deposit.approved_at,
          rejectedAt: deposit.rejected_at,
          createdAt: deposit.created_at,
          updatedAt: deposit.updated_at,
        })),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting all deposits:', error);
    next(error);
  }
};

/**
 * @desc    Get deposit statistics (Admin only)
 * @route   GET /api/v1/deposits/admin/stats
 * @access  Private/Admin
 */
exports.getDepositStats = async (req, res, next) => {
  try {
    const stats = await Deposit.findAll({
      attributes: [
        'status',
        [Deposit.sequelize.fn('COUNT', Deposit.sequelize.col('id')), 'count'],
        [Deposit.sequelize.fn('SUM', Deposit.sequelize.col('amount')), 'totalAmount'],
      ],
      group: ['status'],
      raw: true,
    });

    const totalDeposits = await Deposit.count();

    const totalAmount = await Deposit.sum('amount', {
      where: { status: 'approved' },
    });

    const statsObject = {
      pending: { count: 0, amount: 0 },
      approved: { count: 0, amount: 0 },
      rejected: { count: 0, amount: 0 },
    };

    stats.forEach(stat => {
      const status = stat.status;
      const count = parseInt(stat.count);
      const amount = parseFloat(stat.totalAmount || 0);
      
      statsObject[status] = {
        count,
        amount,
        amountUSD: constants.convertPkrToUsd(amount),
      };
    });

    res.status(200).json({
      success: true,
      data: {
        totalDeposits,
        totalAmount: totalAmount || 0,
        totalAmountUSD: constants.convertPkrToUsd(totalAmount || 0),
        byStatus: statsObject,
      },
    });
  } catch (error) {
    logger.error('Error getting deposit stats:', error);
    next(error);
  }
};

