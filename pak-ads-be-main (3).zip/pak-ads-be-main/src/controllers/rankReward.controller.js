const { User, Earning, RankReward, Deposit } = require('../models');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const constants = require('../config/constants');
const logger = require('../config/logger');
const { hasApprovedDeposit } = require('../utils/depositGuard');

/**
 * @desc    Claim rank-based reward
 * @route   POST /api/rank-reward/claim
 * @access  Private (User)
 */
exports.claimRankReward = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const userId = req.user.id;

    // Require at least one approved deposit before allowing rank reward claims
    const depositApproved = await hasApprovedDeposit(userId, transaction);
    if (!depositApproved) {
      await transaction.rollback();
      return res.status(403).json({
        success: false,
        code: 'DEPOSIT_REQUIRED',
        message: 'You must have at least one approved deposit to claim rank rewards',
      });
    }

    // CRITICAL: Count only referrals whose deposits are APPROVED
    const directReferralsCount = await User.count({
      where: { referred_by: userId },
      include: [{
        model: Deposit,
        as: 'deposits',
        where: {
          status: 'approved'
        },
        required: true,
        attributes: [],
      }],
      distinct: true,
      transaction,
    });

    // Get user's current balance
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_earnings'],
      transaction,
    });

    if (!user) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Determine eligible rank based on direct referrals count
    const eligibleRank = determineEligibleRank(directReferralsCount);

    if (!eligibleRank) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `You need at least ${constants.RANK_REWARDS[1].members} direct referrals to claim any rank reward`,
        data: {
          currentReferrals: directReferralsCount,
          nextRankRequirement: constants.RANK_REWARDS[1].members,
          referralsNeeded: constants.RANK_REWARDS[1].members - directReferralsCount,
        },
      });
    }

    // Check if user has already claimed this rank reward
    const existingReward = await RankReward.findOne({
      where: {
        user_id: userId,
        rank: eligibleRank.rank,
      },
      transaction,
    });

    if (existingReward) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `You have already claimed the ${eligibleRank.name} reward`,
        data: {
          currentReferrals: directReferralsCount,
          alreadyClaimed: true,
          claimedReward: {
            rank: existingReward.rank,
            rankName: existingReward.rank_name,
            amount: {
              pkr: parseFloat(existingReward.reward_amount),
              usd: parseFloat(existingReward.reward_amount_usd),
            },
            claimedAt: existingReward.claimed_at,
          },
        },
      });
    }

    // Check if user can claim a higher rank
    const nextRank = getNextAvailableRank(directReferralsCount, userId, transaction);
    if (nextRank && nextRank.rank > eligibleRank.rank) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `You have ${directReferralsCount} direct referrals. You can claim ${nextRank.name} (${nextRank.requiredMembers} referrals) for ${nextRank.rewardUSD} instead of ${eligibleRank.name}`,
        data: {
          currentReferrals: directReferralsCount,
          eligibleRank: {
            rank: eligibleRank.rank,
            name: eligibleRank.name,
            requiredMembers: eligibleRank.requiredMembers,
            rewardUSD: eligibleRank.rewardUSD,
            rewardPKR: eligibleRank.rewardPKR,
          },
          higherRank: {
            rank: nextRank.rank,
            name: nextRank.name,
            requiredMembers: nextRank.requiredMembers,
            rewardUSD: nextRank.rewardUSD,
            rewardPKR: nextRank.rewardPKR,
          },
        },
      });
    }

    // Create earning record for the rank reward
    const earning = await Earning.create({
      user_id: userId,
      amount: eligibleRank.rewardPKR,
      type: 'rank_reward',
      level: eligibleRank.rank,
      from_user_id: null,
      description: `${eligibleRank.name} reward: ${eligibleRank.rewardUSD} for ${directReferralsCount} direct referrals`,
      status: 'completed',
      metadata: JSON.stringify({
        rank: eligibleRank.rank,
        rankName: eligibleRank.name,
        requiredMembers: eligibleRank.requiredMembers,
        actualMembers: directReferralsCount,
        rewardUSD: eligibleRank.rewardUSD,
        claimedAt: new Date(),
      }),
    }, { transaction });

    // Create rank reward record
    await RankReward.create({
      user_id: userId,
      rank: eligibleRank.rank,
      rank_name: eligibleRank.name,
      required_members: eligibleRank.requiredMembers,
      actual_members: directReferralsCount,
      reward_amount: eligibleRank.rewardPKR,
      reward_amount_usd: eligibleRank.rewardUSD,
      earning_id: earning.id,
    }, { transaction });

    // Update user's wallet balance and total earnings
    await user.update({
      wallet_balance: parseFloat(user.wallet_balance) + eligibleRank.rewardPKR,
      total_earnings: parseFloat(user.total_earnings) + eligibleRank.rewardPKR,
    }, { transaction });

    await transaction.commit();

    res.status(200).json({
      success: true,
      message: `Congratulations! You claimed ${eligibleRank.name} reward worth ${eligibleRank.rewardUSD}!`,
      data: {
        rank: {
          rank: eligibleRank.rank,
          name: eligibleRank.name,
          requiredMembers: eligibleRank.requiredMembers,
          actualMembers: directReferralsCount,
          reward: {
            pkr: eligibleRank.rewardPKR,
            usd: eligibleRank.rewardUSD,
          },
        },
        remainingBalance: {
          pkr: parseFloat(user.wallet_balance) + eligibleRank.rewardPKR,
          usd: constants.convertPkrToUsd(parseFloat(user.wallet_balance) + eligibleRank.rewardPKR),
        },
        earningId: earning.id,
      },
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error claiming rank reward:', error);
    next(error);
  }
};

/**
 * @desc    Get user's rank status and available rewards
 * @route   GET /api/rank-reward/status
 * @access  Private (User)
 */
exports.getRankStatus = async (req, res, next) => {
  try {
    const userId = req.user.id;

    // CRITICAL: Count only referrals whose deposits are APPROVED
    const directReferralsCount = await User.count({
      where: { referred_by: userId },
      include: [{
        model: Deposit,
        as: 'deposits',
        where: {
          status: 'approved'
        },
        required: true,
        attributes: [],
      }],
      distinct: true,
    });

    // Get user's claimed rewards
    const claimedRewards = await RankReward.findAll({
      where: { user_id: userId },
      order: [['rank', 'ASC']],
    });

    // Determine current eligible rank
    const currentEligibleRank = determineEligibleRank(directReferralsCount);
    
    // Get all available ranks for reference
    const allRanks = Object.values(constants.RANK_REWARDS).map(rank => ({
      rank: rank.name,
      requiredMembers: rank.members,
      rewardUSD: rank.rewardUSD,
      rewardPKR: rank.rewardPKR,
      isClaimed: claimedRewards.some(claimed => claimed.rank === Object.keys(constants.RANK_REWARDS).find(key => constants.RANK_REWARDS[key].name === rank.name)),
      isEligible: directReferralsCount >= rank.members,
    }));

    // Get next available rank
    const nextRank = allRanks.find(rank => 
      !rank.isClaimed && 
      directReferralsCount >= rank.requiredMembers
    );

    res.status(200).json({
      success: true,
      data: {
        currentReferrals: directReferralsCount,
        currentEligibleRank: currentEligibleRank ? {
          rank: currentEligibleRank.rank,
          name: currentEligibleRank.name,
          requiredMembers: currentEligibleRank.requiredMembers,
          rewardUSD: currentEligibleRank.rewardUSD,
          rewardPKR: currentEligibleRank.rewardPKR,
        } : null,
        nextAvailableRank: nextRank,
        claimedRewards: claimedRewards.map(reward => ({
          rank: reward.rank,
          rankName: reward.rank_name,
          requiredMembers: reward.required_members,
          actualMembers: reward.actual_members,
          reward: {
            pkr: parseFloat(reward.reward_amount),
            usd: parseFloat(reward.reward_amount_usd),
          },
          claimedAt: reward.claimed_at,
        })),
        allRanks,
      },
    });
  } catch (error) {
    logger.error('Error getting rank status:', error);
    next(error);
  }
};

/**
 * @desc    Get rank reward history
 * @route   GET /api/rank-reward/history?page=1&limit=10
 * @access  Private (User)
 */
exports.getRankRewardHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows } = await RankReward.findAndCountAll({
      where: { user_id: userId },
      include: [
        {
          model: Earning,
          as: 'earning',
          attributes: ['id', 'amount', 'description', 'created_at'],
        },
      ],
      order: [['claimed_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    // Calculate total rewards earned
    const totalRewards = await RankReward.sum('reward_amount', {
      where: { user_id: userId },
    });

    const totalRewardsUSD = await RankReward.sum('reward_amount_usd', {
      where: { user_id: userId },
    });

    res.status(200).json({
      success: true,
      data: {
        rewards: rows.map(reward => ({
          id: reward.id,
          rank: reward.rank,
          rankName: reward.rank_name,
          requiredMembers: reward.required_members,
          actualMembers: reward.actual_members,
          reward: {
            pkr: parseFloat(reward.reward_amount),
            usd: parseFloat(reward.reward_amount_usd),
          },
          earning: reward.earning,
          claimedAt: reward.claimed_at,
        })),
        summary: {
          totalRewards: {
            pkr: parseFloat(totalRewards || 0),
            usd: parseFloat(totalRewardsUSD || 0),
          },
          totalRanksClaimed: count,
        },
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting rank reward history:', error);
    next(error);
  }
};

/**
 * Helper function to determine eligible rank based on direct referrals count
 * @param {number} referralsCount - Number of direct referrals
 * @returns {object|null} - Eligible rank or null
 */
function determineEligibleRank(referralsCount) {
  const ranks = constants.RANK_REWARDS;
  
  // Find the highest rank the user is eligible for
  let eligibleRank = null;
  
  for (const [rankNumber, rankData] of Object.entries(ranks)) {
    if (referralsCount >= rankData.members) {
      eligibleRank = {
        rank: parseInt(rankNumber),
        name: rankData.name,
        requiredMembers: rankData.members,
        rewardUSD: rankData.rewardUSD,
        rewardPKR: rankData.rewardPKR,
      };
    }
  }
  
  return eligibleRank;
}

/**
 * Helper function to get next available rank that user can claim
 * @param {number} referralsCount - Number of direct referrals
 * @param {number} userId - User ID
 * @param {object} transaction - Database transaction
 * @returns {object|null} - Next available rank or null
 */
async function getNextAvailableRank(referralsCount, userId, transaction) {
  const ranks = constants.RANK_REWARDS;
  
  // Get claimed ranks
  const claimedRanks = await RankReward.findAll({
    where: { user_id: userId },
    attributes: ['rank'],
    transaction,
  });
  
  const claimedRankNumbers = claimedRanks.map(reward => reward.rank);
  
  // Find the highest rank user can claim
  let nextRank = null;
  
  for (const [rankNumber, rankData] of Object.entries(ranks)) {
    const rankNum = parseInt(rankNumber);
    if (referralsCount >= rankData.members && !claimedRankNumbers.includes(rankNum)) {
      nextRank = {
        rank: rankNum,
        name: rankData.name,
        requiredMembers: rankData.members,
        rewardUSD: rankData.rewardUSD,
        rewardPKR: rankData.rewardPKR,
      };
    }
  }
  
  return nextRank;
}

/**
 * Auto-award rank reward when user reaches threshold
 * This is called automatically from admin approval
 * Awards ALL eligible unclaimed ranks (not just the highest one)
 * @param {number} userId - ID of the user who should get the reward
 * @returns {Promise<object>} - Reward result
 */
exports.autoAwardRankReward = async (userId) => {
  const transaction = await sequelize.transaction();
  
  try {
    // CRITICAL: Count only referrals whose deposits are APPROVED
    // Rank rewards should only be given when referred users have approved deposits
    const directReferralsCount = await User.count({
      where: { referred_by: userId },
      include: [{
        model: Deposit,
        as: 'deposits',
        where: {
          status: 'approved'
        },
        required: true, // Only count users who have at least one approved deposit
        attributes: [],
      }],
      distinct: true,
      transaction,
    });

    // Check if user has approved deposit
    const depositApproved = await hasApprovedDeposit(userId, transaction);
    if (!depositApproved) {
      await transaction.rollback();
      return { awarded: false, reason: 'deposit_required' };
    }

    // Get user's current balance
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_earnings'],
      transaction,
    });

    if (!user) {
      await transaction.rollback();
      return { awarded: false, reason: 'user_not_found' };
    }

    // Get all already claimed ranks
    const claimedRewards = await RankReward.findAll({
      where: { user_id: userId },
      attributes: ['rank'],
      transaction,
    });

    const claimedRankNumbers = claimedRewards.map(r => r.rank);

    // Find ALL eligible ranks that haven't been claimed yet
    const ranks = constants.RANK_REWARDS;
    const eligibleRanks = [];
    
    for (const [rankNumber, rankData] of Object.entries(ranks)) {
      const rankNum = parseInt(rankNumber);
      // Check if user is eligible for this rank AND hasn't claimed it yet
      if (directReferralsCount >= rankData.members && !claimedRankNumbers.includes(rankNum)) {
        eligibleRanks.push({
          rank: rankNum,
          name: rankData.name,
          requiredMembers: rankData.members,
          rewardUSD: rankData.rewardUSD,
          rewardPKR: rankData.rewardPKR,
        });
      }
    }

    // Sort by rank number (ascending) to award lower ranks first
    eligibleRanks.sort((a, b) => a.rank - b.rank);

    if (eligibleRanks.length === 0) {
      await transaction.rollback();
      return { awarded: false, reason: 'no_eligible_ranks' };
    }

    // Award ALL eligible ranks
    let totalRewardAmount = 0;
    const awardedRanks = [];

    for (const eligibleRank of eligibleRanks) {
      // Create earning record for the reward
      const earning = await Earning.create({
        user_id: userId,
        amount: eligibleRank.rewardPKR,
        type: 'rank_reward',
        level: eligibleRank.rank,
        from_user_id: null,
        description: `${eligibleRank.name} reward for ${directReferralsCount} direct referrals`,
        status: 'completed',
        metadata: JSON.stringify({
          rank: eligibleRank.rank,
          rankName: eligibleRank.name,
          requiredMembers: eligibleRank.requiredMembers,
          actualMembers: directReferralsCount,
        }),
      }, { transaction });

      // Create rank reward record
      await RankReward.create({
        user_id: userId,
        rank: eligibleRank.rank,
        rank_name: eligibleRank.name,
        required_members: eligibleRank.requiredMembers,
        actual_members: directReferralsCount,
        reward_amount: eligibleRank.rewardPKR,
        reward_amount_usd: eligibleRank.rewardUSD,
        earning_id: earning.id,
      }, { transaction });

      totalRewardAmount += eligibleRank.rewardPKR;
      awardedRanks.push({
        rank: eligibleRank.rank,
        name: eligibleRank.name,
        rewardAmount: eligibleRank.rewardPKR,
      });

      logger.info(`Auto-awarded ${eligibleRank.name} reward to user ${userId}: ${eligibleRank.rewardPKR} PKR for ${directReferralsCount} referrals`);
    }

    // Update user's wallet balance and total earnings with total amount
    await user.update({
      wallet_balance: parseFloat(user.wallet_balance) + totalRewardAmount,
      total_earnings: parseFloat(user.total_earnings) + totalRewardAmount,
    }, { transaction });

    await transaction.commit();

    logger.info(`Auto-awarded ${awardedRanks.length} rank reward(s) to user ${userId}: ${totalRewardAmount} PKR total for ${directReferralsCount} referrals`);

    return {
      awarded: true,
      ranksAwarded: awardedRanks.length,
      ranks: awardedRanks,
      totalRewardAmount: totalRewardAmount,
      referralsCount: directReferralsCount,
    };
  } catch (error) {
    await transaction.rollback();
    logger.error(`Error auto-awarding rank reward to user ${userId}:`, error);
    return { awarded: false, reason: 'error', error: error.message };
  }
};

module.exports = {
  claimRankReward: exports.claimRankReward,
  getRankStatus: exports.getRankStatus,
  getRankRewardHistory: exports.getRankRewardHistory,
  autoAwardRankReward: exports.autoAwardRankReward,
};
