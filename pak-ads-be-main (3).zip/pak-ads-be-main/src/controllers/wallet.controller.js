const { User, Earning, Deposit, UserPlan } = require('../models');
const Sequelize = require('sequelize');
const { Op } = Sequelize;
const { sequelize } = require('../config/database');

// Ensure Op is available
if (!Op || !Op.in) {
  throw new Error('Sequelize Op is not properly imported');
}
const logger = require('../config/logger');
const constants = require('../config/constants');

const getOrdinalSuffix = (number) => {
  const remainderTen = number % 10;
  const remainderHundred = number % 100;

  if (remainderTen === 1 && remainderHundred !== 11) {
    return `${number}st`;
  }
  if (remainderTen === 2 && remainderHundred !== 12) {
    return `${number}nd`;
  }
  if (remainderTen === 3 && remainderHundred !== 13) {
    return `${number}rd`;
  }
  return `${number}th`;
};

const getWithdrawalTiers = () => constants.CURRENCY.WITHDRAWAL_TIERS || [];

const getFallbackMinimum = () => {
  const minPKR = constants.CURRENCY.MIN_WITHDRAWAL_PKR || 0;
  const minUSD = constants.CURRENCY.MIN_WITHDRAWAL_USD || 0;

  return {
    minPKR,
    minUSD,
    withdrawalNumber: 1,
    effectiveWithdrawalNumber: 1,
    baseWithdrawalNumber: 1,
    label: '1st withdrawal',
  };
};

const resolveWithdrawalTier = (withdrawalNumber) => {
  const tiers = getWithdrawalTiers();

  if (!tiers.length) {
    return getFallbackMinimum();
  }

  const sortedTiers = [...tiers].sort((a, b) => a.withdrawalNumber - b.withdrawalNumber);
  const directMatch = sortedTiers.find(tier => tier.withdrawalNumber === withdrawalNumber);
  const selectedTier = directMatch || sortedTiers[sortedTiers.length - 1];

  const isBeyondDefinedTiers = !directMatch && withdrawalNumber > selectedTier.withdrawalNumber;
  const ordinalForDisplay = isBeyondDefinedTiers
    ? `${getOrdinalSuffix(selectedTier.withdrawalNumber)}+`
    : getOrdinalSuffix(withdrawalNumber);

  return {
    ...selectedTier,
    label: `${ordinalForDisplay} withdrawal`,
    effectiveWithdrawalNumber: withdrawalNumber,
    baseWithdrawalNumber: selectedTier.withdrawalNumber,
  };
};

const getUserWithdrawalTier = async (userId, options = {}) => {
  const { transaction } = options;

  const completedWithdrawals = await Earning.count({
    where: {
      user_id: userId,
      type: 'withdrawal',
      status: {
        [Op.in]: ['completed', 'sent'],
      },
    },
    transaction,
  });

  const withdrawalNumber = completedWithdrawals + 1;
  const tier = resolveWithdrawalTier(withdrawalNumber);

  return {
    tier,
    completedWithdrawals,
    withdrawalNumber,
  };
};

/**
 * @desc    Get user's wallet balance
 * @route   GET /api/wallet/balance
 * @access  Private (User)
 */
exports.getWalletBalance = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const user = await User.findByPk(userId, {
      attributes: ['id', 'name', 'email', 'wallet_balance', 'total_earnings', 'total_withdrawn', 'total_referrals'],
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.status(200).json({
      success: true,
      data: {
        walletBalance: parseFloat(user.wallet_balance),
        walletBalanceUSD: constants.convertPkrToUsd(parseFloat(user.wallet_balance)),
        totalEarnings: parseFloat(user.total_earnings),
        totalEarningsUSD: constants.convertPkrToUsd(parseFloat(user.total_earnings)),
        totalWithdrawn: parseFloat(user.total_withdrawn),
        totalWithdrawnUSD: constants.convertPkrToUsd(parseFloat(user.total_withdrawn)),
        totalReferrals: user.total_referrals,
        availableBalance: parseFloat(user.wallet_balance),
        availableBalanceUSD: constants.convertPkrToUsd(parseFloat(user.wallet_balance)),
        currencyRate: {
          usdToPkr: constants.CURRENCY.USD_TO_PKR_RATE,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting wallet balance:', error);
    next(error);
  }
};

/**
 * @desc    Get user's earnings history
 * @route   GET /api/wallet/earnings?page=1&limit=10
 * @access  Private (User)
 */
exports.getEarningsHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows } = await Earning.findAndCountAll({
      where: { user_id: userId },
      include: [
        {
          model: User,
          as: 'fromUser',
          attributes: ['id', 'name', 'email'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        earnings: rows.map(earning => ({
          id: earning.id,
          amount: parseFloat(earning.amount),
          level: earning.level,
          type: earning.type,
          description: earning.description,
          status: earning.status,
          fromUser: earning.fromUser,
          createdAt: earning.created_at,
        })),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting earnings history:', error);
    next(error);
  }
};

/**
 * @desc    Get earnings summary by level
 * @route   GET /api/wallet/earnings-summary
 * @access  Private (User)
 */
exports.getEarningsSummary = async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Get earnings grouped by level
    const earningsByLevel = await Earning.findAll({
      where: { 
        user_id: userId,
        type: 'referral_commission',
      },
      attributes: [
        'level',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
      ],
      group: ['level'],
      order: [['level', 'ASC']],
      raw: true,
    });

    // Get total earnings by type
    const earningsByType = await Earning.findAll({
      where: { user_id: userId },
      attributes: [
        'type',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
      ],
      group: ['type'],
      raw: true,
    });

    // Get user's wallet info
    const user = await User.findByPk(userId, {
      attributes: ['wallet_balance', 'total_earnings', 'total_withdrawn', 'total_referrals'],
    });

    res.status(200).json({
      success: true,
      data: {
        summary: {
          walletBalance: parseFloat(user.wallet_balance),
          totalEarnings: parseFloat(user.total_earnings),
          totalWithdrawn: parseFloat(user.total_withdrawn),
          totalReferrals: user.total_referrals,
        },
        earningsByLevel: earningsByLevel.map(item => ({
          level: item.level,
          count: parseInt(item.count, 10),
          total: parseFloat(item.total || 0),
        })),
        earningsByType: earningsByType.map(item => ({
          type: item.type,
          count: parseInt(item.count, 10),
          total: parseFloat(item.total || 0),
        })),
      },
    });
  } catch (error) {
    logger.error('Error getting earnings summary:', error);
    next(error);
  }
};

/**
 * @desc    Get earnings from a specific level
 * @route   GET /api/wallet/earnings-by-level/:level
 * @access  Private (User)
 */
exports.getEarningsByLevel = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { level } = req.params;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    if (level < 1 || level > 7) {
      return res.status(400).json({
        success: false,
        message: 'Level must be between 1 and 7',
      });
    }

    const { count, rows } = await Earning.findAndCountAll({
      where: { 
        user_id: userId,
        level: parseInt(level, 10),
      },
      include: [
        {
          model: User,
          as: 'fromUser',
          attributes: ['id', 'name', 'email'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    // Calculate total earnings for this level
    const totalEarnings = await Earning.sum('amount', {
      where: {
        user_id: userId,
        level: parseInt(level, 10),
      },
    });

    res.status(200).json({
      success: true,
      data: {
        level: parseInt(level, 10),
        totalEarnings: parseFloat(totalEarnings || 0),
        totalCount: count,
        earnings: rows.map(earning => ({
          id: earning.id,
          amount: parseFloat(earning.amount),
          description: earning.description,
          fromUser: earning.fromUser,
          createdAt: earning.created_at,
        })),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting earnings by level:', error);
    next(error);
  }
};

/**
 * @desc    Get referral network tree
 * @route   GET /api/wallet/referral-tree
 * @access  Private (User)
 */
exports.getReferralTree = async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Get ALL direct referrals (Level 1) - will filter by approved deposits later
    const directReferrals = await User.findAll({
      where: { referred_by: userId },
      attributes: ['id', 'name', 'email', 'created_at', 'total_referrals'],
      include: [
        {
          model: Deposit,
          as: 'deposits',
          attributes: ['id', 'status', 'amount'],
          required: false,
        },
      ],
      order: [['created_at', 'DESC']],
    });

    // Get earnings separately for each referral to calculate total earned from each
    // This is more efficient and accurate than using include with where clause
    const referralIds = directReferrals.map(ref => ref.id).filter(id => id != null);
    const earningsByReferral = {};
    
    if (referralIds.length > 0 && Op && Op.in) {
      const earnings = await Earning.findAll({
        where: {
          user_id: userId,
          from_user_id: { [Op.in]: referralIds },
          type: 'referral_commission', // Only count referral commissions
        },
        attributes: ['from_user_id', [sequelize.fn('SUM', sequelize.col('amount')), 'total']],
        group: ['from_user_id'],
        raw: true,
      });

      // Build map of referral ID to total earnings
      earnings.forEach(earning => {
        earningsByReferral[earning.from_user_id] = parseFloat(earning.total || 0);
      });
    }

    // Get all referrals with their levels (for counting all)
    const allLevelCounts = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, 1 as level
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, rt.level + 1
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT level, COUNT(*) as count
      FROM referral_tree
      GROUP BY level
      ORDER BY level;
    `, {
      replacements: { userId },
      type: sequelize.QueryTypes.SELECT,
    });

    // Get indirect referrals with approved deposits only
    // First, get all indirect referral IDs by level
    const indirectReferralsByLevel = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, 1 as level
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, rt.level + 1
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT id, level
      FROM referral_tree
      WHERE level > 1
      ORDER BY level, id;
    `, {
      replacements: { userId },
      type: sequelize.QueryTypes.SELECT,
    });

    // Get all indirect referral IDs
    const indirectReferralIds = indirectReferralsByLevel.map(item => item.id);

    // Get users with approved deposits from indirect referrals
    let indirectReferralsWithApproved = [];
    if (indirectReferralIds.length > 0) {
      indirectReferralsWithApproved = await User.findAll({
        where: {
          id: { [Op.in]: indirectReferralIds }
        },
        attributes: ['id'],
        include: [
          {
            model: Deposit,
            as: 'deposits',
            attributes: ['id', 'status'],
            required: false,
          },
        ],
      });

      // Filter to only those with approved deposits
      indirectReferralsWithApproved = indirectReferralsWithApproved.filter(user => {
        return user.deposits && user.deposits.some(d => d.status === 'approved');
      });
    }

    // Create a map of user ID to level
    const userIdToLevel = {};
    indirectReferralsByLevel.forEach(item => {
      userIdToLevel[item.id] = parseInt(item.level, 10);
    });

    // Count indirect referrals with approved deposits by level
    const indirectLevelsWithApproved = {};
    indirectReferralsWithApproved.forEach(user => {
      const level = userIdToLevel[user.id];
      if (level) {
        indirectLevelsWithApproved[level] = (indirectLevelsWithApproved[level] || 0) + 1;
      }
    });

    // Build indirect levels data with approved deposits count
    const indirectLevelsData = [];
    for (let level = 2; level <= 7; level++) {
      const allCount = allLevelCounts.find(item => parseInt(item.level, 10) === level);
      const approvedCount = indirectLevelsWithApproved[level] || 0;
      
      if (allCount) {
        indirectLevelsData.push({
          level: level,
          count: approvedCount, // Only count those with approved deposits
          total: parseInt(allCount.count, 10), // Total count for reference
        });
      }
    }

    // Filter to only show direct referrals with approved deposits
    const directReferralsWithApproved = directReferrals.filter(ref => {
      return ref.deposits && ref.deposits.some(d => d.status === 'approved');
    });

    // Calculate statistics
    const totalDirectReferrals = directReferrals.length;
    const withApprovedCount = directReferralsWithApproved.length;
    const withoutApprovedCount = totalDirectReferrals - withApprovedCount;

    // Get direct level data
    const directLevelData = allLevelCounts.find(item => parseInt(item.level, 10) === 1);
    
    // Calculate total indirect referrals with approved deposits (levels 2-7)
    const totalIndirectReferrals = indirectLevelsData.reduce((sum, item) => {
      return sum + parseInt(item.count, 10);
    }, 0);

    res.status(200).json({
      success: true,
      data: {
        // Show ONLY direct referrals with approved deposits
        directReferrals: directReferralsWithApproved.map(ref => {
          const approvedDeposit = ref.deposits?.find(d => d.status === 'approved');
          const earnedFromThis = earningsByReferral[ref.id] || 0;
          
          return {
            id: ref.id,
            name: ref.name,
            email: ref.email,
            joinedAt: ref.created_at,
            totalReferrals: ref.total_referrals,
            hasApprovedDeposit: true, // Always true since we filtered
            depositAmount: approvedDeposit ? parseFloat(approvedDeposit.amount) : null,
            earnedFromThis: earnedFromThis,
          };
        }),
        // Statistics
        directReferralsStats: {
          total: totalDirectReferrals,
          withApprovedDeposits: withApprovedCount,
          withoutApprovedDeposits: withoutApprovedCount,
        },
        // Indirect referrals statistics (only with approved deposits)
        indirectReferralsStats: {
          total: totalIndirectReferrals,
          byLevel: indirectLevelsData.map(item => ({
            level: parseInt(item.level, 10),
            count: parseInt(item.count, 10), // Only approved deposits
            total: item.total, // Total count for reference
          })),
        },
        // Network summary shows referrals at each level
        // Direct: only with approved deposits, Indirect: only with approved deposits
        networkSummary: [
          {
            level: 1,
            count: withApprovedCount, // Only direct with approved deposits
            type: 'direct',
            total: totalDirectReferrals, // Total for reference
          },
          ...indirectLevelsData.map(item => ({
            level: parseInt(item.level, 10),
            count: parseInt(item.count, 10), // Only indirect with approved deposits
            type: 'indirect',
            total: item.total, // Total for reference
          })),
        ],
      },
    });
  } catch (error) {
    logger.error('Error getting referral tree:', error);
    next(error);
  }
};

/**
 * @desc    Request withdrawal
 * @route   POST /api/wallet/withdraw
 * @access  Private (User)
 */
exports.requestWithdrawal = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const userId = req.user.id;
    const { 
      amount, 
      paymentMethod, 
      accountType, 
      accountNumber, 
      accountTitle 
    } = req.body;

    // Validate required fields
    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid withdrawal amount',
      });
    }

    if (!accountType) {
      return res.status(400).json({
        success: false,
        message: 'Account type is required (easypaisa, jazzcash, bank, etc.)',
      });
    }

    if (!accountNumber) {
      return res.status(400).json({
        success: false,
        message: 'Account number is required',
      });
    }

    if (!accountTitle) {
      return res.status(400).json({
        success: false,
        message: 'Account title/name is required',
      });
    }

    const withdrawalAmount = parseFloat(amount);

    // Get user's current balance first
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_withdrawn'],
      transaction,
    });

    if (!user) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const currentBalance = parseFloat(user.wallet_balance);

    const {
      tier: currentTier,
      completedWithdrawals,
      withdrawalNumber,
    } = await getUserWithdrawalTier(userId, { transaction });



    if (withdrawalAmount < currentTier.minPKR) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `Not eligible. Minimum for your next withdrawal is PKR ${currentTier.minPKR}`,
        minimumAmount: {
          pkr: currentTier.minPKR,
          usd: currentTier.minUSD,
        },
        withdrawalNumber,
        completedWithdrawals,
      });
    }

    // Check if user has sufficient balance
    if (currentBalance < withdrawalAmount) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Insufficient wallet balance',
        availableBalance: {
          pkr: currentBalance,
          usd: constants.convertPkrToUsd(currentBalance),
        },
        requestedAmount: {
          pkr: withdrawalAmount,
          usd: constants.convertPkrToUsd(withdrawalAmount),
        },
      });
    }

    // Create withdrawal record in earnings table
    const withdrawal = await Earning.create({
      user_id: userId,
      amount: -withdrawalAmount, // Negative amount to indicate withdrawal
      type: 'withdrawal',
      level: null,
      from_user_id: null,
      description: `Withdrawal request: ${withdrawalAmount} PKR via ${accountType}`,
      status: 'pending',
      metadata: JSON.stringify({
        accountType,
        accountNumber,
        accountTitle,
        paymentMethod: paymentMethod || accountType,
        requestedAt: new Date(),
      }),
    }, { transaction });

    // Update user's wallet balance and total withdrawn
    await user.update({
      wallet_balance: currentBalance - withdrawalAmount,
      total_withdrawn: parseFloat(user.total_withdrawn) + withdrawalAmount,
    }, { transaction });

    await transaction.commit();

    res.status(200).json({
      success: true,
      message: 'Withdrawal request submitted successfully. It will be processed within 24-48 hours.',
      data: {
        withdrawalId: withdrawal.id,
        amount: withdrawalAmount,
        amountUSD: constants.convertPkrToUsd(withdrawalAmount),
        status: 'pending',
        withdrawalTier: {
          label: currentTier.label,
          minimumAmount: {
            pkr: currentTier.minPKR,
            usd: currentTier.minUSD,
          },
          completedWithdrawals,
          withdrawalNumber,
        },
        accountDetails: {
          accountType,
          accountNumber,
          accountTitle,
        },
        remainingBalance: {
          pkr: currentBalance - withdrawalAmount,
          usd: constants.convertPkrToUsd(currentBalance - withdrawalAmount),
        },
        totalWithdrawn: {
          pkr: parseFloat(user.total_withdrawn) + withdrawalAmount,
          usd: constants.convertPkrToUsd(parseFloat(user.total_withdrawn) + withdrawalAmount),
        },
      },
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error processing withdrawal request:', error);
    next(error);
  }
};

/**
 * @desc    Request plan-specific withdrawal
 * @route   POST /api/wallet/plan-withdraw
 * @access  Private (User)
 */
exports.requestPlanWithdrawal = async (req, res, next) => {
  const transaction = await sequelize.transaction();
  
  try {
    const userId = req.user.id;
    const { 
      amount, 
      paymentMethod, 
      accountType, 
      accountNumber, 
      accountTitle 
    } = req.body;

    // Validate required fields
    if (!amount || amount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid withdrawal amount',
      });
    }

    if (!accountType) {
      return res.status(400).json({
        success: false,
        message: 'Account type is required (easypaisa, jazzcash, bank, etc.)',
      });
    }

    if (!accountNumber) {
      return res.status(400).json({
        success: false,
        message: 'Account number is required',
      });
    }

    if (!accountTitle) {
      return res.status(400).json({
        success: false,
        message: 'Account title/name is required',
      });
    }

    const withdrawalAmount = parseFloat(amount);

    // Get user's current balance first
    const user = await User.findByPk(userId, {
      attributes: ['id', 'wallet_balance', 'total_withdrawn', 'created_at', 'last_plan_upgrade_at'],
      transaction,
    });

    if (!user) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    const currentBalance = parseFloat(user.wallet_balance);

    const {
      tier: currentTier,
      completedWithdrawals,
      withdrawalNumber,
    } = await getUserWithdrawalTier(userId, { transaction });

    // ROI PLAN SYSTEM CONSTRAINTS
    
    // 1. 30-day wait period rule (from registration or last plan upgrade)
    const now = new Date();
    const registrationDate = new Date(user.created_at || now);
    const lastUpgradeDate = user.last_plan_upgrade_at ? new Date(user.last_plan_upgrade_at) : null;
    
    const minutesSinceRegistration = (now - registrationDate) / (1000 * 60);
    const minutesSinceUpgrade = lastUpgradeDate ? (now - lastUpgradeDate) / (1000 * 60) : 999;

    if (minutesSinceRegistration < 3) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: req.t ? req.t('WITHDRAWAL_LOCKOUT') : 'You cannot withdraw before 3 minutes after registration',
        minutesRemaining: Math.ceil(3 - minutesSinceRegistration),
      });
    }

    if (lastUpgradeDate && minutesSinceUpgrade < 3) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: req.t ? req.t('WITHDRAWAL_LOCKOUT') : 'You cannot withdraw before 3 minutes after plan upgrade',
        minutesRemaining: Math.ceil(3 - minutesSinceUpgrade),
      });
    }

    // 2. Referral requirement (must refer at least one person who purchased a plan)
    const referralWithPlan = await UserPlan.findOne({
      include: [
        {
          model: User,
          as: 'user',
          where: { referred_by: userId },
          attributes: ['id'],
          required: true,
        },
      ],
      where: {
        status: { [Op.in]: ['active', 'completed'] },
      },
      transaction,
    });

    if (!referralWithPlan) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: req.t ? req.t('REFERRAL_REQUIRED') : 'You must refer at least one person who purchased a plan to unlock withdrawals',
      });
    }

    if (withdrawalAmount < currentTier.minPKR) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: `Not eligible. Minimum for your next withdrawal is PKR ${currentTier.minPKR}`,
        minimumAmount: {
          pkr: currentTier.minPKR,
          usd: currentTier.minUSD,
        },
        withdrawalNumber,
        completedWithdrawals,
      });
    }

    // Check if user has sufficient balance
    if (currentBalance < withdrawalAmount) {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Insufficient wallet balance',
        availableBalance: {
          pkr: currentBalance,
          usd: constants.convertPkrToUsd(currentBalance),
        },
        requestedAmount: {
          pkr: withdrawalAmount,
          usd: constants.convertPkrToUsd(withdrawalAmount),
        },
      });
    }

    // Create withdrawal record in earnings table
    const withdrawal = await Earning.create({
      user_id: userId,
      amount: -withdrawalAmount, // Negative amount to indicate withdrawal
      type: 'withdrawal',
      level: null,
      from_user_id: null,
      description: `Plan Withdrawal request: ${withdrawalAmount} PKR via ${accountType}`,
      status: 'pending',
      metadata: JSON.stringify({
        withdrawalType: 'plan_specific',
        accountType,
        accountNumber,
        accountTitle,
        paymentMethod: paymentMethod || accountType,
        requestedAt: new Date(),
      }),
    }, { transaction });

    // Update user's wallet balance and total withdrawn
    await user.update({
      wallet_balance: currentBalance - withdrawalAmount,
      total_withdrawn: parseFloat(user.total_withdrawn || 0) + withdrawalAmount,
    }, { transaction });

    await transaction.commit();

    res.status(200).json({
      success: true,
      message: 'Plan withdrawal request submitted successfully. It will be processed within 24-48 hours.',
      data: {
        withdrawalId: withdrawal.id,
        amount: withdrawalAmount,
        amountUSD: constants.convertPkrToUsd(withdrawalAmount),
        status: 'pending',
        withdrawalTier: {
          label: currentTier.label,
          minimumAmount: {
            pkr: currentTier.minPKR,
            usd: currentTier.minUSD,
          },
          completedWithdrawals,
          withdrawalNumber,
        },
        accountDetails: {
          accountType,
          accountNumber,
          accountTitle,
        },
        remainingBalance: {
          pkr: currentBalance - withdrawalAmount,
          usd: constants.convertPkrToUsd(currentBalance - withdrawalAmount),
        },
        totalWithdrawn: {
          pkr: parseFloat(user.total_withdrawn || 0) + withdrawalAmount,
          usd: constants.convertPkrToUsd(parseFloat(user.total_withdrawn || 0) + withdrawalAmount),
        },
      },
    });
  } catch (error) {
    await transaction.rollback();
    logger.error('Error processing plan withdrawal request:', error);
    next(error);
  }
};

/**
 * @desc    Get withdrawal history
 * @route   GET /api/wallet/withdrawals?page=1&limit=10
 * @access  Private (User)
 */
exports.getWithdrawalHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows } = await Earning.findAndCountAll({
      where: { 
        user_id: userId,
        type: 'withdrawal',
      },
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        withdrawals: rows.map(withdrawal => {
          const metadata = withdrawal.metadata ? JSON.parse(withdrawal.metadata) : null;
          return {
            id: withdrawal.id,
            amount: Math.abs(parseFloat(withdrawal.amount)),
            amountUSD: constants.convertPkrToUsd(Math.abs(parseFloat(withdrawal.amount))),
            status: withdrawal.status,
            description: withdrawal.description,
            createdAt: withdrawal.created_at,
            accountDetails: metadata ? {
              accountType: metadata.accountType,
              accountNumber: metadata.accountNumber,
              accountTitle: metadata.accountTitle,
            } : null,
            metadata: metadata,
          };
        }),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting withdrawal history:', error);
    next(error);
  }
};

/**
 * @desc    Get available payment methods for withdrawal
 * @route   GET /api/wallet/payment-methods
 * @access  Private (User)
 */
exports.getPaymentMethods = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const {
      tier: currentTier,
      completedWithdrawals,
      withdrawalNumber,
    } = await getUserWithdrawalTier(userId);

    // Get payment methods from constants
    const paymentMethods = constants.PAYMENT_METHODS.filter(method => method.active);

    const allTiers = getWithdrawalTiers().map(tier => {
      const usdValue = Number.isInteger(tier.minUSD) ? tier.minUSD.toFixed(0) : tier.minUSD.toFixed(2);
      const isCurrentTier = tier.withdrawalNumber === currentTier.baseWithdrawalNumber;

      return {
        withdrawalNumber: tier.withdrawalNumber,
        usd: tier.minUSD,
        pkr: tier.minPKR,
        label: tier.withdrawalNumber === currentTier.baseWithdrawalNumber && currentTier.effectiveWithdrawalNumber > tier.withdrawalNumber
          ? `${usdValue} USD or more`
          : `${usdValue} USD`,
        tierLabel: `${getOrdinalSuffix(tier.withdrawalNumber)} withdrawal`,
        isCurrent: isCurrentTier,
      };
    });

    const highestTier = allTiers[allTiers.length - 1] || null;

    res.status(200).json({
      success: true,
      data: {
        paymentMethods,
        minimumWithdrawal: {
          pkr: currentTier.minPKR,
          usd: currentTier.minUSD,
        },
        withdrawalTier: {
          label: currentTier.label,
          minimumAmount: {
            pkr: currentTier.minPKR,
            usd: currentTier.minUSD,
          },
          completedWithdrawals,
          withdrawalNumber,
        },
        withdrawalOptions: allTiers,
        flexibleWithdrawal: highestTier
          ? {
              minPKR: highestTier.pkr,
              minUSD: highestTier.usd,
              description: `${highestTier.label} or higher`,
            }
          : null,
        currencyRate: {
          usdToPkr: constants.CURRENCY.USD_TO_PKR_RATE,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting payment methods:', error);
    next(error);
  }
};

/**
 * @desc    Get user's ROI earning history
 * @route   GET /api/v1/wallet/roi-history
 * @access  Private (User)
 */
exports.getROIHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows } = await Earning.findAndCountAll({
      where: { 
        user_id: userId,
        type: 'roi_daily_profit'
      },
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        earnings: rows.map(earning => ({
          id: earning.id,
          amount: parseFloat(earning.amount),
          description: earning.description,
          status: earning.status,
          createdAt: earning.created_at,
        })),
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting ROI history:', error);
    next(error);
  }
};
