const Ad = require('../models/Ad');
const AdImage = require('../models/AdImage');
const Category = require('../models/Category');
const Location = require('../models/Location');
const User = require('../models/User');
const { Op } = require('sequelize');

// @desc    Get all ads
// @route   GET /api/v1/ads
// @access  Public
exports.getAds = async (req, res, next) => {
  try {
    const {
      status,
      category_id,
      location_id,
      user_id,
      is_featured,
      search,
      min_price,
      max_price,
      condition,
    } = req.query;
    
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || parseInt(process.env.DEFAULT_PAGE_SIZE, 10) || 10;
    const offset = (page - 1) * limit;

    const where = {};
    
    // Filters
    if (status) where.status = status;
    if (category_id) where.category_id = category_id;
    if (location_id) where.location_id = location_id;
    if (user_id) where.user_id = user_id;
    if (is_featured !== undefined) where.is_featured = is_featured === 'true';
    if (condition) where.condition = condition;
    
    // Search in title and description
    if (search) {
      where[Op.or] = [
        { title: { [Op.iLike]: `%${search}%` } },
        { description: { [Op.iLike]: `%${search}%` } },
      ];
    }
    
    // Price range
    if (min_price || max_price) {
      where.price = {};
      if (min_price) where.price[Op.gte] = min_price;
      if (max_price) where.price[Op.lte] = max_price;
    }

    const { count, rows: ads } = await Ad.findAndCountAll({
      where,
      limit,
      offset,
      order: [
        ['is_featured', 'DESC'],
        ['created_at', 'DESC'],
      ],
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'avatar'],
        },
        {
          model: Category,
          as: 'category',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: Location,
          as: 'location',
          attributes: ['id', 'name', 'slug', 'type'],
        },
        {
          model: AdImage,
          as: 'images',
          order: [['is_primary', 'DESC'], ['display_order', 'ASC']],
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: ads.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: ads,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single ad
// @route   GET /api/v1/ads/:id
// @access  Public
exports.getAd = async (req, res, next) => {
  try {
    const ad = await Ad.findByPk(req.params.id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone', 'avatar'],
        },
        {
          model: Category,
          as: 'category',
        },
        {
          model: Location,
          as: 'location',
        },
        {
          model: AdImage,
          as: 'images',
          order: [['is_primary', 'DESC'], ['display_order', 'ASC']],
        },
      ],
    });

    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    // Increment view count
    await ad.increment('views_count');

    res.status(200).json({
      success: true,
      data: ad,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create ad
// @route   POST /api/v1/ads
// @access  Private
exports.createAd = async (req, res, next) => {
  try {
    // Validate required fields
    const { title, description, price, category_id, location_id, external_url } = req.body;
    
    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Title is required',
      });
    }
    
    if (!description) {
      return res.status(400).json({
        success: false,
        message: 'Description is required',
      });
    }
    
    if (!price || price <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Valid price is required',
      });
    }
    
    if (!category_id) {
      return res.status(400).json({
        success: false,
        message: 'Category ID is required',
      });
    }
    
    if (!location_id) {
      return res.status(400).json({
        success: false,
        message: 'Location ID is required',
      });
    }
    
    if (!external_url) {
      return res.status(400).json({
        success: false,
        message: 'External URL is required',
      });
    }
    
    // Validate URL format
    try {
      new URL(external_url);
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: 'External URL must be a valid URL',
      });
    }

    // Set user_id from authenticated user
    req.body.user_id = req.user.id;

    // Auto-generate slug from title if not provided
    if (!req.body.slug && req.body.title) {
      let baseSlug = req.body.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '');
      
      // Ensure slug is unique
      let slug = baseSlug;
      let counter = 1;
      let existingAd = await Ad.findOne({ where: { slug } });
      
      while (existingAd) {
        slug = `${baseSlug}-${counter}`;
        existingAd = await Ad.findOne({ where: { slug } });
        counter++;
      }
      
      req.body.slug = slug;
    }

    // Create the ad
    const ad = await Ad.create(req.body);

    // Fetch the complete ad with associations (without images)
    const completeAd = await Ad.findByPk(ad.id, {
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'phone'],
        },
        {
          model: Category,
          as: 'category',
        },
        {
          model: Location,
          as: 'location',
        },
      ],
    });

    res.status(201).json({
      success: true,
      data: completeAd,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update ad
// @route   PUT /api/v1/ads/:id
// @access  Private
exports.updateAd = async (req, res, next) => {
  try {
    const ad = await Ad.findByPk(req.params.id);

    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    // Check ownership (user can only update their own ads, admin can update all)
    if (ad.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this ad',
      });
    }

    await ad.update(req.body);

    // Reload with associations
    await ad.reload({
      include: [
        { model: Category, as: 'category' },
        { model: Location, as: 'location' },
        { model: AdImage, as: 'images' },
      ],
    });

    res.status(200).json({
      success: true,
      data: ad,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete ad
// @route   DELETE /api/v1/ads/:id
// @access  Private
exports.deleteAd = async (req, res, next) => {
  try {
    const ad = await Ad.findByPk(req.params.id);

    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    // Check ownership
    if (ad.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this ad',
      });
    }

    await ad.destroy();

    res.status(200).json({
      success: true,
      message: 'Ad deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Approve ad (Admin only)
// @route   PUT /api/v1/ads/:id/approve
// @access  Private/Admin
exports.approveAd = async (req, res, next) => {
  try {
    const ad = await Ad.findByPk(req.params.id);

    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    await ad.update({ status: 'active' });

    res.status(200).json({
      success: true,
      data: ad,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Reject ad (Admin only)
// @route   PUT /api/v1/ads/:id/reject
// @access  Private/Admin
exports.rejectAd = async (req, res, next) => {
  try {
    const ad = await Ad.findByPk(req.params.id);

    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    await ad.update({
      status: 'rejected',
      rejection_reason: req.body.rejection_reason,
    });

    res.status(200).json({
      success: true,
      data: ad,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Mark ad as featured (Admin only)
// @route   PUT /api/v1/ads/:id/feature
// @access  Private/Admin
exports.featureAd = async (req, res, next) => {
  try {
    const ad = await Ad.findByPk(req.params.id);

    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    const featuredDays = req.body.days || 7;
    const featuredUntil = new Date();
    featuredUntil.setDate(featuredUntil.getDate() + featuredDays);

    await ad.update({
      is_featured: true,
      featured_until: featuredUntil,
    });

    res.status(200).json({
      success: true,
      data: ad,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get ad statistics (Admin only)
// @route   GET /api/v1/ads/stats
// @access  Private/Admin
exports.getAdStats = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');

    const stats = await Ad.findAll({
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['status'],
      raw: true,
    });

    const totalAds = await Ad.count();
    const featuredAds = await Ad.count({ where: { is_featured: true } });
    const activeAds = await Ad.count({ where: { status: 'active' } });
    const pendingAds = await Ad.count({ where: { status: 'pending' } });

    res.status(200).json({
      success: true,
      data: {
        total: totalAds,
        featured: featuredAds,
        active: activeAds,
        pending: pendingAds,
        by_status: stats,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get my ads (current user's ads)
// @route   GET /api/v1/ads/my-ads
// @access  Private
exports.getMyAds = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows: ads } = await Ad.findAndCountAll({
      where: { user_id: req.user.id },
      include: [
        {
          model: Category,
          as: 'category',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: Location,
          as: 'location',
          attributes: ['id', 'name', 'slug'],
        },
        {
          model: AdImage,
          as: 'images',
          attributes: ['id', 'image_url', 'is_primary'],
        },
      ],
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    res.status(200).json({
      success: true,
      count: ads.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: ads,
    });
  } catch (error) {
    next(error);
  }
};

