const { User, Ad, AdView, Earning } = require('../models');
const { AD_WATCHING } = require('../config/constants');
const commissionService = require('../utils/commissionService');
const { hasApprovedDeposit } = require('../utils/depositGuard');
const { sequelize } = require('../config/database');
const logger = require('../config/logger');

/**
 * @desc    Watch an ad
 * @route   POST /api/ad-views/:adId/watch
 * @access  Private (User)
 */
exports.watchAd = async (req, res, next) => {
  try {
    const { adId } = req.params;
    const userId = req.user.id;

    // Get user with current ad watching status
    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Require at least one approved deposit before awarding ad-watching earnings
    const depositApproved = await hasApprovedDeposit(userId);
    if (!depositApproved) {
      return res.status(403).json({
        success: false,
        code: 'DEPOSIT_REQUIRED',
        message: 'You must have at least one approved deposit to earn from ad watching',
        help: 'Submit a deposit and wait for admin approval, then try again.'
      });
    }

    // Get adType from request body (normalize: trim whitespace, lowercase)
    // Defaults to 'first' if not provided
    const requestedAdType = req.body.adType 
      ? String(req.body.adType).trim().toLowerCase() 
      : 'first';

    // Log for debugging (remove in production if needed)
    logger.info(`User ${userId} watching ad ${adId}, requestedAdType: "${requestedAdType}", body.adType: "${req.body.adType}"`);

    // If requesting second ad, validate second ad eligibility only
    // Skip first-ad cooldown check for second ads
    if (requestedAdType === 'second') {
      // FIXED: Reset counters based on 24-hour rule (not calendar day)
      // This gives users 24 hours from last direct join to watch second ads
      await user.resetDailyCounters();
      
      // Check eligibility based on current state (after reset)
      const directJoinsToday = user.today_direct_joins || 0;
      const secondAdViewsToday = user.today_second_ad_views || 0;
      
      const remainingViews = directJoinsToday - secondAdViewsToday;
      
      if (directJoinsToday === 0) {
        return res.status(403).json({
          success: false,
          message: 'You need to add a direct member to unlock the second ad. You have 24 hours from when you add a member to watch second ads.',
          reason: 'no_direct_joins',
          code: 'SECOND_AD_NOT_ELIGIBLE',
          data: {
            canWatch: false,
            directJoinsToday: 0,
            secondAdViewsToday: 0,
            remainingViews: 0
          },
        });
      }
      
      if (remainingViews <= 0) {
        return res.status(403).json({
          success: false,
          message: `You have used all your second ad views for this period (${directJoinsToday} views). You have 24 hours from when you add a member to watch second ads.`,
          reason: 'daily_limit_reached',
          code: 'SECOND_AD_NOT_ELIGIBLE',
          data: {
            canWatch: false,
            directJoinsToday,
            secondAdViewsToday,
            remainingViews: 0
          },
        });
      }
      
      logger.info(`Second ad eligible for user ${userId}: ${remainingViews} views remaining`);
    } else {
      // For first ads, check first-ad eligibility (24-hour cooldown, 7-day cycle)
      // Also reset daily counters for consistency
      await user.resetDailyCounters();
      
      // FIXED: canWatchAd is now async and can reset cycle automatically
      const eligibility = await user.canWatchAd();

      if (!eligibility.canWatch) {
        return res.status(403).json({
          success: false,
          message: eligibility.message,
          reason: eligibility.reason,
          code: 'FIRST_AD_NOT_ELIGIBLE',
          data: eligibility,
        });
      }
    }

    // Check if ad exists
    const ad = await Ad.findByPk(adId);

    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    // Users cannot watch their own ads
    if (ad.user_id === userId) {
      return res.status(400).json({
        success: false,
        message: 'You cannot watch your own ad',
      });
    }

    const now = new Date();
    let earningAmount = 0;
    let adType = requestedAdType;
    let numberOfAdsPaid = 1; // Track how many second ads were paid for

    // FIXED: Use transaction like spinner to ensure atomic wallet balance update
    // This prevents wallet balance loss and ensures earnings are always added
    await sequelize.transaction(async (t) => {
      // Reload user within transaction to get latest wallet balance
      const currentUser = await User.findByPk(userId, { transaction: t });
      if (!currentUser) {
        throw new Error('User not found');
      }

      // Get current values
      const directJoinsToday = currentUser.today_direct_joins || 0;
      const secondAdViewsToday = currentUser.today_second_ad_views || 0;
      const currentWalletBalance = parseFloat(currentUser.wallet_balance || 0);
      const currentTotalEarnings = parseFloat(currentUser.total_earnings || 0);

      // Prepare wallet update fields
      const updateFields = {};

      if (requestedAdType === 'second') {
        // Calculate remaining second ads available
        const remainingViews = directJoinsToday - secondAdViewsToday;
        
        // NEW: User watches once and gets paid for ALL remaining second ads
        // If user has 7 second ads, they watch once and get 7 * 22 = 154 PKR
        numberOfAdsPaid = remainingViews > 0 ? remainingViews : 1;
        earningAmount = AD_WATCHING.SECOND_AD_EARNING * numberOfAdsPaid;
        
        // Mark ALL remaining second ads as used (set to directJoinsToday)
        updateFields.today_second_ad_views = directJoinsToday;
        
        // Create earning record for the viewer (within transaction)
        // Record shows total amount earned for all second ads
        await Earning.create({
          user_id: userId,
          amount: earningAmount,
          type: 'ad_watching',
          description: `Earning from watching ${numberOfAdsPaid} second ad(s)`,
          status: 'completed',
          metadata: JSON.stringify({
            ad_id: adId,
            ad_type: 'second',
            earning_amount: earningAmount,
            number_of_ads: numberOfAdsPaid,
            per_ad_amount: AD_WATCHING.SECOND_AD_EARNING
          })
        }, { transaction: t });

        // Add wallet balance to update fields
        updateFields.wallet_balance = currentWalletBalance + earningAmount;
        updateFields.total_earnings = currentTotalEarnings + earningAmount;

        // Distribute commission to upline for ALL second ads
        // If user has 7 second ads, distribute commission 7 times (7 * 30 = 210 PKR pool)
        const totalCommissionPool = AD_WATCHING.SECOND_AD_COMMISSION_POOL * numberOfAdsPaid;
        try {
          // Distribute commission multiple times (once for each second ad)
          // This ensures each second ad's commission is distributed properly
          let totalCommissionDistributed = 0;
          let totalRecipients = 0;
          
          for (let i = 0; i < numberOfAdsPaid; i++) {
            const commissionResult = await commissionService.distributeAdWatchingCommission(
              userId,
              AD_WATCHING.SECOND_AD_COMMISSION_POOL,
              'fixed'
            );
            totalCommissionDistributed += commissionResult.totalDistributed || 0;
            totalRecipients = Math.max(totalRecipients, commissionResult.recipients || 0);
          }
          
          logger.info(`Commission distributed for ${numberOfAdsPaid} second ad(s): ${totalCommissionDistributed} PKR total to ${totalRecipients} users`);
        } catch (commissionError) {
          logger.error('Error distributing second ad commission:', commissionError);
          // Don't fail the main operation if commission distribution fails
        }

        // Note: For second ads, we do NOT update last_ad_watched_at
        // because second ads don't have a 24-hour cooldown
        // They're based on daily direct joins instead
      } else {
        // This is a first ad - user gets 5 PKR
        earningAmount = AD_WATCHING.FIRST_AD_EARNING;
        
        // Create earning record for the viewer (within transaction)
        await Earning.create({
          user_id: userId,
          amount: earningAmount,
          type: 'ad_watching',
          description: 'Earning from watching first ad',
          status: 'completed',
          metadata: JSON.stringify({
            ad_id: adId,
            ad_type: 'first',
            earning_amount: earningAmount
          })
        }, { transaction: t });

        // Add wallet balance to update fields
        updateFields.wallet_balance = currentWalletBalance + earningAmount;
        updateFields.total_earnings = currentTotalEarnings + earningAmount;

        // Update user's last ad watched time (for 24-hour cooldown)
        updateFields.last_ad_watched_at = now;
      }

      // If this is the first time watching, set the cycle start date
      if (!currentUser.current_cycle_started_at) {
        updateFields.current_cycle_started_at = now;
      }

      // FIXED: Update user in SINGLE operation within transaction (like spinner)
      await currentUser.update(updateFields, { transaction: t });
    });

    // Reload user after transaction to get updated wallet balance for response
    await user.reload();
    
    // Get second ad status for response
    const secondAdStatus = user.canWatchSecondAd();

    // Create ad view record
    await AdView.create({
      user_id: userId,
      ad_id: adId,
      watched_at: now,
    });

    // Increment ad views count
    await ad.increment('views_count');

    // Update log message for second ads to show number of ads paid
    if (adType === 'second' && numberOfAdsPaid > 1) {
      logger.info(`User ${userId} watched ${adType} ad ${adId} once and earned ${earningAmount} PKR for ${numberOfAdsPaid} second ad(s)`);
    } else {
      logger.info(`User ${userId} watched ${adType} ad ${adId} and earned ${earningAmount} PKR`);
    }

    // FIXED: getAdWatchingStatus is now async
    const adWatchingStatus = await user.getAdWatchingStatus();

    // Prepare response message
    let successMessage = 'Ad watched successfully';
    if (adType === 'second' && numberOfAdsPaid > 1) {
      successMessage = `Second ad watched successfully! You earned ${earningAmount} PKR for ${numberOfAdsPaid} second ad(s).`;
    }

    res.status(200).json({
      success: true,
      message: successMessage,
      data: {
        adId,
        adType,
        earningAmount,
        numberOfAdsPaid: adType === 'second' ? numberOfAdsPaid : 1,
        watchedAt: now,
        nextAdAvailableAt: new Date(now.getTime() + 24 * 60 * 60 * 1000),
        adWatchingStatus: adWatchingStatus,
        secondAdStatus: secondAdStatus,
      },
    });
  } catch (error) {
    logger.error('Error watching ad:', error);
    next(error);
  }
};

/**
 * @desc    Get user's ad watching status
 * @route   GET /api/ad-views/status
 * @access  Private (User)
 */
exports.getAdWatchingStatus = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const user = await User.findByPk(userId, {
      include: [
        {
          model: User,
          as: 'referrals',
          attributes: ['id', 'name', 'email', 'created_at'],
        },
      ],
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // FIXED: getAdWatchingStatus is now async
    const status = await user.getAdWatchingStatus();

    res.status(200).json({
      success: true,
      data: {
        ...status,
        referrals: user.referrals || [],
      },
    });
  } catch (error) {
    logger.error('Error getting ad watching status:', error);
    next(error);
  }
};

/**
 * @desc    Get user's ad watching history
 * @route   GET /api/ad-views/history
 * @access  Private (User)
 */
exports.getAdWatchingHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows } = await AdView.findAndCountAll({
      where: { user_id: userId },
      include: [
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug', 'price', 'status'],
          include: [
            {
              model: User,
              as: 'user',
              attributes: ['id', 'name', 'email'],
            },
          ],
        },
      ],
      order: [['watched_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        history: rows,
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting ad watching history:', error);
    next(error);
  }
};

/**
 * @desc    Add a new member (referral)
 * @route   POST /api/ad-views/add-member
 * @access  Private (User)
 */
exports.addMember = async (req, res, next) => {
  try {
    const { referralCode } = req.body;
    const userId = req.user.id;

    if (!referralCode) {
      return res.status(400).json({
        success: false,
        message: 'Referral code is required',
      });
    }

    // Find the user who was referred
    const referredUser = await User.findOne({
      where: { referral_code: referralCode },
    });

    if (!referredUser) {
      return res.status(404).json({
        success: false,
        message: 'Invalid referral code',
      });
    }

    // Check if the referred user is already associated with someone
    if (referredUser.referred_by) {
      return res.status(400).json({
        success: false,
        message: 'This user has already been referred by someone else',
      });
    }

    // Users cannot refer themselves
    if (referredUser.id === userId) {
      return res.status(400).json({
        success: false,
        message: 'You cannot use your own referral code',
      });
    }

    // Update the referred user
    referredUser.referred_by = userId;
    await referredUser.save();

    // Update the referrer's total referrals and reset their cycle
    const referrer = await User.findByPk(userId);
    referrer.total_referrals += 1;
    referrer.current_cycle_started_at = new Date(); // Reset the 7-day cycle
    
    // Increment daily direct joins for the referrer
    await referrer.incrementDailyDirectJoins();
    
    await referrer.save();

    logger.info(`User ${userId} added member with referral code ${referralCode}`);

    res.status(200).json({
      success: true,
      message: 'Member added successfully! Your 7-day cycle has been reset.',
      data: {
        totalReferrals: referrer.total_referrals,
        newCycleStartDate: referrer.current_cycle_started_at,
        adWatchingStatus: await referrer.getAdWatchingStatus(),
      },
    });
  } catch (error) {
    logger.error('Error adding member:', error);
    next(error);
  }
};

/**
 * @desc    Get user's referral information
 * @route   GET /api/ad-views/referral-info
 * @access  Private (User)
 */
exports.getReferralInfo = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const user = await User.findByPk(userId, {
      include: [
        {
          model: User,
          as: 'referrals',
          attributes: ['id', 'name', 'email', 'createdAt'],
        },
        {
          model: User,
          as: 'referrer',
          attributes: ['id', 'name', 'email'],
        },
      ],
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.status(200).json({
      success: true,
      data: {
        referralCode: user.referral_code,
        totalReferrals: user.total_referrals,
        referrals: user.referrals || [],
        referredBy: user.referrer || null,
      },
    });
  } catch (error) {
    logger.error('Error getting referral info:', error);
    next(error);
  }
};

/**
 * @desc    Get second ad status
 * @route   GET /api/ad-views/second-ad-status
 * @access  Private (User)
 */
exports.getSecondAdStatus = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // Reset daily counters and get second ad status
    await user.resetDailyCounters();
    const secondAdStatus = user.canWatchSecondAd();

    res.status(200).json({
      success: true,
      data: {
        ...secondAdStatus,
        adWatchingStatus: await user.getAdWatchingStatus(),
      },
    });
  } catch (error) {
    logger.error('Error getting second ad status:', error);
    next(error);
  }
};

