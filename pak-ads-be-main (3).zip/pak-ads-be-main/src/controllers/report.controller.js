const Report = require('../models/Report');
const User = require('../models/User');
const Ad = require('../models/Ad');
const { Op } = require('sequelize');

// @desc    Get all reports
// @route   GET /api/v1/reports
// @access  Private/Admin
exports.getReports = async (req, res, next) => {
  try {
    const { status, reason, ad_id } = req.query;
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    const offset = (page - 1) * limit;

    const where = {};
    if (status) where.status = status;
    if (reason) where.reason = reason;
    if (ad_id) where.ad_id = ad_id;

    const { count, rows: reports } = await Report.findAndCountAll({
      where,
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug', 'status'],
        },
        {
          model: User,
          as: 'reporter',
          attributes: ['id', 'name', 'email'],
        },
        {
          model: User,
          as: 'reviewer',
          attributes: ['id', 'name'],
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: reports.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: reports,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single report
// @route   GET /api/v1/reports/:id
// @access  Private/Admin
exports.getReport = async (req, res, next) => {
  try {
    const report = await Report.findByPk(req.params.id, {
      include: [
        {
          model: Ad,
          as: 'ad',
          include: [
            {
              model: User,
              as: 'user',
              attributes: ['id', 'name', 'email'],
            },
          ],
        },
        {
          model: User,
          as: 'reporter',
          attributes: ['id', 'name', 'email'],
        },
        {
          model: User,
          as: 'reviewer',
          attributes: ['id', 'name'],
        },
      ],
    });

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Report not found',
      });
    }

    res.status(200).json({
      success: true,
      data: report,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create report
// @route   POST /api/v1/reports
// @access  Private
exports.createReport = async (req, res, next) => {
  try {
    req.body.reporter_id = req.user.id;

    // Check if user already reported this ad
    const existingReport = await Report.findOne({
      where: {
        ad_id: req.body.ad_id,
        reporter_id: req.user.id,
      },
    });

    if (existingReport) {
      return res.status(400).json({
        success: false,
        message: 'You have already reported this ad',
      });
    }

    const report = await Report.create(req.body);

    // Fetch complete report
    const completeReport = await Report.findByPk(report.id, {
      include: [
        {
          model: Ad,
          as: 'ad',
          attributes: ['id', 'title', 'slug'],
        },
      ],
    });

    res.status(201).json({
      success: true,
      data: completeReport,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update report status (Admin only)
// @route   PUT /api/v1/reports/:id/status
// @access  Private/Admin
exports.updateReportStatus = async (req, res, next) => {
  try {
    const report = await Report.findByPk(req.params.id);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Report not found',
      });
    }

    await report.update({
      status: req.body.status,
      admin_notes: req.body.admin_notes,
      reviewed_by: req.user.id,
      reviewed_at: new Date(),
    });

    res.status(200).json({
      success: true,
      data: report,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete report
// @route   DELETE /api/v1/reports/:id
// @access  Private/Admin
exports.deleteReport = async (req, res, next) => {
  try {
    const report = await Report.findByPk(req.params.id);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Report not found',
      });
    }

    await report.destroy();

    res.status(200).json({
      success: true,
      message: 'Report deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get report statistics (Admin only)
// @route   GET /api/v1/reports/stats
// @access  Private/Admin
exports.getReportStats = async (req, res, next) => {
  try {
    const { sequelize } = require('../config/database');

    const stats = await Report.findAll({
      attributes: [
        'status',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['status'],
      raw: true,
    });

    const reasonStats = await Report.findAll({
      attributes: [
        'reason',
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['reason'],
      raw: true,
    });

    const totalReports = await Report.count();
    const pendingReports = await Report.count({ where: { status: 'pending' } });

    res.status(200).json({
      success: true,
      data: {
        total: totalReports,
        pending: pendingReports,
        by_status: stats,
        by_reason: reasonStats,
      },
    });
  } catch (error) {
    next(error);
  }
};

