const Favorite = require('../models/Favorite');
const Ad = require('../models/Ad');
const User = require('../models/User');
const Category = require('../models/Category');
const Location = require('../models/Location');
const AdImage = require('../models/AdImage');

// @desc    Get user's favorite ads
// @route   GET /api/v1/favorites
// @access  Private
exports.getFavorites = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || parseInt(process.env.DEFAULT_PAGE_SIZE, 10) || 10;
    const offset = (page - 1) * limit;

    const { count, rows: favorites } = await Favorite.findAndCountAll({
      where: { user_id: req.user.id },
      limit,
      offset,
      order: [['created_at', 'DESC']],
      include: [
        {
          model: Ad,
          as: 'ad',
          include: [
            {
              model: User,
              as: 'user',
              attributes: ['id', 'name', 'email', 'phone', 'avatar'],
            },
            {
              model: Category,
              as: 'category',
              attributes: ['id', 'name', 'slug'],
            },
            {
              model: Location,
              as: 'location',
              attributes: ['id', 'name', 'slug'],
            },
            {
              model: AdImage,
              as: 'images',
              limit: 1,
              where: { is_primary: true },
              required: false,
            },
          ],
        },
      ],
    });

    res.status(200).json({
      success: true,
      count: favorites.length,
      total: count,
      page,
      pages: Math.ceil(count / limit),
      data: favorites,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Add ad to favorites
// @route   POST /api/v1/favorites/:adId
// @access  Private
exports.addFavorite = async (req, res, next) => {
  try {
    const { adId } = req.params;

    // Check if ad exists
    const ad = await Ad.findByPk(adId);
    if (!ad) {
      return res.status(404).json({
        success: false,
        message: 'Ad not found',
      });
    }

    // Check if already favorited
    const existing = await Favorite.findOne({
      where: {
        user_id: req.user.id,
        ad_id: adId,
      },
    });

    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'Ad already in favorites',
      });
    }

    const favorite = await Favorite.create({
      user_id: req.user.id,
      ad_id: adId,
    });

    // Increment favorites count on ad
    await ad.increment('favorites_count');

    res.status(201).json({
      success: true,
      data: favorite,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Remove ad from favorites
// @route   DELETE /api/v1/favorites/:adId
// @access  Private
exports.removeFavorite = async (req, res, next) => {
  try {
    const { adId } = req.params;

    const favorite = await Favorite.findOne({
      where: {
        user_id: req.user.id,
        ad_id: adId,
      },
    });

    if (!favorite) {
      return res.status(404).json({
        success: false,
        message: 'Favorite not found',
      });
    }

    await favorite.destroy();

    // Decrement favorites count on ad
    const ad = await Ad.findByPk(adId);
    if (ad && ad.favorites_count > 0) {
      await ad.decrement('favorites_count');
    }

    res.status(200).json({
      success: true,
      message: 'Removed from favorites',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Check if ad is favorited
// @route   GET /api/v1/favorites/check/:adId
// @access  Private
exports.checkFavorite = async (req, res, next) => {
  try {
    const { adId } = req.params;

    const favorite = await Favorite.findOne({
      where: {
        user_id: req.user.id,
        ad_id: adId,
      },
    });

    res.status(200).json({
      success: true,
      is_favorited: !!favorite,
    });
  } catch (error) {
    next(error);
  }
};
