const { Notice } = require('../models');
const { Op } = require('sequelize');
const logger = require('../config/logger');

/**
 * @desc    Get all notices (Admin only)
 * @route   GET /api/v1/notices
 * @access  Private/Admin
 */
exports.getAllNotices = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 20;
    const offset = (page - 1) * limit;
    const status = req.query.status; // active, inactive
    const search = req.query.search;

    // Build where clause
    const whereClause = {};

    if (status) {
      whereClause.status = status;
    }

    if (search) {
      whereClause[Op.or] = [
        { title: { [Op.iLike]: `%${search}%` } },
        { content: { [Op.iLike]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Notice.findAndCountAll({
      where: whereClause,
      order: [['created_at', 'DESC']],
      limit,
      offset,
    });

    const totalPages = Math.ceil(count / limit);

    res.status(200).json({
      success: true,
      data: {
        notices: rows,
        pagination: {
          currentPage: page,
          totalPages,
          totalRecords: count,
          limit,
        },
      },
    });
  } catch (error) {
    logger.error('Error getting all notices:', error);
    next(error);
  }
};

/**
 * @desc    Get single notice
 * @route   GET /api/v1/notices/:id
 * @access  Public
 */
exports.getNoticeById = async (req, res, next) => {
  try {
    const notice = await Notice.findByPk(req.params.id);

    if (!notice) {
      return res.status(404).json({
        success: false,
        message: 'Notice not found',
      });
    }

    res.status(200).json({
      success: true,
      data: notice,
    });
  } catch (error) {
    logger.error('Error getting notice by ID:', error);
    next(error);
  }
};

/**
 * @desc    Create new notice (Admin only)
 * @route   POST /api/v1/notices
 * @access  Private/Admin
 */
exports.createNotice = async (req, res, next) => {
  try {
    const { title, content, type, priority, status, expiresAt } = req.body;

    if (!title || !content) {
      return res.status(400).json({
        success: false,
        message: 'Title and content are required',
      });
    }

    const notice = await Notice.create({
      title,
      content,
      type: type || 'general',
      priority: priority || 'normal',
      status: status || 'active',
      expiresAt: expiresAt ? new Date(expiresAt) : null,
      createdBy: req.user.id,
    });

    res.status(201).json({
      success: true,
      message: 'Notice created successfully',
      data: notice,
    });
  } catch (error) {
    logger.error('Error creating notice:', error);
    next(error);
  }
};

/**
 * @desc    Update notice (Admin only)
 * @route   PUT /api/v1/notices/:id
 * @access  Private/Admin
 */
exports.updateNotice = async (req, res, next) => {
  try {
    const notice = await Notice.findByPk(req.params.id);

    if (!notice) {
      return res.status(404).json({
        success: false,
        message: 'Notice not found',
      });
    }

    const { title, content, type, priority, status, expiresAt } = req.body;

    await notice.update({
      title: title || notice.title,
      content: content || notice.content,
      type: type || notice.type,
      priority: priority || notice.priority,
      status: status || notice.status,
      expiresAt: expiresAt ? new Date(expiresAt) : notice.expiresAt,
      updatedBy: req.user.id,
    });

    res.status(200).json({
      success: true,
      message: 'Notice updated successfully',
      data: notice,
    });
  } catch (error) {
    logger.error('Error updating notice:', error);
    next(error);
  }
};

/**
 * @desc    Delete notice (Admin only)
 * @route   DELETE /api/v1/notices/:id
 * @access  Private/Admin
 */
exports.deleteNotice = async (req, res, next) => {
  try {
    const notice = await Notice.findByPk(req.params.id);

    if (!notice) {
      return res.status(404).json({
        success: false,
        message: 'Notice not found',
      });
    }

    await notice.destroy();

    res.status(200).json({
      success: true,
      message: 'Notice deleted successfully',
    });
  } catch (error) {
    logger.error('Error deleting notice:', error);
    next(error);
  }
};

/**
 * @desc    Get active notices (Public)
 * @route   GET /api/v1/notices/active
 * @access  Public
 */
exports.getActiveNotices = async (req, res, next) => {
  try {
    const limit = parseInt(req.query.limit, 10) || 10;
    const type = req.query.type;

    const whereClause = {
      status: 'active',
    };

    if (type) {
      whereClause.type = type;
    }

    // Add expiry check
    whereClause[Op.or] = [
      { expiresAt: null },
      { expiresAt: { [Op.gt]: new Date() } },
    ];

    const notices = await Notice.findAll({
      where: whereClause,
      order: [
        ['priority', 'DESC'],
        ['created_at', 'DESC'],
      ],
      limit,
    });

    res.status(200).json({
      success: true,
      data: notices,
    });
  } catch (error) {
    logger.error('Error getting active notices:', error);
    next(error);
  }
};

