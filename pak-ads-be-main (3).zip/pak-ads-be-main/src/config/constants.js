/**
 * Application Constants
 * This file contains all the constant values used across the application
 */

module.exports = {
  // Currency Configuration
  CURRENCY: {
    USD_TO_PKR_RATE: 283, // 1 USD = 283 PKR (fixed rate)
    
    // Joining Fee
    JOINING_FEE_USD: 2.30, // Joining fee in USD
    JOINING_FEE_PKR: 650,  // Joining fee in PKR (fixed at 650)
    
    // Withdrawal limits
    // Users can request withdrawals for any of these USD amounts at any time:
    // $0.50 (141 PKR), $1 (283 PKR), $2 (566 PKR), or $4+ (1132 PKR minimum, no upper cap)
    WITHDRAWAL_TIERS: [
      { withdrawalNumber: 1, minUSD: 0.50, minPKR: 141 },
      { withdrawalNumber: 2, minUSD: 1, minPKR: 283 },
      { withdrawalNumber: 3, minUSD: 2, minPKR: 566 },
      { withdrawalNumber: 4, minUSD: 4, minPKR: 1132 }, // 4th withdrawal and beyond
    ],
    // Legacy fields for backward compatibility (using 3rd tier as default)
    MIN_WITHDRAWAL_USD: 1,
    MIN_WITHDRAWAL_PKR: 283,
  },

  // Available Payment Methods for Withdrawal
  PAYMENT_METHODS: [
    { id: 1, name: 'Easypaisa', slug: 'easypaisa', active: true },
    { id: 2, name: 'Jazzcash', slug: 'jazzcash', active: true },
    { id: 3, name: 'Upaisa', slug: 'upaisa', active: true },
    { id: 4, name: 'Rast payment', slug: 'rast_payment', active: true },
    { id: 5, name: 'Sada pay', slug: 'sada_pay', active: true },
    { id: 6, name: 'Naya pay', slug: 'naya_pay', active: true },
    { id: 7, name: 'First pay', slug: 'first_pay', active: true },
    { id: 8, name: 'Alfa pay', slug: 'alfa_pay', active: true },
    { id: 9, name: 'Pay max', slug: 'pay_max', active: true },
  ],

  // Daily Referral Bonus System
  DAILY_REFERRAL_BONUS: {
    FIRST_BONUS_THRESHOLD: 3,        // First bonus after 3 referrals
    SUBSEQUENT_BONUS_THRESHOLD: 3,   // Additional bonuses every 3 referrals
    MAX_REFERRALS_FOR_BONUS: 8,      // Maximum referrals counted for bonus (cap at 8)
    BONUS_AMOUNT_USD: 1,             // $1 per bonus
    BONUS_AMOUNT_PKR: 283,           // 283 PKR per bonus (1 USD)
  },

  // Rank-Based Reward System
  RANK_REWARDS: {
    1: { members: 15, rewardUSD: 2, rewardPKR: 566, name: 'Rank 1' },
    2: { members: 35, rewardUSD: 4, rewardPKR: 1132, name: 'Rank 2' },
    3: { members: 75, rewardUSD: 6, rewardPKR: 1698, name: 'Rank 3' },
    4: { members: 150, rewardUSD: 15, rewardPKR: 4245, name: 'Rank 4' },
    5: { members: 300, rewardUSD: 25, rewardPKR: 7075, name: 'Rank 5' },
    6: { members: 500, rewardUSD: 35, rewardPKR: 9905, name: 'Rank 6' },
    7: { members: 800, rewardUSD: 45, rewardPKR: 12735, name: 'Rank 7' },
  },

  // Deposit Reward System
  DEPOSIT_REWARD: {
    REFERRAL_THRESHOLD: 15,        // Required referrals after deposit
    REWARD_AMOUNT_USD: 2,          // $2 per reward
    REWARD_AMOUNT_PKR: 566,        // 566 PKR per reward (2 USD)
  },

  // Generation-Based Multi-Level Commission System
  // Distribution across 7 levels based on 345 PKR base amount (53% of 650 PKR joining fee)
  // Total commission distributed: 345 PKR (53% of joining fee)
  COMMISSION_LEVELS: {
    1: { amount: 175, ratio: 0.618, percentage: 61.8 },  // Level 1 - Direct referral
    2: { amount: 60, ratio: 0.212, percentage: 21.2 },   // Level 2
    3: { amount: 40, ratio: 0.141, percentage: 14.1 },   // Level 3
    4: { amount: 30, ratio: 0.106, percentage: 10.6 },   // Level 4
    5: { amount: 20, ratio: 0.071, percentage: 7.1 },    // Level 5
    6: { amount: 10, ratio: 0.035, percentage: 3.5 },    // Level 6
    7: { amount: 10, ratio: 0.035, percentage: 3.5 },    // Level 7
  },

  // Ad Watching Earnings
  AD_WATCHING: {
    FIRST_AD_EARNING: 5,    // 5 PKR for first ad watch
    SECOND_AD_EARNING: 22,  // 22 PKR for second ad watch (watcher gets this)
    SECOND_AD_COMMISSION_POOL: 30, // 30 PKR pool for upline commission (9+7+5+4+3+2 = 30, watcher gets 22 separately)
  },

  // Ad Watching Commission Distribution
  // IMPORTANT: Level numbering in this config:
  // - Level 1 = 22 PKR (watcher gets this directly, NOT as commission)
  // - Level 2 = 9 PKR (watcher's referrer gets this)
  // - Level 3 = 7 PKR (Level 2's referrer)
  // - Level 4 = 5 PKR
  // - Level 5 = 4 PKR
  // - Level 6 = 3 PKR
  // - Level 7 = 2 PKR
  // Commission distribution uses level+1 mapping (upline level 1 → commission level 2)
  AD_WATCHING_COMMISSION_LEVELS: {
    1: { amount: 22, ratio: 0.423, percentage: 42.3 },   // Level 1: 22 PKR (watcher gets this directly)
    2: { amount: 9, ratio: 0.173, percentage: 17.3 },    // Level 2: 9 PKR (watcher's referrer)
    3: { amount: 7, ratio: 0.135, percentage: 13.5 },    // Level 3: 7 PKR
    4: { amount: 5, ratio: 0.096, percentage: 9.6 },     // Level 4: 5 PKR
    5: { amount: 4, ratio: 0.077, percentage: 7.7 },     // Level 5: 4 PKR
    6: { amount: 3, ratio: 0.058, percentage: 5.8 },     // Level 6: 3 PKR
    7: { amount: 2, ratio: 0.038, percentage: 3.8 },     // Level 7: 2 PKR
  },

  // Total commission pool configuration
  COMMISSION_CONFIG: {
    BASE_AMOUNT: 345,      // Base amount in PKR for commission calculation (53% of 650)
    TOTAL_LEVELS: 7,       // Maximum levels for commission distribution
    TOTAL_DISTRIBUTED: 345, // Total amount distributed (175+60+40+30+20+10+10)
  },

  // Helper function to convert USD to PKR
  convertUsdToPkr: (usdAmount) => {
    return parseFloat((usdAmount * module.exports.CURRENCY.USD_TO_PKR_RATE).toFixed(2));
  },

  // Helper function to convert PKR to USD
  convertPkrToUsd: (pkrAmount) => {
    return parseFloat((pkrAmount / module.exports.CURRENCY.USD_TO_PKR_RATE).toFixed(2));
  },
};

