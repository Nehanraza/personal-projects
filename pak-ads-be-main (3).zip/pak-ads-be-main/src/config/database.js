const { Sequelize } = require('sequelize');
const pg = require('pg');
require('dotenv').config();

const { Sequelize } = require('sequelize');
const pg = require('pg');
require('dotenv').config();

const dbUrl =
  process.env.DATABASE_URL ||
  `postgres://${process.env.DB_USERNAME}:${process.env.DB_PASSWORD}@${process.env.DB_HOST}:${process.env.DB_PORT}/${process.env.DB_DATABASE}`;

const sequelize = new Sequelize(dbUrl, {
  dialect: 'postgres',
  dialectModule: pg,

  logging: false,
  timezone: '+05:00',

  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false,
    },
    keepAlive: true,
  },

pool: {
  max: 30,
  min: 5,
  acquire: 60000,
  idle: 10000,
},  retry: {
    max: 5,
  },
});

const connectDB = async () => {
  try {
    await sequelize.authenticate();
    console.log('✓ PostgreSQL Connected');
  } catch (error) {
    console.error('✗ DB connection failed:', error.message);
    throw error;
  }
};

module.exports = { sequelize, connectDB };