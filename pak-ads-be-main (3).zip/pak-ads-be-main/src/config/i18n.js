const i18next = require('i18next');
const middleware = require('i18next-http-middleware');
const fs = require('fs');
const path = require('path');

const en = JSON.parse(fs.readFileSync(path.join(__dirname, '../locales/en.json'), 'utf8'));
const ur = JSON.parse(fs.readFileSync(path.join(__dirname, '../locales/ur.json'), 'utf8'));

i18next
  .use(middleware.LanguageDetector)
  .init({
    fallbackLng: 'en',
    resources: {
      en: { translation: en },
      ur: { translation: ur },
    },
    detection: {
      order: ['header', 'querystring', 'cookie'],
      caches: false,
    },
  });

module.exports = i18next;
