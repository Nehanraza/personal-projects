/**
 * OTP Generation Utility
 * Generates secure 6-digit OTP codes
 */

const crypto = require('crypto');

/**
 * Generate a 6-digit OTP
 * @returns {string} 6-digit OTP
 */
const generateOTP = () => {
  // Generate random 6-digit number
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  return otp;
};

/**
 * Generate OTP with expiry time
 * @param {number} expiryMinutes - Minutes until OTP expires (default: 10)
 * @returns {object} { otp, expiry }
 */
const generateOTPWithExpiry = (expiryMinutes = 10) => {
  const otp = generateOTP();
  const expiry = new Date(Date.now() + expiryMinutes * 60 * 1000);
  
  return {
    otp,
    expiry,
  };
};

/**
 * Generate secure token for password reset (alternative to OTP)
 * @returns {string} Secure token
 */
const generateResetToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

/**
 * Hash token for storage
 * @param {string} token - Token to hash
 * @returns {string} Hashed token
 */
const hashToken = (token) => {
  return crypto.createHash('sha256').update(token).digest('hex');
};

module.exports = {
  generateOTP,
  generateOTPWithExpiry,
  generateResetToken,
  hashToken,
};

