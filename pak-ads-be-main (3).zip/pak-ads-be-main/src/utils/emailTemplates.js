/**
 * Email Templates
 * HTML templates for various email types
 */

/**
 * Email verification OTP template
 */
const emailVerificationTemplate = (name, otp) => {
  return {
    subject: 'Verify Your Email - Pak Ads',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #4CAF50; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
          .otp-box { background: white; border: 2px dashed #4CAF50; padding: 20px; text-align: center; margin: 20px 0; border-radius: 5px; }
          .otp-code { font-size: 32px; font-weight: bold; color: #4CAF50; letter-spacing: 5px; }
          .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
          .warning { color: #f44336; font-size: 14px; margin-top: 15px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Email Verification</h1>
          </div>
          <div class="content">
            <h2>Hello ${name}!</h2>
            <p>Thank you for registering with Pak Ads. To complete your registration, please verify your email address.</p>
            
            <div class="otp-box">
              <p style="margin: 0; font-size: 14px; color: #666;">Your verification code is:</p>
              <div class="otp-code">${otp}</div>
            </div>
            
            <p>Enter this code in the app to verify your email address.</p>
            <p class="warning">⚠️ This code will expire in 10 minutes.</p>
            <p>If you didn't create an account with Pak Ads, please ignore this email.</p>
          </div>
          <div class="footer">
            <p>© 2025 Pak Ads. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: `
Hello ${name}!

Thank you for registering with Pak Ads.

Your email verification code is: ${otp}

This code will expire in 10 minutes.

If you didn't create an account with Pak Ads, please ignore this email.

© 2025 Pak Ads. All rights reserved.
    `,
  };
};

/**
 * Password reset OTP template
 */
const passwordResetTemplate = (name, otp) => {
  return {
    subject: 'Reset Your Password - Pak Ads',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #FF9800; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
          .otp-box { background: white; border: 2px dashed #FF9800; padding: 20px; text-align: center; margin: 20px 0; border-radius: 5px; }
          .otp-code { font-size: 32px; font-weight: bold; color: #FF9800; letter-spacing: 5px; }
          .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
          .warning { color: #f44336; font-size: 14px; margin-top: 15px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Password Reset Request</h1>
          </div>
          <div class="content">
            <h2>Hello ${name}!</h2>
            <p>We received a request to reset your password for your Pak Ads account.</p>
            
            <div class="otp-box">
              <p style="margin: 0; font-size: 14px; color: #666;">Your password reset code is:</p>
              <div class="otp-code">${otp}</div>
            </div>
            
            <p>Enter this code in the app to reset your password.</p>
            <p class="warning">⚠️ This code will expire in 10 minutes.</p>
            <p><strong>If you didn't request a password reset, please ignore this email and your password will remain unchanged.</strong></p>
          </div>
          <div class="footer">
            <p>© 2025 Pak Ads. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: `
Hello ${name}!

We received a request to reset your password for your Pak Ads account.

Your password reset code is: ${otp}

This code will expire in 10 minutes.

If you didn't request a password reset, please ignore this email.

© 2025 Pak Ads. All rights reserved.
    `,
  };
};

/**
 * Welcome email template (after verification)
 */
const welcomeEmailTemplate = (name, referralCode) => {
  return {
    subject: 'Welcome to Pak Ads! 🎉',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #2196F3; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 5px 5px; }
          .referral-box { background: white; border: 2px solid #2196F3; padding: 20px; text-align: center; margin: 20px 0; border-radius: 5px; }
          .referral-code { font-size: 24px; font-weight: bold; color: #2196F3; letter-spacing: 3px; }
          .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
          .feature { background: white; padding: 15px; margin: 10px 0; border-left: 4px solid #2196F3; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎉 Welcome to Pak Ads!</h1>
          </div>
          <div class="content">
            <h2>Hello ${name}!</h2>
            <p>Your email has been verified successfully. Welcome to the Pak Ads community!</p>
            
            <div class="referral-box">
              <p style="margin: 0; font-size: 14px; color: #666;">Your Referral Code:</p>
              <div class="referral-code">${referralCode}</div>
              <p style="margin: 10px 0 0 0; font-size: 12px; color: #666;">Share this code and earn commissions!</p>
            </div>
            
            <h3>What you can do now:</h3>
            <div class="feature">📱 Post unlimited ads</div>
            <div class="feature">💰 Earn through referrals</div>
            <div class="feature">🎰 Spin the lucky draw wheel</div>
            <div class="feature">🏆 Unlock rank rewards</div>
            <div class="feature">💵 Track your earnings</div>
            
            <p style="margin-top: 20px;">Start exploring and enjoy all the features!</p>
          </div>
          <div class="footer">
            <p>© 2025 Pak Ads. All rights reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
    text: `
Welcome to Pak Ads, ${name}!

Your email has been verified successfully.

Your Referral Code: ${referralCode}
Share this code and earn commissions!

What you can do now:
- Post unlimited ads
- Earn through referrals
- Spin the lucky draw wheel
- Unlock rank rewards
- Track your earnings

Start exploring and enjoy all the features!

© 2025 Pak Ads. All rights reserved.
    `,
  };
};

module.exports = {
  emailVerificationTemplate,
  passwordResetTemplate,
  welcomeEmailTemplate,
};

