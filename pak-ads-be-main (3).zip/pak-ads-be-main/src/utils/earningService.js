const { User, UserPlan, InvestmentPlan, Earning } = require('../models');
const { sequelize } = require('../config/database');
const logger = require('../config/logger');

/**
 * Distribute daily ROI earnings for all users with active plans
 */
async function distributeDailyROIEarnings() {
  try {
    logger.info('[roi] Starting daily ROI earnings distribution...');

    // 1. Get all active user plans
    const activePlans = await UserPlan.findAll({
      where: {
        status: 'active',
      },
      include: [
        {
          model: InvestmentPlan,
          as: 'plan',
        },
      ],
    });

    logger.info(`[roi] Found ${activePlans.length} active plans to process`);

    let distributedCount = 0;
    let completedCount = 0;

    for (const userPlan of activePlans) {
      const transaction = await sequelize.transaction();
      try {
        const now = new Date();
        const lastEarning = userPlan.last_earning_at || userPlan.activated_at;
        
        // Calculate minutes since last earning
        const minutesSinceLastEarning = (now - new Date(lastEarning)) / (1000 * 60);

        // If at least 2 minutes have passed
        if (minutesSinceLastEarning >= 2) {
          const user = await User.findByPk(userPlan.user_id, { transaction });
          if (!user) {
            await transaction.rollback();
            continue;
          }

          const dailyProfit = parseFloat(userPlan.daily_profit);
          const currentReturned = parseFloat(userPlan.total_returned);
          const maxReturn = parseFloat(userPlan.max_return);

          // Calculate how much is left to return
          const remainingToReturn = maxReturn - currentReturned;
          const actualEarining = Math.min(dailyProfit, remainingToReturn);

          if (actualEarining <= 0) {
            // Plan already finished but status was 'active'
            await userPlan.update({ status: 'completed' }, { transaction });
            await transaction.commit();
            completedCount++;
            continue;
          }

          // Create earning record
          await Earning.create({
            user_id: user.id,
            amount: actualEarining,
            type: 'roi_daily_profit',
            description: `Daily profit from ${userPlan.plan.name} (${currentReturned + actualEarining} / ${maxReturn})`,
            status: 'completed',
            metadata: JSON.stringify({
              plan_id: userPlan.plan_id,
              user_plan_id: userPlan.id,
              daily_profit: dailyProfit,
            }),
          }, { transaction });

          // Update user wallet
          await user.update({
            wallet_balance: parseFloat(user.wallet_balance) + actualEarining,
            total_earnings: parseFloat(user.total_earnings) + actualEarining,
          }, { transaction });

          // Update user plan
          const newTotalReturned = currentReturned + actualEarining;
          const updates = {
            total_returned: newTotalReturned,
            last_earning_at: now,
          };

          if (newTotalReturned >= maxReturn) {
            updates.status = 'completed';
            completedCount++;
          }

          await userPlan.update(updates, { transaction });

          await transaction.commit();
          distributedCount++;
          logger.info(`[roi] Distributed ${actualEarining} PKR to user ${user.id} for plan ${userPlan.plan.name}`);
        } else {
          await transaction.rollback();
        }
      } catch (error) {
        await transaction.rollback();
        logger.error(`[roi] Error distributing earnings for user plan ${userPlan.id}:`, error);
      }
    }

    logger.info(`[roi] Daily ROI distribution complete. Distributed: ${distributedCount}, Completed: ${completedCount}`);
    return { distributedCount, completedCount };
  } catch (error) {
    logger.error('[roi] Critical error in distributeDailyROIEarnings:', error);
    throw error;
  }
}

module.exports = {
  distributeDailyROIEarnings,
};
