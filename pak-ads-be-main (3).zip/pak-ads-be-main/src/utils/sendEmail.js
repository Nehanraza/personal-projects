const nodemailer = require('nodemailer');

const sendEmail = async (options) => {
  try {
    // Create transporter with Gmail configuration
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: 'qaziyousuf701@gmail.com',
        pass: 'mias kzjn bpiq hkvk', // App password
      },
      tls: {
        rejectUnauthorized: false
      },
      debug: process.env.NODE_ENV === 'development', // Enable debug in development
      logger: process.env.NODE_ENV === 'development'
    });

    // Verify connection configuration
    await transporter.verify();
    console.log('✅ SMTP Server is ready to take our messages');

    // Message options
    const message = {
      from: 'Pak Ads <qaziyousuf701@gmail.com>',
      to: options.email,
      subject: options.subject,
      text: options.message,
      html: options.html,
    };

    // Send email
    const info = await transporter.sendMail(message);
    console.log('✅ Message sent successfully: %s', info.messageId);
    return info;
    
  } catch (error) {
    console.error('❌ Error sending email:', error);
    throw error;
  }
};

module.exports = sendEmail;

