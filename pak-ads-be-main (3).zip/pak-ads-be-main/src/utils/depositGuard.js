const { Deposit } = require('../models');

async function hasApprovedDeposit(userId, transaction) {
  const count = await Deposit.count({
    where: { user_id: userId, status: 'approved' },
    transaction,
  });
  return count > 0;
}

module.exports = { hasApprovedDeposit };


