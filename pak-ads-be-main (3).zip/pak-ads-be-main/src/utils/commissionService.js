/**
 * Commission Service
 * Handles multi-level referral commission calculation and distribution
 */

const { User, Earning, UserPlan, InvestmentPlan } = require('../models');
const { hasApprovedDeposit } = require('../utils/depositGuard');
const { COMMISSION_LEVELS, COMMISSION_CONFIG, AD_WATCHING_COMMISSION_LEVELS } = require('../config/constants');
const { sequelize } = require('../config/database');
const { Op } = require('sequelize');
const logger = require('../config/logger');

/**
 * Get the upline chain for a user (up to 7 levels)
 * @param {number} userId - The user ID to start from
 * @param {number} maxLevels - Maximum number of levels to traverse (default: 7)
 * @returns {Promise<Array>} Array of upline users with their level
 */
async function getUplineChain(userId, maxLevels = COMMISSION_CONFIG.TOTAL_LEVELS) {
  const uplineChain = [];
  let currentUserId = userId;
  let level = 1;

  try {
    logger.info(`[commission] Building upline chain for user=${userId}, maxLevels=${maxLevels}`);
    while (level <= maxLevels && currentUserId) {
      // Find the user's referrer
      const user = await User.findByPk(currentUserId, {
        attributes: ['id', 'referred_by', 'name', 'email'],
        raw: true,
      });

      if (!user || !user.referred_by) {
        logger.info(`[commission] Stopping chain at level=${level} for user=${currentUserId} (no referrer)`);
        break; // No more referrers in the chain
      }

      uplineChain.push({
        userId: user.referred_by,
        level: level,
        name: user.name,
      });

      currentUserId = user.referred_by;
      level++;
    }

    logger.info(`[commission] Upline chain for user=${userId}: ${JSON.stringify(uplineChain)}`);
    return uplineChain;
  } catch (error) {
    logger.error('Error getting upline chain:', error);
    throw error;
  }
}

/**
 * Calculate commission amount for a specific level
 * @param {number} baseAmount - The base transaction amount
 * @param {number} level - The commission level (1-7)
 * @param {string} calculationType - 'fixed' or 'percentage' based calculation
 * @param {string} activityType - Type of activity (signup, ad_watching, purchase, etc.)
 * @returns {number} Commission amount for this level
 */
function calculateCommissionForLevel(baseAmount, level, calculationType = 'percentage', activityType = 'signup') {
  if (level < 1 || level > COMMISSION_CONFIG.TOTAL_LEVELS) {
    return 0;
  }

  // Use AD_WATCHING_COMMISSION_LEVELS for ad watching, COMMISSION_LEVELS for everything else
  let levelConfig;
  if (activityType === 'ad_watching') {
    // CRITICAL: For ad watching, watcher is Level 1 (22 PKR), so upline commission starts from Level 2
    // uplineChain level 1 (watcher's referrer) should get AD_WATCHING_COMMISSION_LEVELS[2] = 9 PKR
    // uplineChain level 2 should get AD_WATCHING_COMMISSION_LEVELS[3] = 7 PKR, etc.
    const adWatchingLevel = level + 1; // Shift level: upline Level 1 → commission Level 2
    levelConfig = AD_WATCHING_COMMISSION_LEVELS[adWatchingLevel];
    
    // If level doesn't exist or amount is 0, return 0
    if (!levelConfig || levelConfig.amount === 0) {
      return 0;
    }
  } else {
    levelConfig = COMMISSION_LEVELS[level];
  }
  
  if (calculationType === 'fixed') {
    // Fixed amount based on configuration
    return levelConfig.amount;
  } else {
    // Percentage-based calculation
    return parseFloat((baseAmount * levelConfig.ratio).toFixed(2));
  }
}

/**
 * Distribute commission to upline members
 * @param {number} fromUserId - User who triggered the commission (performed the activity)
 * @param {number} baseAmount - Base amount for commission calculation
 * @param {string} activityType - Type of activity (signup, ad_view, purchase, etc.)
 * @param {string} calculationType - 'fixed' or 'percentage' based calculation
 * @param {Object} options - Additional options (transaction, metadata)
 * @returns {Promise<Object>} Distribution result with details
 */
async function distributeCommission(
  fromUserId,
  baseAmount,
  activityType = 'signup',
  calculationType = 'percentage',
  options = {}
) {
  const { transaction, metadata = {} } = options;
  const distributionResults = [];
  let totalDistributed = 0;

  try {
    logger.info(`[commission] START distributeCommission fromUserId=${fromUserId}, baseAmount=${baseAmount}, activityType=${activityType}, calculationType=${calculationType}`);
    // Get the user who triggered the commission
    const fromUser = await User.findByPk(fromUserId, {
      attributes: ['id', 'name', 'email', 'is_admin_approved'],
    });

    if (!fromUser) {
      logger.warn(`User ${fromUserId} not found for commission distribution`);
      return {
        success: false,
        distributed: false,
        message: 'User not found',
        totalDistributed: 0,
        recipients: 0,
      };
    }

    // Removed admin approval gating: commissions distribute regardless of fromUser.is_admin_approved

    // Get the upline chain
    const uplineChain = await getUplineChain(fromUserId);

    if (uplineChain.length === 0) {
      logger.info(`[commission] User ${fromUserId} has no upline for commission distribution`);
      return {
        success: true,
        distributed: false,
        message: 'No upline found for commission distribution',
        totalDistributed: 0,
        recipients: 0,
      };
    }

    // Distribute commission to each level
    for (const upline of uplineChain) {
      const { userId, level } = upline;

      // Calculate commission for this level
      const commissionAmount = calculateCommissionForLevel(
        baseAmount,
        level,
        calculationType,
        activityType
      );

      logger.info(`[commission] Level ${level} -> userId=${userId}, baseAmount=${baseAmount}, calculationType=${calculationType}, activityType=${activityType}, amount=${commissionAmount}`);
      if (commissionAmount <= 0) {
        logger.warn(`[commission] Skipping level ${level} for userId=${userId} due to non-positive amount=${commissionAmount}`);
        continue;
      }

      // Get the upline user
      const uplineUser = await User.findByPk(userId);

      if (!uplineUser) {
        logger.warn(`[commission] Upline user ${userId} not found for commission distribution`);
        continue;
      }

      // Fetch active plan for the recipient
      const recipientPlan = await UserPlan.findOne({
        where: { user_id: userId, status: 'active' },
        transaction
      });

      // RUL ENFORCEMENT: Referrer must have same or higher plan than the source user
      // 1. Get the source user's active plan
      const sourceUserPlan = await UserPlan.findOne({
        where: { user_id: fromUserId, status: 'active' },
        transaction
      });

      // 2. If source user has a plan, compare with recipient's plan
      if (sourceUserPlan) {
        if (!recipientPlan || parseFloat(recipientPlan.investment_amount) < parseFloat(sourceUserPlan.investment_amount)) {
          logger.info(`[commission] Skipping level ${level} commission for userId=${userId}: Recipient has plan ${recipientPlan ? recipientPlan.investment_amount : 'none'} < source plan ${sourceUserPlan.investment_amount}`);
          continue;
        }
      } else {
        // If source user has no plan (e.g. just joined), we require the recipient to have at least one approved deposit
        // (which is already checked by hasApprovedDeposit below, but we can also require a plan if needed)
        const recipientHasDeposit = await hasApprovedDeposit(userId, transaction);
        if (!recipientHasDeposit) {
          logger.info(`[commission] Skipping commission for userId=${userId} (level=${level}) due to no approved deposit`);
          continue;
        }
      }

      // Create earning record
      const earning = await Earning.create(
        {
          user_id: userId,
          from_user_id: fromUserId,
          amount: commissionAmount,
          level: level,
          type: 'referral_commission',
          description: `Level ${level} referral commission from ${fromUser.name} (${activityType})`,
          status: 'completed',
          metadata: JSON.stringify({
            activity_type: activityType,
            base_amount: baseAmount,
            calculation_type: calculationType,
            commission_percentage: COMMISSION_LEVELS[level].percentage,
            ...metadata,
          }),
        },
        { transaction }
      );

      // Update user's wallet balance and total earnings
      await uplineUser.update(
        {
          wallet_balance: parseFloat(uplineUser.wallet_balance) + commissionAmount,
          total_earnings: parseFloat(uplineUser.total_earnings) + commissionAmount,
        },
        { transaction }
      );

      distributionResults.push({
        userId: userId,
        userName: uplineUser.name,
        level: level,
        amount: commissionAmount,
        earningId: earning.id,
      });

      totalDistributed += commissionAmount;

      logger.info(`[commission] Distributed ${commissionAmount} PKR to upline user=${userId} (level=${level}) fromUserId=${fromUserId}`);
    }

    logger.info(`[commission] DONE distributeCommission fromUserId=${fromUserId}, recipients=${distributionResults.length}, totalDistributed=${parseFloat(totalDistributed.toFixed(2))}`);
    return {
      success: true,
      distributed: true,
      message: 'Commission distributed successfully',
      totalDistributed: parseFloat(totalDistributed.toFixed(2)),
      recipients: distributionResults.length,
      details: distributionResults,
    };
  } catch (error) {
    logger.error('Error distributing commission:', error);
    throw error;
  }
}

/**
 * Get commission statistics for a user
 * @param {number} userId - User ID
 * @returns {Promise<Object>} Commission statistics
 */
async function getUserCommissionStats(userId) {
  try {
    // Get all referral commissions earned by the user
    const commissions = await Earning.findAll({
      where: {
        user_id: userId,
        type: 'referral_commission',
      },
      include: [
        {
          model: User,
          as: 'fromUser',
          attributes: ['id', 'name', 'email'],
        },
      ],
      order: [['created_at', 'DESC']],
    });

    // Calculate totals by level
    const totalsByLevel = {};
    let totalCommissionEarned = 0;

    for (let i = 1; i <= COMMISSION_CONFIG.TOTAL_LEVELS; i++) {
      totalsByLevel[i] = {
        level: i,
        count: 0,
        amount: 0,
      };
    }

    commissions.forEach((commission) => {
      const level = commission.level;
      const amount = parseFloat(commission.amount);

      if (level >= 1 && level <= COMMISSION_CONFIG.TOTAL_LEVELS) {
        totalsByLevel[level].count += 1;
        totalsByLevel[level].amount += amount;
      }

      totalCommissionEarned += amount;
    });

    // Get direct referrals (level 1 commissions sources)
    const directReferrals = await User.count({
      where: { referred_by: userId },
    });

    return {
      totalCommissionEarned: parseFloat(totalCommissionEarned.toFixed(2)),
      totalCommissions: commissions.length,
      directReferrals: directReferrals,
      byLevel: Object.values(totalsByLevel),
      recentCommissions: commissions.slice(0, 10).map((c) => ({
        id: c.id,
        amount: parseFloat(c.amount),
        level: c.level,
        fromUser: c.fromUser ? {
          id: c.fromUser.id,
          name: c.fromUser.name,
        } : null,
        description: c.description,
        createdAt: c.created_at,
      })),
    };
  } catch (error) {
    logger.error('Error getting user commission stats:', error);
    throw error;
  }
}

/**
 * Get overall commission statistics (for admin dashboard)
 * @param {Object} filters - Optional filters (date range, etc.)
 * @returns {Promise<Object>} Overall commission statistics
 */
async function getOverallCommissionStats(filters = {}) {
  try {
    const { startDate, endDate } = filters;
    const whereClause = {
      type: 'referral_commission',
    };

    if (startDate || endDate) {
      whereClause.created_at = {};
      if (startDate) {
        whereClause.created_at[Op.gte] = new Date(startDate);
      }
      if (endDate) {
        whereClause.created_at[Op.lte] = new Date(endDate);
      }
    }

    // Get all referral commissions
    const commissions = await Earning.findAll({
      where: whereClause,
      attributes: ['level', 'amount'],
      raw: true,
    });

    // Calculate totals
    const totalsByLevel = {};
    let totalCommissionDistributed = 0;
    let totalCommissions = commissions.length;

    for (let i = 1; i <= COMMISSION_CONFIG.TOTAL_LEVELS; i++) {
      totalsByLevel[i] = {
        level: i,
        count: 0,
        amount: 0,
        percentage: COMMISSION_LEVELS[i].percentage,
      };
    }

    commissions.forEach((commission) => {
      const level = commission.level;
      const amount = parseFloat(commission.amount);

      if (level >= 1 && level <= COMMISSION_CONFIG.TOTAL_LEVELS) {
        totalsByLevel[level].count += 1;
        totalsByLevel[level].amount += amount;
      }

      totalCommissionDistributed += amount;
    });

    // Get total users with referrals
    const usersWithReferrals = await User.count({
      where: {
        total_referrals: {
          [Op.gt]: 0,
        },
      },
    });

    return {
      totalCommissionDistributed: parseFloat(totalCommissionDistributed.toFixed(2)),
      totalCommissions: totalCommissions,
      usersWithReferrals: usersWithReferrals,
      distributionByLevel: Object.values(totalsByLevel),
      commissionStructure: COMMISSION_LEVELS,
    };
  } catch (error) {
    logger.error('Error getting overall commission stats:', error);
    throw error;
  }
}

/**
 * Get top earners by commission
 * @param {number} limit - Number of top earners to return (default: 10)
 * @param {Object} filters - Optional filters
 * @returns {Promise<Array>} Top earners
 */
async function getTopCommissionEarners(limit = 10, filters = {}) {
  try {
    const { startDate, endDate } = filters;
    const whereClause = {
      type: 'referral_commission',
    };

    if (startDate || endDate) {
      whereClause.created_at = {};
      if (startDate) {
        whereClause.created_at[Op.gte] = new Date(startDate);
      }
      if (endDate) {
        whereClause.created_at[Op.lte] = new Date(endDate);
      }
    }

    const topEarners = await Earning.findAll({
      where: whereClause,
      attributes: [
        'user_id',
        [sequelize.fn('SUM', sequelize.col('Earning.amount')), 'total_earned'],
        [sequelize.fn('COUNT', sequelize.col('Earning.id')), 'commission_count'],
      ],
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'name', 'email', 'total_referrals'],
        },
      ],
      group: ['Earning.user_id', 'user.id'],
      order: [[sequelize.fn('SUM', sequelize.col('Earning.amount')), 'DESC']],
      limit: limit,
      raw: false,
    });

    return topEarners.map((earner) => ({
      userId: earner.user_id,
      name: earner.user?.name,
      email: earner.user?.email,
      totalReferrals: earner.user?.total_referrals || 0,
      totalEarned: parseFloat(earner.get('total_earned')),
      commissionCount: parseInt(earner.get('commission_count')),
    }));
  } catch (error) {
    logger.error('Error getting top commission earners:', error);
    throw error;
  }
}

/**
 * Distribute commissions for a newly approved user
 * This function should be called when a user gets admin approval
 * @param {number} userId - User ID who was just approved
 * @returns {Promise<Object>} Distribution result
 */
async function distributeApprovalCommissions(userId) {
  try {
    const user = await User.findByPk(userId, {
      attributes: ['id', 'name', 'email', 'is_admin_approved', 'joining_fee_paid', 'joining_fee_amount'],
    });

    if (!user) {
      logger.warn(`User ${userId} not found for approval commission distribution`);
      return {
        success: false,
        message: 'User not found',
      };
    }

    // Removed admin approval check to allow commission distribution irrespective of approval status

    // If user paid joining fee, distribute joining fee commissions
    if (user.joining_fee_paid && user.joining_fee_amount) {
      const joiningFeeAmount = parseFloat(user.joining_fee_amount);
      logger.info(`Distributing joining fee commissions for newly approved user ${userId}`);
      
      const result = await distributeJoiningFeeCommission(userId, joiningFeeAmount);
      
      logger.info(`Commission distribution completed for user ${userId}:`, result);
      
      return {
        success: true,
        message: 'Approval commissions distributed successfully',
        data: result,
      };
    }

    logger.info(`User ${userId} has no joining fee to distribute commissions from`);
    return {
      success: true,
      message: 'No joining fee commissions to distribute',
    };
  } catch (error) {
    logger.error('Error distributing approval commissions:', error);
    throw error;
  }
}

/**
 * Preview commission distribution (without actually distributing)
 * @param {number} fromUserId - User who would trigger the commission
 * @param {number} baseAmount - Base amount for commission calculation
 * @param {string} calculationType - 'fixed' or 'percentage' based calculation
 * @param {string} activityType - Type of activity (signup, ad_watching, purchase, etc.)
 * @returns {Promise<Object>} Preview of commission distribution
 */
async function previewCommissionDistribution(fromUserId, baseAmount, calculationType = 'percentage', activityType = 'signup') {
  try {
    const uplineChain = await getUplineChain(fromUserId);
    const preview = [];
    let totalToDistribute = 0;

    for (const upline of uplineChain) {
      const { userId, level } = upline;
      const commissionAmount = calculateCommissionForLevel(
        baseAmount,
        level,
        calculationType,
        activityType
      );

      if (commissionAmount > 0) {
        const user = await User.findByPk(userId, {
          attributes: ['id', 'name', 'email'],
        });

        preview.push({
          userId: userId,
          userName: user?.name,
          level: level,
          amount: commissionAmount,
          percentage: COMMISSION_LEVELS[level].percentage,
        });

        totalToDistribute += commissionAmount;
      }
    }

    return {
      success: true,
      fromUserId: fromUserId,
      baseAmount: baseAmount,
      calculationType: calculationType,
      totalToDistribute: parseFloat(totalToDistribute.toFixed(2)),
      recipients: preview.length,
      levels: preview,
    };
  } catch (error) {
    logger.error('Error previewing commission distribution:', error);
    throw error;
  }
}

/**
 * Distribute commission for joining fee
 * This is a convenience wrapper for distributeCommission specifically for joining fees
 * @param {number} newUserId - New user who just joined
 * @param {number} joiningFeeAmount - Joining fee amount
 * @returns {Promise<Object>} Distribution result
 */
async function distributeJoiningFeeCommission(newUserId, joiningFeeAmount) {
  const transaction = await sequelize.transaction();
  
  try {
    // For joining fee, use fixed commission structure (345 PKR total)
    // Don't use percentage of joining fee amount
    const result = await distributeCommission(
      newUserId,
      COMMISSION_CONFIG.BASE_AMOUNT, // Use 345 PKR as base amount
      'joining_fee',
      'fixed', // Use fixed amounts instead of percentage
      { transaction, metadata: { joining_fee_amount: joiningFeeAmount } }
    );
    
    await transaction.commit();
    return result;
  } catch (error) {
    await transaction.rollback();
    logger.error('Error distributing joining fee commission:', error);
    throw error;
  }
}

/**
 * Distribute commission for ad watching
 * @param {number} userId - User who watched the ad
 * @param {number} adEarningAmount - Amount earned from watching the ad
 * @param {string} calculationType - 'fixed' or 'percentage' based calculation
 * @returns {Promise<Object>} Distribution result
 */
async function distributeAdWatchingCommission(userId, adEarningAmount, calculationType = 'fixed') {
  const transaction = await sequelize.transaction();
  
  try {
    const result = await distributeCommission(
      userId,
      adEarningAmount,
      'ad_watching',
      calculationType,
      { transaction, metadata: { ad_earning_amount: adEarningAmount } }
    );
    
    await transaction.commit();
    return result;
  } catch (error) {
    await transaction.rollback();
    logger.error('Error distributing ad watching commission:', error);
    throw error;
  }
}

/**
 * Distribute commission for purchase/transaction
 * @param {number} userId - User who made the purchase
 * @param {number} purchaseAmount - Purchase amount
 * @param {Object} metadata - Additional metadata about the purchase
 * @returns {Promise<Object>} Distribution result
 */
async function distributePurchaseCommission(userId, purchaseAmount, metadata = {}) {
  const transaction = await sequelize.transaction();
  
  try {
    const result = await distributeCommission(
      userId,
      purchaseAmount,
      'purchase',
      'percentage',
      { transaction, metadata: { purchase_amount: purchaseAmount, ...metadata } }
    );
    
    await transaction.commit();
    return result;
  } catch (error) {
    await transaction.rollback();
    logger.error('Error distributing purchase commission:', error);
    throw error;
  }
}

/**
 * Distribute commission for investment plan purchase (Direct level only)
 * @param {number} userId - User who purchased the plan
 * @param {number} referralBonus - Bonus amount for the referrer
 * @param {Object} options - Additional options (transaction, metadata)
 * @returns {Promise<Object>} Distribution result
 */
async function distributeInvestmentPlanCommission(userId, referralBonus, options = {}) {
  const { transaction, planName, purchasedPlanAmount } = options;
  
  try {
    const user = await User.findByPk(userId, {
      attributes: ['id', 'name', 'referred_by'],
    });

    if (!user || !user.referred_by) {
      return { success: true, message: 'No referrer found' };
    }

    const referrer = await User.findByPk(user.referred_by);
    if (!referrer) {
      return { success: true, message: 'Referrer not found' };
    }

    // CHECK IF REFERRER HAS A PLAN EQUAL TO OR HIGHER THAN PURCHASED PLAN
    if (purchasedPlanAmount) {
      const activeReferrerPlan = await UserPlan.findOne({
        where: { user_id: referrer.id, status: 'active' },
        transaction
      });
      
      if (!activeReferrerPlan || parseFloat(activeReferrerPlan.investment_amount) < purchasedPlanAmount) {
        logger.info(`[commission] Skipping commission: Referrer ${referrer.id} has plan amount ${activeReferrerPlan ? activeReferrerPlan.investment_amount : 'none'} < purchased plan amount ${purchasedPlanAmount}`);
        return { success: true, message: 'Referrer plan tier is too low to earn this commission' };
      }
    }

    // Create earning record for the referrer
    await Earning.create(
      {
        user_id: referrer.id,
        from_user_id: userId,
        amount: referralBonus,
        level: 1,
        type: 'referral_commission',
        description: `Direct referral bonus for ${planName} purchase by ${user.name}`,
        status: 'completed',
        metadata: JSON.stringify({
          activity_type: 'plan_purchase',
          referral_bonus: referralBonus,
          plan_name: planName,
        }),
      },
      { transaction }
    );

    // Update referrer's wallet balance
    await referrer.update(
      {
        wallet_balance: parseFloat(referrer.wallet_balance) + parseFloat(referralBonus),
        total_earnings: parseFloat(referrer.total_earnings) + parseFloat(referralBonus),
      },
      { transaction }
    );

    logger.info(`[commission] Distributed ${referralBonus} PKR plan referral bonus to user=${referrer.id} fromUserId=${userId}`);
    
    return { success: true, totalDistributed: referralBonus };
  } catch (error) {
    logger.error('Error distributing investment plan commission:', error);
    throw error;
  }
}

module.exports = {
  getUplineChain,
  calculateCommissionForLevel,
  distributeCommission,
  distributeJoiningFeeCommission,
  distributeAdWatchingCommission,
  distributePurchaseCommission,
  distributeInvestmentPlanCommission,
  distributeApprovalCommissions,
  getUserCommissionStats,
  getOverallCommissionStats,
  getTopCommissionEarners,
  previewCommissionDistribution,
};
