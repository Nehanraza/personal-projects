const { InvestmentPlan } = require('../../models');

const investmentPlans = [
  {
    name: 'Plan 1',
    investment_amount: 1500,
    total_return: 2250,
    daily_profit: 75,
    referral_bonus: 30,
    duration_days: 30,
  },
  {
    name: 'Plan 2',
    investment_amount: 3000,
    total_return: 4500,
    daily_profit: 150,
    referral_bonus: 60,
    duration_days: 30,
  },
  {
    name: 'Plan 3',
    investment_amount: 5000,
    total_return: 7500,
    daily_profit: 250,
    referral_bonus: 100,
    duration_days: 30,
  },
  {
    name: 'Plan 4',
    investment_amount: 10000,
    total_return: 15000,
    daily_profit: 500,
    referral_bonus: 200,
    duration_days: 30,
  },
  {
    name: 'Plan 5',
    investment_amount: 25000,
    total_return: 37500,
    daily_profit: 1250,
    referral_bonus: 500,
    duration_days: 30,
  },
  {
    name: 'Plan 6',
    investment_amount: 50000,
    total_return: 75000,
    daily_profit: 2500,
    referral_bonus: 1000,
    duration_days: 30,
  },
  {
    name: 'Plan 7',
    investment_amount: 100000,
    total_return: 150000,
    daily_profit: 5000,
    referral_bonus: 2000,
    duration_days: 30,
  },
  {
    name: 'Plan 8',
    investment_amount: 200000,
    total_return: 300000,
    daily_profit: 10000,
    referral_bonus: 4000,
    duration_days: 30,
  },
  {
    name: 'Plan 9',
    investment_amount: 400000,
    total_return: 600000,
    daily_profit: 20000,
    referral_bonus: 8000,
    duration_days: 30,
  },
  {
    name: 'Plan 10',
    investment_amount: 1000000,
    total_return: 1500000,
    daily_profit: 50000,
    referral_bonus: 20000,
    duration_days: 30,
  },
];

const seedInvestmentPlans = async () => {
  try {
    console.log('Seeding investment plans...');
    for (const plan of investmentPlans) {
      await InvestmentPlan.findOrCreate({
        where: { name: plan.name },
        defaults: plan,
      });
    }
    console.log('✓ Investment plans seeded successfully');
  } catch (error) {
    console.error('Migration failed: error seeding investment plans:', error);
    throw error;
  }
};

module.exports = seedInvestmentPlans;
