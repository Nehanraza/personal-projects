const Location = require('../../models/Location');
const logger = require('../../config/logger');

const seedLocations = async () => {
  try {
    const locationsCount = await Location.count();
    if (locationsCount > 0) {
      logger.info('Locations already exist, skipping seeding');
      return;
    }

    // Create country
    const country = await Location.create({
      name: 'Pakistan',
      slug: 'pakistan',
      type: 'country',
      display_order: 1,
    });

    // Create provinces
    const provinces = await Location.bulkCreate([
      { name: 'Punjab', slug: 'punjab', type: 'province', parent_id: country.id, display_order: 1 },
      { name: 'Sindh', slug: 'sindh', type: 'province', parent_id: country.id, display_order: 2 },
      { name: 'Khyber Pakhtunkhwa', slug: 'kpk', type: 'province', parent_id: country.id, display_order: 3 },
      { name: 'Balochistan', slug: 'balochistan', type: 'province', parent_id: country.id, display_order: 4 },
    ]);

    logger.info(`Seeded ${provinces.length} provinces`);

    // Get provinces for cities
    const punjab = await Location.findOne({ where: { slug: 'punjab' } });
    const sindh = await Location.findOne({ where: { slug: 'sindh' } });
    const kpk = await Location.findOne({ where: { slug: 'kpk' } });
    const balochistan = await Location.findOne({ where: { slug: 'balochistan' } });

    // Create cities
    const cities = [
      // Punjab cities
      { name: 'Lahore', slug: 'lahore', type: 'city', parent_id: punjab.id, latitude: 31.5204, longitude: 74.3587, display_order: 1 },
      { name: 'Faisalabad', slug: 'faisalabad', type: 'city', parent_id: punjab.id, latitude: 31.4504, longitude: 73.1350, display_order: 2 },
      { name: 'Rawalpindi', slug: 'rawalpindi', type: 'city', parent_id: punjab.id, latitude: 33.5651, longitude: 73.0169, display_order: 3 },
      { name: 'Multan', slug: 'multan', type: 'city', parent_id: punjab.id, latitude: 30.1575, longitude: 71.5249, display_order: 4 },
      { name: 'Gujranwala', slug: 'gujranwala', type: 'city', parent_id: punjab.id, latitude: 32.1877, longitude: 74.1945, display_order: 5 },
      { name: 'Sialkot', slug: 'sialkot', type: 'city', parent_id: punjab.id, latitude: 32.4945, longitude: 74.5229, display_order: 6 },
      
      // Sindh cities
      { name: 'Karachi', slug: 'karachi', type: 'city', parent_id: sindh.id, latitude: 24.8607, longitude: 67.0011, display_order: 1 },
      { name: 'Hyderabad', slug: 'hyderabad', type: 'city', parent_id: sindh.id, latitude: 25.3960, longitude: 68.3578, display_order: 2 },
      { name: 'Sukkur', slug: 'sukkur', type: 'city', parent_id: sindh.id, latitude: 27.7052, longitude: 68.8574, display_order: 3 },
      
      // KPK cities
      { name: 'Peshawar', slug: 'peshawar', type: 'city', parent_id: kpk.id, latitude: 34.0151, longitude: 71.5249, display_order: 1 },
      { name: 'Mardan', slug: 'mardan', type: 'city', parent_id: kpk.id, latitude: 34.1958, longitude: 72.0447, display_order: 2 },
      { name: 'Abbottabad', slug: 'abbottabad', type: 'city', parent_id: kpk.id, latitude: 34.1495, longitude: 73.2215, display_order: 3 },
      
      // Balochistan cities
      { name: 'Quetta', slug: 'quetta', type: 'city', parent_id: balochistan.id, latitude: 30.1798, longitude: 66.9750, display_order: 1 },
      { name: 'Gwadar', slug: 'gwadar', type: 'city', parent_id: balochistan.id, latitude: 25.1264, longitude: 62.3225, display_order: 2 },
      
      // Federal territories
      { name: 'Islamabad', slug: 'islamabad', type: 'city', parent_id: country.id, latitude: 33.6844, longitude: 73.0479, display_order: 1 },
    ];

    await Location.bulkCreate(cities);
    logger.info(`Seeded ${cities.length} cities`);
    logger.info('Location seeding completed successfully');
  } catch (error) {
    logger.error('Error seeding locations:', error);
    throw error;
  }
};

module.exports = seedLocations;

