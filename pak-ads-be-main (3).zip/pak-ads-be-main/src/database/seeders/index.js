require('dotenv').config();
const { sequelize } = require('../../config/database');
const logger = require('../../config/logger');
const seedAdmin = require('./adminSeeder');
const seedCategories = require('./categorySeeder');
const seedLocations = require('./locationSeeder');
const seedPackages = require('./packageSeeder');
const seedInvestmentPlans = require('./investmentPlanSeeder');

const runSeeders = async () => {
  try {
    logger.info('Starting database seeding...');

    // Test connection
    await sequelize.authenticate();
    logger.info('Database connection established');

    // Run seeders in order
    await seedAdmin();
    await seedCategories();
    await seedLocations();
    await seedPackages();
    await seedInvestmentPlans();

    logger.info('✓ All seeders completed successfully!');
    process.exit(0);
  } catch (error) {
    logger.error('✗ Seeding failed:', error);
    process.exit(1);
  }
};

runSeeders();
