const Category = require('../../models/Category');
const logger = require('../../config/logger');

const seedCategories = async () => {
  try {
    const categoriesCount = await Category.count();
    if (categoriesCount > 0) {
      logger.info('Categories already exist, skipping seeding');
      return;
    }

    const categories = [
      // Main categories
      { name: 'Electronics', slug: 'electronics', description: 'Electronic devices and gadgets', display_order: 1, icon: '📱' },
      { name: 'Vehicles', slug: 'vehicles', description: 'Cars, bikes, and other vehicles', display_order: 2, icon: '🚗' },
      { name: 'Property', slug: 'property', description: 'Houses, apartments, and land', display_order: 3, icon: '🏠' },
      { name: 'Furniture', slug: 'furniture', description: 'Home and office furniture', display_order: 4, icon: '🛋️' },
      { name: 'Fashion', slug: 'fashion', description: 'Clothing and accessories', display_order: 5, icon: '👗' },
      { name: 'Jobs', slug: 'jobs', description: 'Job opportunities', display_order: 6, icon: '💼' },
      { name: 'Services', slug: 'services', description: 'Professional services', display_order: 7, icon: '🔧' },
      { name: 'Education', slug: 'education', description: 'Books, courses, and tutoring', display_order: 8, icon: '📚' },
      { name: 'Pets', slug: 'pets', description: 'Pets and pet accessories', display_order: 9, icon: '🐕' },
      { name: 'Sports', slug: 'sports', description: 'Sports equipment and gear', display_order: 10, icon: '⚽' },
    ];

    await Category.bulkCreate(categories);
    logger.info(`Seeded ${categories.length} main categories`);

    // Get created categories for subcategories
    const electronics = await Category.findOne({ where: { slug: 'electronics' } });
    const vehicles = await Category.findOne({ where: { slug: 'vehicles' } });
    const property = await Category.findOne({ where: { slug: 'property' } });

    // Subcategories
    const subcategories = [
      // Electronics subcategories
      { name: 'Mobile Phones', slug: 'mobile-phones', parent_id: electronics.id, display_order: 1 },
      { name: 'Laptops', slug: 'laptops', parent_id: electronics.id, display_order: 2 },
      { name: 'Tablets', slug: 'tablets', parent_id: electronics.id, display_order: 3 },
      { name: 'Cameras', slug: 'cameras', parent_id: electronics.id, display_order: 4 },
      { name: 'TV & Audio', slug: 'tv-audio', parent_id: electronics.id, display_order: 5 },
      
      // Vehicles subcategories
      { name: 'Cars', slug: 'cars', parent_id: vehicles.id, display_order: 1 },
      { name: 'Motorcycles', slug: 'motorcycles', parent_id: vehicles.id, display_order: 2 },
      { name: 'Scooters', slug: 'scooters', parent_id: vehicles.id, display_order: 3 },
      { name: 'Trucks & Vans', slug: 'trucks-vans', parent_id: vehicles.id, display_order: 4 },
      
      // Property subcategories
      { name: 'Houses for Sale', slug: 'houses-sale', parent_id: property.id, display_order: 1 },
      { name: 'Houses for Rent', slug: 'houses-rent', parent_id: property.id, display_order: 2 },
      { name: 'Apartments for Sale', slug: 'apartments-sale', parent_id: property.id, display_order: 3 },
      { name: 'Apartments for Rent', slug: 'apartments-rent', parent_id: property.id, display_order: 4 },
      { name: 'Plots & Land', slug: 'plots-land', parent_id: property.id, display_order: 5 },
      { name: 'Commercial Property', slug: 'commercial-property', parent_id: property.id, display_order: 6 },
    ];

    await Category.bulkCreate(subcategories);
    logger.info(`Seeded ${subcategories.length} subcategories`);
    logger.info('Category seeding completed successfully');
  } catch (error) {
    logger.error('Error seeding categories:', error);
    throw error;
  }
};

module.exports = seedCategories;

