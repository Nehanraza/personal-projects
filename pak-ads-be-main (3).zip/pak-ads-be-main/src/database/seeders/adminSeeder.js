const User = require('../../models/User');
const logger = require('../../config/logger');

const seedAdmin = async () => {
  try {
    // Check if admin already exists
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@pakads.com';
    const existingAdmin = await User.findOne({ where: { email: adminEmail } });

    if (existingAdmin) {
      logger.info('Admin user already exists');
      return;
    }

    // Create admin user
    const admin = await User.create({
      name: process.env.ADMIN_NAME || 'Admin User',
      email: adminEmail,
      password: process.env.ADMIN_PASSWORD || 'admin123',
      phone: process.env.ADMIN_PHONE || '+92-300-0000000',
      role: 'admin',
      is_active: true,
      is_email_verified: true,
      is_admin_approved: true,
    });

    logger.info(`Admin user created successfully: ${admin.email}`);
  } catch (error) {
    logger.error('Error seeding admin user:', error);
    throw error;
  }
};

module.exports = seedAdmin;

