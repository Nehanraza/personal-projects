const Package = require('../../models/Package');
const logger = require('../../config/logger');

const seedPackages = async () => {
  try {
    const packagesCount = await Package.count();
    if (packagesCount > 0) {
      logger.info('Packages already exist, skipping seeding');
      return;
    }

    const packages = [
      {
        name: 'Free Basic',
        slug: 'free-basic',
        description: 'Post your ad for free with basic features',
        price: 0,
        duration_days: 30,
        ads_limit: 3,
        images_limit: 3,
        is_featured: false,
        featured_days: 0,
        priority: 0,
        display_order: 1,
      },
      {
        name: 'Standard',
        slug: 'standard',
        description: 'Enhanced visibility for your ads',
        price: 499,
        duration_days: 45,
        ads_limit: 10,
        images_limit: 5,
        is_featured: false,
        featured_days: 0,
        priority: 1,
        display_order: 2,
      },
      {
        name: 'Premium',
        slug: 'premium',
        description: 'Featured listing with maximum exposure',
        price: 999,
        duration_days: 60,
        ads_limit: 25,
        images_limit: 10,
        is_featured: true,
        featured_days: 7,
        priority: 2,
        display_order: 3,
      },
      {
        name: 'Gold',
        slug: 'gold',
        description: 'Top placement and extended duration',
        price: 1999,
        duration_days: 90,
        ads_limit: 50,
        images_limit: 15,
        is_featured: true,
        featured_days: 15,
        priority: 3,
        display_order: 4,
      },
      {
        name: 'Platinum',
        slug: 'platinum',
        description: 'Ultimate visibility and unlimited features',
        price: 3999,
        duration_days: 180,
        ads_limit: 100,
        images_limit: 20,
        is_featured: true,
        featured_days: 30,
        priority: 4,
        display_order: 5,
      },
    ];

    await Package.bulkCreate(packages);
    logger.info(`Seeded ${packages.length} packages`);
    logger.info('Package seeding completed successfully');
  } catch (error) {
    logger.error('Error seeding packages:', error);
    throw error;
  }
};

module.exports = seedPackages;

