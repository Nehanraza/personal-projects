require('dotenv').config();
const { sequelize } = require('../config/database');
const logger = require('../config/logger');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const resetDatabase = async () => {
  try {
    // Warning prompt
    rl.question(
      '⚠️  WARNING: This will DROP all tables and recreate them. All data will be LOST!\nType "yes" to continue: ',
      async (answer) => {
        if (answer.toLowerCase() !== 'yes') {
          logger.info('Database reset cancelled');
          process.exit(0);
        }

        try {
          logger.info('Connecting to database...');
          await sequelize.authenticate();
          
          logger.info('Dropping all tables...');
          await sequelize.drop();
          
          logger.info('Recreating tables...');
          await sequelize.sync({ force: true });
          
          logger.info('Database reset completed successfully!');
          logger.info('Run "npm run db:seed" to seed initial data');
          
          rl.close();
          process.exit(0);
        } catch (error) {
          logger.error('Database reset failed:', error);
          rl.close();
          process.exit(1);
        }
      }
    );
  } catch (error) {
    logger.error('Database reset failed:', error);
    rl.close();
    process.exit(1);
  }
};

resetDatabase();

