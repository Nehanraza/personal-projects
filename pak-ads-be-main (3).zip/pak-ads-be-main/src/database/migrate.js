require('dotenv').config();
const { sequelize } = require('../config/database');
const fs = require('fs');
const path = require('path');
const logger = require('../config/logger');

const runMigrations = async () => {
  try {
    logger.info('Starting database migrations...');

    // Test connection
    await sequelize.authenticate();
    logger.info('Database connection established');

    // Get all migration files
    const migrationsPath = path.join(__dirname, 'migrations');
    const migrationFiles = fs
      .readdirSync(migrationsPath)
      .filter((file) => file.endsWith('.js'))
      .sort();

    logger.info(`Found ${migrationFiles.length} migration file(s)`);

    // Run each migration
    for (const file of migrationFiles) {
      logger.info(`Running migration: ${file}`);
      const migration = require(path.join(migrationsPath, file));

      const queryInterface = sequelize.getQueryInterface();
      const Sequelize = sequelize.constructor;

      // Prefer passing queryInterface; fallback to sequelize only if needed
      if (typeof migration.up === 'function') {
        try {
          await migration.up(queryInterface, Sequelize);
        } catch (err) {
          const msg = (err && err.message) || '';
          // Only retry with sequelize instance if the failure looks like a signature mismatch
          if (msg.includes('is not a function') || msg.includes('getQueryInterface')) {
            logger.warn(`Primary call failed for ${file} due to signature, retrying with sequelize instance...`);
            await migration.up(sequelize);
          } else {
            // Bubble up real migration errors (e.g., duplicate column) to avoid wrong-arg calls
            throw err;
          }
        }
      } else {
        logger.warn(`Migration ${file} has no up() function, skipping.`);
      }
      logger.info(`✓ Completed: ${file}`);
    }

    logger.info('All migrations completed successfully!');
    process.exit(0);
  } catch (error) {
    logger.error('Migration failed:', error);
    process.exit(1);
  }
};

runMigrations();

