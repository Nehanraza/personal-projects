'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Check if column already exists
    let hasColumn = true;
    try {
      await queryInterface.describeTable('users').then(columns => {
        hasColumn = 'is_admin_approved' in columns;
      });
    } catch (_) {
      hasColumn = false;
    }

    if (!hasColumn) {
      await queryInterface.addColumn('users', 'is_admin_approved', {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
        allowNull: false,
      });
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('users', 'is_admin_approved');
  }
};
