const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Check if column already exists
    let hasColumn = true;
    try {
      await queryInterface.describeTable('ads').then(columns => {
        hasColumn = 'external_url' in columns;
      });
    } catch (_) {
      hasColumn = false;
    }

    if (!hasColumn) {
      await queryInterface.addColumn('ads', 'external_url', {
        type: DataTypes.STRING(500),
        allowNull: false,
        comment: 'External link for the ad (YouTube, website, etc.) - REQUIRED',
      });
    }
  },

  down: async (queryInterface, Sequelize) => {
    // Remove external_url column from ads table
    await queryInterface.removeColumn('ads', 'external_url');
  },
};
