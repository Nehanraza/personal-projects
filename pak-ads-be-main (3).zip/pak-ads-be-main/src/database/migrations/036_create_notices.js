'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Check if table already exists
    const tableExists = await queryInterface.tableExists('notices');
    
    if (!tableExists) {
      await queryInterface.createTable('notices', {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true,
        },
        title: {
          type: Sequelize.STRING(255),
          allowNull: false,
        },
        content: {
          type: Sequelize.TEXT,
          allowNull: false,
        },
        type: {
          type: Sequelize.ENUM('general', 'maintenance', 'promotion', 'warning', 'info'),
          defaultValue: 'general',
        },
        priority: {
          type: Sequelize.ENUM('low', 'normal', 'high', 'urgent'),
          defaultValue: 'normal',
        },
        status: {
          type: Sequelize.ENUM('active', 'inactive'),
          defaultValue: 'active',
        },
        expiresAt: {
          type: Sequelize.DATE,
          allowNull: true,
        },
        createdBy: {
          type: Sequelize.INTEGER,
          allowNull: false,
          references: {
            model: 'users',
            key: 'id',
          },
          onUpdate: 'CASCADE',
          onDelete: 'RESTRICT',
        },
        updatedBy: {
          type: Sequelize.INTEGER,
          allowNull: true,
          references: {
            model: 'users',
            key: 'id',
          },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        },
        created_at: {
          type: Sequelize.DATE,
          allowNull: false,
          defaultValue: Sequelize.NOW,
        },
        updated_at: {
          type: Sequelize.DATE,
          allowNull: false,
          defaultValue: Sequelize.NOW,
        },
      });
    }

    // Add indexes (only if they don't exist)
    try {
      await queryInterface.addIndex('notices', ['status']);
    } catch (error) {
      // Index might already exist, ignore error
    }
    
    try {
      await queryInterface.addIndex('notices', ['type']);
    } catch (error) {
      // Index might already exist, ignore error
    }
    
    try {
      await queryInterface.addIndex('notices', ['priority']);
    } catch (error) {
      // Index might already exist, ignore error
    }
    
    try {
      await queryInterface.addIndex('notices', ['expiresAt']);
    } catch (error) {
      // Index might already exist, ignore error
    }
    
    try {
      await queryInterface.addIndex('notices', ['created_at']);
    } catch (error) {
      // Index might already exist, ignore error
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('notices');
  },
};

