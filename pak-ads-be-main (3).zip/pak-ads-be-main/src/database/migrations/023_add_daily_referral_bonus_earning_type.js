/**
 * Migration: Add 'daily_referral_bonus' to earnings type enum
 * Purpose: Allow tracking of daily referral bonuses in earnings
 */

exports.up = async (queryInterface, Sequelize) => {
  // Add new earning type for daily referral bonus (idempotent)
  await queryInterface.sequelize.query(
    "DO $$ BEGIN IF NOT EXISTS (" +
      "SELECT 1 FROM pg_type t JOIN pg_enum e ON t.oid = e.enumtypid " +
      "WHERE t.typname = 'enum_earnings_type' AND e.enumlabel = 'daily_referral_bonus') THEN " +
      "ALTER TYPE \"enum_earnings_type\" ADD VALUE 'daily_referral_bonus'; END IF; END $$;"
  );
};

exports.down = async (queryInterface, Sequelize) => {
  // Note: PostgreSQL doesn't support removing enum values easily
  // This migration cannot be fully rolled back
  console.log('Warning: Cannot remove enum values in PostgreSQL. Manual intervention required.');
};
