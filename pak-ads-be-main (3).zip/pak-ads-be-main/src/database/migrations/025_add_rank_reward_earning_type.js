/**
 * Migration: Add 'rank_reward' to earnings type enum
 * Purpose: Allow tracking of rank-based rewards in earnings
 */

exports.up = async (queryInterface, Sequelize) => {
  // Add new earning type for rank reward (idempotent)
  await queryInterface.sequelize.query(
    "DO $$ BEGIN IF NOT EXISTS (" +
      "SELECT 1 FROM pg_type t JOIN pg_enum e ON t.oid = e.enumtypid " +
      "WHERE t.typname = 'enum_earnings_type' AND e.enumlabel = 'rank_reward') THEN " +
      "ALTER TYPE \"enum_earnings_type\" ADD VALUE 'rank_reward'; END IF; END $$;"
  );
};

exports.down = async (queryInterface, Sequelize) => {
  // Note: PostgreSQL doesn't support removing enum values easily
  // This migration cannot be fully rolled back
  console.log('Warning: Cannot remove enum values in PostgreSQL. Manual intervention required.');
};
