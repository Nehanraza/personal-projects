/**
 * Migration: Add 'ad_watching' to earnings type enum
 * Purpose: Allow tracking of ad watching earnings separately from other earning types
 */

exports.up = async (queryInterface, Sequelize) => {
  // Add new earning type for ad watching (idempotent)
  await queryInterface.sequelize.query(
    "DO $$ BEGIN IF NOT EXISTS (" +
      "SELECT 1 FROM pg_type t JOIN pg_enum e ON t.oid = e.enumtypid " +
      "WHERE t.typname = 'enum_earnings_type' AND e.enumlabel = 'ad_watching') THEN " +
      "ALTER TYPE \"enum_earnings_type\" ADD VALUE 'ad_watching'; END IF; END $$;"
  );
};

exports.down = async (queryInterface, Sequelize) => {
  // Note: PostgreSQL doesn't support removing enum values easily
  // This migration cannot be fully rolled back
  console.log('Warning: Cannot remove enum values in PostgreSQL. Manual intervention required.');
};

