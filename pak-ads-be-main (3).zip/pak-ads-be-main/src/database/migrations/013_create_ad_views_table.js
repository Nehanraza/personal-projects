const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    
    await queryInterface.createTable('ad_views', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'users',
          key: 'id',
        },
        onDelete: 'CASCADE',
      },
      ad_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'ads',
          key: 'id',
        },
        onDelete: 'CASCADE',
      },
      watched_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
    });

    // Add indexes for better query performance
    try {
      await queryInterface.addIndex('ad_views', ['user_id']);
    } catch (error) {
      // Index might already exist
    }
    
    try {
      await queryInterface.addIndex('ad_views', ['ad_id']);
    } catch (error) {
      // Index might already exist
    }
    
    try {
      await queryInterface.addIndex('ad_views', ['watched_at']);
    } catch (error) {
      // Index might already exist
    }
    
    try {
      await queryInterface.addIndex('ad_views', ['user_id', 'watched_at']);
    } catch (error) {
      // Index might already exist
    }
  },

  down: async (queryInterface, Sequelize) => {
    
    await queryInterface.dropTable('ad_views');
  },
};

