/**
 * Migration: Create rank rewards table
 * Purpose: Track rank-based rewards claimed by users
 */

exports.up = async (queryInterface, Sequelize) => {
  // Check if table already exists
  let hasTable = true;
  try {
    await queryInterface.describeTable('rank_rewards');
  } catch (_) {
    hasTable = false;
  }

  if (hasTable) {
    console.log('Table rank_rewards already exists, skipping migration.');
    return;
  }

  await queryInterface.createTable('rank_rewards', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: Sequelize.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    rank: {
      type: Sequelize.INTEGER,
      allowNull: false,
      comment: 'Rank number (1-7)',
    },
    rank_name: {
      type: Sequelize.STRING,
      allowNull: false,
      comment: 'Rank name (e.g., Rank 1, Rank 2)',
    },
    required_members: {
      type: Sequelize.INTEGER,
      allowNull: false,
      comment: 'Number of direct members required for this rank',
    },
    actual_members: {
      type: Sequelize.INTEGER,
      allowNull: false,
      comment: 'Actual number of direct members when reward was claimed',
    },
    reward_amount: {
      type: Sequelize.DECIMAL(12, 2),
      allowNull: false,
      comment: 'Reward amount in PKR',
    },
    reward_amount_usd: {
      type: Sequelize.DECIMAL(12, 2),
      allowNull: false,
      comment: 'Reward amount in USD',
    },
    earning_id: {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'earnings',
        key: 'id',
      },
      onDelete: 'SET NULL',
      comment: 'Reference to the earning record for this reward',
    },
    claimed_at: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.NOW,
      comment: 'When the reward was claimed',
    },
    created_at: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.NOW,
    },
    updated_at: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.NOW,
    },
  });

  // Add indexes for better performance
  await queryInterface.addIndex('rank_rewards', ['user_id']);
  await queryInterface.addIndex('rank_rewards', ['rank']);
  await queryInterface.addIndex('rank_rewards', ['claimed_at']);
  await queryInterface.addIndex('rank_rewards', ['user_id', 'rank'], {
    unique: true,
    name: 'unique_user_rank_reward',
  });
};

exports.down = async (queryInterface, Sequelize) => {
  await queryInterface.dropTable('rank_rewards');
};
