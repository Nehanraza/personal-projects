const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    const table = await queryInterface.describeTable('users');

    if (!table.wallet_balance) {
      await queryInterface.addColumn('users', 'wallet_balance', {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
        allowNull: false,
        comment: 'User wallet balance in PKR',
      });
    }

    if (!table.total_earnings) {
      await queryInterface.addColumn('users', 'total_earnings', {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
        allowNull: false,
        comment: 'Total earnings from referrals in PKR',
      });
    }

    if (!table.total_withdrawn) {
      await queryInterface.addColumn('users', 'total_withdrawn', {
        type: DataTypes.DECIMAL(12, 2),
        defaultValue: 0.00,
        allowNull: false,
        comment: 'Total amount withdrawn in PKR',
      });
    }
  },

  down: async (queryInterface) => {
    const table = await queryInterface.describeTable('users');
    if (table.wallet_balance) {
      await queryInterface.removeColumn('users', 'wallet_balance');
    }
    if (table.total_earnings) {
      await queryInterface.removeColumn('users', 'total_earnings');
    }
    if (table.total_withdrawn) {
      await queryInterface.removeColumn('users', 'total_withdrawn');
    }
  },
};

