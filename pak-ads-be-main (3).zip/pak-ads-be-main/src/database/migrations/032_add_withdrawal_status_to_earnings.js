/**
 * Migration: Add 'approved', 'rejected', 'sent' to earnings status enum
 * Purpose: Allow proper withdrawal status tracking in earnings table
 */

exports.up = async (queryInterface, Sequelize) => {
  // Add new status values for withdrawals (idempotent)
  await queryInterface.sequelize.query(
    "DO $$ BEGIN IF NOT EXISTS (" +
      "SELECT 1 FROM pg_type t JOIN pg_enum e ON t.oid = e.enumtypid " +
      "WHERE t.typname = 'enum_earnings_status' AND e.enumlabel = 'approved') THEN " +
      "ALTER TYPE \"enum_earnings_status\" ADD VALUE 'approved'; END IF; END $$;"
  );
  
  await queryInterface.sequelize.query(
    "DO $$ BEGIN IF NOT EXISTS (" +
      "SELECT 1 FROM pg_type t JOIN pg_enum e ON t.oid = e.enumtypid " +
      "WHERE t.typname = 'enum_earnings_status' AND e.enumlabel = 'rejected') THEN " +
      "ALTER TYPE \"enum_earnings_status\" ADD VALUE 'rejected'; END IF; END $$;"
  );
  
  await queryInterface.sequelize.query(
    "DO $$ BEGIN IF NOT EXISTS (" +
      "SELECT 1 FROM pg_type t JOIN pg_enum e ON t.oid = e.enumtypid " +
      "WHERE t.typname = 'enum_earnings_status' AND e.enumlabel = 'sent') THEN " +
      "ALTER TYPE \"enum_earnings_status\" ADD VALUE 'sent'; END IF; END $$;"
  );
};

exports.down = async (queryInterface, Sequelize) => {
  // Note: PostgreSQL doesn't support removing enum values easily
  // This migration cannot be fully rolled back
  console.log('Warning: Cannot remove enum values in PostgreSQL. Manual intervention required.');
};

