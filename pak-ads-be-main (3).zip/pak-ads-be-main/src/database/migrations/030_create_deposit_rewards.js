const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    // Check if table already exists
    let hasTable = true;
    try {
      await queryInterface.describeTable('deposit_rewards');
    } catch (_) {
      hasTable = false;
    }

    if (hasTable) {
      console.log('Table deposit_rewards already exists, skipping migration.');
      return;
    }

    // Create deposit_rewards table
    await queryInterface.createTable('deposit_rewards', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'users',
          key: 'id',
        },
        onDelete: 'CASCADE',
        comment: 'User who earned the deposit reward',
      },
      reward_amount: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
        comment: 'Reward amount in PKR',
      },
      referrals_count: {
        type: DataTypes.INTEGER,
        allowNull: false,
        comment: 'Total referrals when reward was earned',
      },
      earning_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: 'earnings',
          key: 'id',
        },
        onDelete: 'SET NULL',
        comment: 'Reference to the earning record for this reward',
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
    });

    // Add indexes
    await queryInterface.addIndex('deposit_rewards', ['user_id']);
    await queryInterface.addIndex('deposit_rewards', ['created_at']);
  },

  down: async (queryInterface) => {
    // Drop table
    await queryInterface.dropTable('deposit_rewards');
  },
};

