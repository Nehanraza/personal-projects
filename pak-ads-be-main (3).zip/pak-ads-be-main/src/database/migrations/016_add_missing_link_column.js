const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    
    // Add link column to notifications table if it doesn't exist
    try {
      await queryInterface.addColumn('notifications', 'link', {
        type: DataTypes.STRING,
        allowNull: true,
        comment: 'Link to related resource',
      });
      console.log('✓ Added link column to notifications');
    } catch (error) {
      // Column might already exist, ignore error
      console.log('Link column already exists or error:', error.message);
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('notifications', 'link');
  },
};

