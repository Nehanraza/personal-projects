/**
 * Migration: Add metadata column to earnings table
 * Purpose: Store additional information for withdrawals (payment method, account details, etc.)
 */

exports.up = async (queryInterface, Sequelize) => {
  // Check if metadata column already exists
  let hasColumn = true;
  try {
    await queryInterface.describeTable('earnings').then(columns => {
      hasColumn = 'metadata' in columns;
    });
  } catch (_) {
    hasColumn = false;
  }

  if (!hasColumn) {
    await queryInterface.addColumn('earnings', 'metadata', {
      type: Sequelize.TEXT,
      allowNull: true,
      comment: 'JSON string containing additional information (payment method, account details, etc.)',
    });
  }
};

exports.down = async (queryInterface, Sequelize) => {
  await queryInterface.removeColumn('earnings', 'metadata');
};

