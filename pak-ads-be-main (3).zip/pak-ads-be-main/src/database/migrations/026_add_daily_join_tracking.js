const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Check which columns exist
    const tableDescription = await queryInterface.describeTable('users');
    
    // Add daily direct join tracking fields
    if (!tableDescription.today_direct_joins) {
      await queryInterface.addColumn('users', 'today_direct_joins', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        allowNull: false,
        comment: 'Number of direct joins today'
      });
    }

    if (!tableDescription.last_join_reset_date) {
      await queryInterface.addColumn('users', 'last_join_reset_date', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'Last date when daily join count was reset'
      });
    }

    // Add second ad watching tracking fields
    if (!tableDescription.today_second_ad_views) {
      await queryInterface.addColumn('users', 'today_second_ad_views', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        allowNull: false,
        comment: 'Number of second ad views today'
      });
    }

    if (!tableDescription.last_ad_view_reset_date) {
      await queryInterface.addColumn('users', 'last_ad_view_reset_date', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'Last date when daily ad view count was reset'
      });
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('users', 'today_direct_joins');
    await queryInterface.removeColumn('users', 'last_join_reset_date');
    await queryInterface.removeColumn('users', 'today_second_ad_views');
    await queryInterface.removeColumn('users', 'last_ad_view_reset_date');
  }
};
