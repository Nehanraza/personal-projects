'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // 1. Create investment_plans table
    await queryInterface.createTable('investment_plans', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      name: {
        type: Sequelize.STRING(100),
        allowNull: false,
      },
      investment_amount: {
        type: Sequelize.DECIMAL(12, 2),
        allowNull: false,
      },
      total_return: {
        type: Sequelize.DECIMAL(12, 2),
        allowNull: false,
      },
      daily_profit: {
        type: Sequelize.DECIMAL(12, 2),
        allowNull: false,
      },
      referral_bonus: {
        type: Sequelize.DECIMAL(12, 2),
        allowNull: false,
      },
      duration_days: {
        type: Sequelize.INTEGER,
        defaultValue: 30,
      },
      is_active: {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
    });

    // 2. Create user_plans table
    await queryInterface.createTable('user_plans', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'users',
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      },
      plan_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'investment_plans',
          key: 'id',
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      },
      status: {
        type: Sequelize.ENUM('active', 'completed', 'cancelled'),
        defaultValue: 'active',
      },
      investment_amount: {
        type: Sequelize.DECIMAL(12, 2),
        allowNull: false,
      },
      daily_profit: {
        type: Sequelize.DECIMAL(12, 2),
        allowNull: false,
      },
      total_returned: {
        type: Sequelize.DECIMAL(12, 2),
        defaultValue: 0.00,
      },
      max_return: {
        type: Sequelize.DECIMAL(12, 2),
        allowNull: false,
      },
      activated_at: {
        type: Sequelize.DATE,
        allowNull: false,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP'),
      },
      expires_at: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      last_earning_at: {
        type: Sequelize.DATE,
        allowNull: true,
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
    });

    // 3. Add last_plan_upgrade_at to users table
    await queryInterface.addColumn('users', 'last_plan_upgrade_at', {
      type: Sequelize.DATE,
      allowNull: true,
    });

    // 4. Add plan_id to deposits table
    await queryInterface.addColumn('deposits', 'plan_id', {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'investment_plans',
        key: 'id',
      },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL',
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('deposits', 'plan_id');
    await queryInterface.removeColumn('users', 'last_plan_upgrade_at');
    await queryInterface.dropTable('user_plans');
    await queryInterface.dropTable('investment_plans');
  },
};
