const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    // Create table if it does not exist
    let hasTable = true;
    try {
      await queryInterface.describeTable('earnings');
    } catch (_) {
      hasTable = false;
    }

    if (!hasTable) {
      await queryInterface.createTable('earnings', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'users',
          key: 'id',
        },
        onDelete: 'CASCADE',
        comment: 'User who earned the commission',
      },
      from_user_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: 'users',
          key: 'id',
        },
        onDelete: 'CASCADE',
        comment: 'User who triggered this earning (the new member)',
      },
      amount: {
        type: DataTypes.DECIMAL(12, 2),
        allowNull: false,
        comment: 'Amount earned in PKR',
      },
      level: {
        type: DataTypes.INTEGER,
        allowNull: true,
        comment: 'Referral level (1-7)',
      },
      type: {
        type: DataTypes.ENUM('referral_commission', 'bonus', 'withdrawal', 'refund', 'lucky_draw_win', 'ad_watching', 'daily_referral_bonus', 'rank_reward'),
        defaultValue: 'referral_commission',
        allowNull: false,
      },
      description: {
        type: DataTypes.STRING,
        allowNull: true,
        comment: 'Description of the earning',
      },
      status: {
        type: DataTypes.ENUM('pending', 'completed', 'cancelled'),
        defaultValue: 'completed',
        allowNull: false,
      },
      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
      });
    }

    // Add indexes if they do not already exist
    const existingIndexes = await queryInterface.showIndex('earnings').catch(() => []);
    const indexNames = new Set(existingIndexes.map((i) => i.name));

    const toAdd = [
      { fields: ['user_id'], name: 'earnings_user_id' },
      { fields: ['from_user_id'], name: 'earnings_from_user_id' },
      { fields: ['level'], name: 'earnings_level' },
      { fields: ['type'], name: 'earnings_type' },
      { fields: ['created_at'], name: 'earnings_created_at' },
      { fields: ['user_id', 'created_at'], name: 'earnings_user_id_created_at' },
    ];

    for (const idx of toAdd) {
      if (!indexNames.has(idx.name)) {
        await queryInterface.addIndex('earnings', idx.fields, { name: idx.name });
      }
    }
  },

  down: async (queryInterface) => {
    // Drop table if exists
    let hasTable = true;
    try {
      await queryInterface.describeTable('earnings');
    } catch (_) {
      hasTable = false;
    }
    if (hasTable) {
      await queryInterface.dropTable('earnings');
    }
  },
};

