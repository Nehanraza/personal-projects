const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    
    // Check if columns exist before adding them
    const tableDescription = await queryInterface.describeTable('users');
    
    // Add referral and ad watching fields to users table
    if (!tableDescription.referred_by) {
      await queryInterface.addColumn('users', 'referred_by', {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: 'users',
          key: 'id',
        },
        onDelete: 'SET NULL',
        comment: 'ID of the user who referred this user',
      });
    }

    if (!tableDescription.referral_code) {
      await queryInterface.addColumn('users', 'referral_code', {
        type: DataTypes.STRING(20),
        allowNull: true,
        unique: true,
        comment: 'Unique referral code for this user',
      });
    }

    if (!tableDescription.last_ad_watched_at) {
      await queryInterface.addColumn('users', 'last_ad_watched_at', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'Timestamp of when user last watched an ad',
      });
    }

    if (!tableDescription.current_cycle_started_at) {
      await queryInterface.addColumn('users', 'current_cycle_started_at', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'When the current 7-day cycle started',
      });
    }

    if (!tableDescription.total_referrals) {
      await queryInterface.addColumn('users', 'total_referrals', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        comment: 'Total number of users referred by this user',
      });
    }

    // Add index for better performance (check if they exist first)
    try {
      await queryInterface.addIndex('users', ['referred_by']);
    } catch (error) {
      // Index might already exist
    }
    
    try {
      await queryInterface.addIndex('users', ['referral_code']);
    } catch (error) {
      // Index might already exist
    }
  },

  down: async (queryInterface, Sequelize) => {
    
    await queryInterface.removeColumn('users', 'referred_by');
    await queryInterface.removeColumn('users', 'referral_code');
    await queryInterface.removeColumn('users', 'last_ad_watched_at');
    await queryInterface.removeColumn('users', 'current_cycle_started_at');
    await queryInterface.removeColumn('users', 'total_referrals');
  },
};

