const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const tableDescription = await queryInterface.describeTable('users');
    
    if (!tableDescription.joining_fee_paid) {
      await queryInterface.addColumn('users', 'joining_fee_paid', {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false,
        comment: 'Whether the user has paid the joining fee',
      });
    }

    if (!tableDescription.joining_fee_paid_at) {
      await queryInterface.addColumn('users', 'joining_fee_paid_at', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'When the user paid the joining fee',
      });
    }

    if (!tableDescription.joining_fee_amount) {
      await queryInterface.addColumn('users', 'joining_fee_amount', {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true,
        comment: 'Amount paid as joining fee in PKR',
      });
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('users', 'joining_fee_paid');
    await queryInterface.removeColumn('users', 'joining_fee_paid_at');
    await queryInterface.removeColumn('users', 'joining_fee_amount');
  },
};

