/**
 * Migration: Create daily referral bonuses table
 * Purpose: Track daily referral bonuses awarded to users
 */

exports.up = async (queryInterface, Sequelize) => {
  // Check if table already exists
  let hasTable = true;
  try {
    await queryInterface.describeTable('daily_referral_bonuses');
  } catch (_) {
    hasTable = false;
  }

  if (hasTable) {
    console.log('Table daily_referral_bonuses already exists, skipping migration.');
    return;
  }

  await queryInterface.createTable('daily_referral_bonuses', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: {
      type: Sequelize.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    },
    bonus_date: {
      type: Sequelize.DATEONLY,
      allowNull: false,
      comment: 'Date when the bonus was earned (YYYY-MM-DD)',
    },
    referrals_count: {
      type: Sequelize.INTEGER,
      allowNull: false,
      comment: 'Number of referrals made on this date',
    },
    bonus_amount: {
      type: Sequelize.DECIMAL(12, 2),
      allowNull: false,
      comment: 'Total bonus amount awarded in PKR',
    },
    bonus_count: {
      type: Sequelize.INTEGER,
      allowNull: false,
      defaultValue: 0,
      comment: 'Number of bonuses awarded (1 bonus per threshold)',
    },
    earning_id: {
      type: Sequelize.INTEGER,
      allowNull: true,
      references: {
        model: 'earnings',
        key: 'id',
      },
      onDelete: 'SET NULL',
      comment: 'Reference to the earning record for this bonus',
    },
    created_at: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.NOW,
    },
    updated_at: {
      type: Sequelize.DATE,
      allowNull: false,
      defaultValue: Sequelize.NOW,
    },
  });

  // Add indexes for better performance
  await queryInterface.addIndex('daily_referral_bonuses', ['user_id']);
  await queryInterface.addIndex('daily_referral_bonuses', ['bonus_date']);
  await queryInterface.addIndex('daily_referral_bonuses', ['user_id', 'bonus_date'], {
    unique: true,
    name: 'unique_user_date_bonus',
  });
};

exports.down = async (queryInterface, Sequelize) => {
  await queryInterface.dropTable('daily_referral_bonuses');
};
