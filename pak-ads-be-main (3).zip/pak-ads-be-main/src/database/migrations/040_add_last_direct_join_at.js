const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Check which columns exist
    const tableDescription = await queryInterface.describeTable('users');
    
    // Add last_direct_join_at field for 24-hour tracking
    if (!tableDescription.last_direct_join_at) {
      await queryInterface.addColumn('users', 'last_direct_join_at', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'Timestamp of when the last direct join was added (for 24-hour tracking)',
      });
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('users', 'last_direct_join_at');
  },
};

