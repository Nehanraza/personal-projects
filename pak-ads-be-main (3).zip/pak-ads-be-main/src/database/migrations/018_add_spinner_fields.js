const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const tableDescription = await queryInterface.describeTable('users');
    
    if (!tableDescription.total_spins) {
      await queryInterface.addColumn('users', 'total_spins', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        allowNull: false,
        comment: 'Total number of spins performed by user',
      });
    }

    if (!tableDescription.extra_spins) {
      await queryInterface.addColumn('users', 'extra_spins', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        allowNull: false,
        comment: 'Extra spins available to user',
      });
    }

    if (!tableDescription.last_spin_at) {
      await queryInterface.addColumn('users', 'last_spin_at', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'Last time user performed a spin',
      });
    }

    if (!tableDescription.daily_spin_limit) {
      await queryInterface.addColumn('users', 'daily_spin_limit', {
        type: DataTypes.INTEGER,
        defaultValue: 5,
        allowNull: false,
        comment: 'Maximum spins allowed per day',
      });
    }

    if (!tableDescription.today_spins_count) {
      await queryInterface.addColumn('users', 'today_spins_count', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        allowNull: false,
        comment: 'Number of spins performed today',
      });
    }

    if (!tableDescription.last_spin_reset_date) {
      await queryInterface.addColumn('users', 'last_spin_reset_date', {
        type: DataTypes.DATE,
        allowNull: true,
        comment: 'Date when spin count was last reset (for daily limit)',
      });
    }
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('users', 'total_spins');
    await queryInterface.removeColumn('users', 'extra_spins');
    await queryInterface.removeColumn('users', 'last_spin_at');
    await queryInterface.removeColumn('users', 'daily_spin_limit');
    await queryInterface.removeColumn('users', 'today_spins_count');
    await queryInterface.removeColumn('users', 'last_spin_reset_date');
  },
};
