const { DataTypes } = require('sequelize');

module.exports = {
  up: async (queryInterface) => {
    // Update from_user_id to allow null
    await queryInterface.changeColumn('earnings', 'from_user_id', {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    });

    // Update level to allow null
    await queryInterface.changeColumn('earnings', 'level', {
      type: DataTypes.INTEGER,
      allowNull: true,
    });

    // Add new earning type for spinner (idempotent)
    await queryInterface.sequelize.query(
      "DO $$ BEGIN IF NOT EXISTS (" +
        "SELECT 1 FROM pg_type t JOIN pg_enum e ON t.oid = e.enumtypid " +
        "WHERE t.typname = 'enum_earnings_type' AND e.enumlabel = 'lucky_draw_win') THEN " +
        "ALTER TYPE \"enum_earnings_type\" ADD VALUE 'lucky_draw_win'; END IF; END $$;"
    );
  },

  down: async (queryInterface) => {
    // Revert from_user_id to not null (this might fail if there are null values)
    await queryInterface.changeColumn('earnings', 'from_user_id', {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
      onDelete: 'CASCADE',
    });

    // Revert level to not null (this might fail if there are null values)
    await queryInterface.changeColumn('earnings', 'level', {
      type: DataTypes.INTEGER,
      allowNull: false,
    });
  },
};
