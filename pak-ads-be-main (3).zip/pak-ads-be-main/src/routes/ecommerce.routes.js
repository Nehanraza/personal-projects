const express = require('express');
const router = express.Router();
const upload = require('../middleware/upload');
const axios = require('axios');

// Proxy endpoint to accept multipart with image and forward to external e-commerce API
// POST /api/v1/ecommerce/add-product
// Fields: product_title, price, description, colors, status
// File field: product_image
router.post('/add-product', upload.single('product_image'), async (req, res) => {
  try {
    const externalBase = process.env.EXTERNAL_ECOMMERCE_BASE_URL || process.env.EXTERNAL_BASE_URL;
    if (!externalBase) {
      return res.status(500).json({ success: false, message: 'External base URL not configured' });
    }

    const token = req.headers.authorization || '';

    // Build image URL from local upload
    const imageUrl = req.file
      ? `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`
      : (req.body.product_image || '');

    const payload = {
      product_title: req.body.product_title,
      price: req.body.price,
      description: req.body.description,
      colors: req.body.colors,
      status: req.body.status || 'enable',
      product_image: imageUrl,
    };

    const forwardUrl = `${externalBase.replace(/\/$/, '')}/add-ecommerce-product`;
    const forwardRes = await axios.post(forwardUrl, payload, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: token,
      },
    });

    return res.status(forwardRes.status).json(forwardRes.data);
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
