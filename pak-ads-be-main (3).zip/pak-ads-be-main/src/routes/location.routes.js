const express = require('express');
const router = express.Router();

const {
  getLocations,
  getLocationTree,
  getLocation,
  createLocation,
  updateLocation,
  deleteLocation,
} = require('../controllers/location.controller');

const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/', getLocations);
router.get('/tree', getLocationTree);
router.get('/:id', getLocation);

// Protected routes (Admin only)
router.use(protect);
router.use(authorize('admin'));

router.post('/', createLocation);
router.put('/:id', updateLocation);
router.delete('/:id', deleteLocation);

module.exports = router;

