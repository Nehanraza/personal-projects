const express = require('express');
const router = express.Router();

const {
  spinWheel,
  getSpinnerInfo,
} = require('../controllers/spinner.controller');

const { protect } = require('../middleware/auth');

// Protected routes (require authentication)
router.get('/info', protect, getSpinnerInfo);
router.post('/spin', protect, spinWheel);

module.exports = router;
