const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  claimRankReward,
  getRankStatus,
  getRankRewardHistory,
} = require('../controllers/rankReward.controller');

const router = express.Router();

// All routes require authentication
router.use(protect);
router.use(authorize('user', 'admin'));

// Rank reward routes
router.post('/claim', claimRankReward);
router.get('/status', getRankStatus);
router.get('/history', getRankRewardHistory);

module.exports = router;
