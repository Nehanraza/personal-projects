const express = require('express');
const router = express.Router();
const investmentPlanController = require('../controllers/investmentPlanController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload'); // Assuming upload middleware exists for proof image

// Public routes
router.get('/', investmentPlanController.getPlans);

// Protected routes
router.use(protect);
router.get('/my-plan', investmentPlanController.getMyPlan);
router.get('/my-plan', investmentPlanController.getMyPlan);
router.post('/purchase', upload.single('proof_image'), investmentPlanController.purchasePlan);

module.exports = router;
