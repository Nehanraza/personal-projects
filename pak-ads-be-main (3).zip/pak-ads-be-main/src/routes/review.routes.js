const express = require('express');
const router = express.Router();

const {
  getReviews,
  getReview,
  createReview,
  updateReview,
  deleteReview,
  approveReview,
} = require('../controllers/review.controller');

const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/', getReviews);
router.get('/:id', getReview);

// Protected routes
router.use(protect);

router.post('/', createReview);
router.put('/:id', updateReview);
router.delete('/:id', deleteReview);

// Admin only routes
router.put('/:id/approve', authorize('admin'), approveReview);

module.exports = router;

