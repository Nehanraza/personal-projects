const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  watchAd,
  getAdWatchingStatus,
  getAdWatchingHistory,
  addMember,
  getReferralInfo,
  getSecondAdStatus,
} = require('../controllers/adView.controller');

const router = express.Router();

// All routes require authentication and user role
router.use(protect);
router.use(authorize('user', 'admin'));

//comment added

// Ad watching routes
router.post('/:adId/watch', watchAd);
router.get('/status', getAdWatchingStatus);
router.get('/history', getAdWatchingHistory);
router.get('/second-ad-status', getSecondAdStatus);

// Referral routes
router.post('/add-member', addMember);
router.get('/referral-info', getReferralInfo);

module.exports = router;

