const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  checkAndAwardDailyBonus,
  getDailyBonusHistory,
  getTodayReferralStatus,
} = require('../controllers/dailyReferralBonus.controller');

const router = express.Router();

// All routes require authentication
router.use(protect);
router.use(authorize('user', 'admin'));

// Daily referral bonus routes
router.post('/check', checkAndAwardDailyBonus);
router.get('/history', getDailyBonusHistory);
router.get('/status', getTodayReferralStatus);

module.exports = router;
