const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  transferMoney,
  getTransfers,
  getTransferById,
  getTransferStats,
} = require('../controllers/transfer.controller');

const router = express.Router();

// All routes require authentication
router.use(protect);
router.use(authorize('user', 'admin'));

// Transfer routes
router.post('/', transferMoney);
router.get('/', getTransfers);
router.get('/:id', getTransferById);
router.get('/admin/stats', authorize('admin'), getTransferStats);

module.exports = router;

