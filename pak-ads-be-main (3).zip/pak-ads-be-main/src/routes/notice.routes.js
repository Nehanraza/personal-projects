const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  getAllNotices,
  getNoticeById,
  createNotice,
  updateNotice,
  deleteNotice,
  getActiveNotices,
} = require('../controllers/notice.controller');

const router = express.Router();

// Public routes
router.get('/active', getActiveNotices);
router.get('/:id', getNoticeById);

// Protected routes
router.use(protect);

// Admin only routes
router.get('/', authorize('admin'), getAllNotices);
router.post('/', authorize('admin'), createNotice);
router.put('/:id', authorize('admin'), updateNotice);
router.delete('/:id', authorize('admin'), deleteNotice);

module.exports = router;

