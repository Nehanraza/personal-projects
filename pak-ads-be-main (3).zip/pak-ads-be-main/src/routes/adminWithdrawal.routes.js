const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  getAllWithdrawals,
  approveWithdrawal,
  rejectWithdrawal,
  markWithdrawalAsSent,
  getWithdrawalStats,
} = require('../controllers/adminWithdrawal.controller');

const router = express.Router();

// All routes require admin authentication
router.use(protect);
router.use(authorize('admin'));

// Admin withdrawal management routes
router.get('/', getAllWithdrawals);
router.get('/stats', getWithdrawalStats);
router.put('/:id/approve', approveWithdrawal);
router.put('/:id/reject', rejectWithdrawal);
router.put('/:id/sent', markWithdrawalAsSent);

module.exports = router;

