const express = require('express');
const router = express.Router();
const { getAllUserPlans, getUserPlanById, getROIStats } = require('../controllers/adminUserPlan.controller');
const { protect, authorize } = require('../middleware/auth');

// All routes require admin authentication
router.use(protect);
router.use(authorize('admin'));

// Admin user plan management routes
router.get('/', getAllUserPlans);
router.get('/stats/roi', getROIStats);
router.get('/:id', getUserPlanById);

module.exports = router;
