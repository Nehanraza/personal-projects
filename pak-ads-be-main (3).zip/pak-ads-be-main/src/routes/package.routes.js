const express = require('express');
const router = express.Router();

const {
  getPackages,
  getPackage,
  createPackage,
  updatePackage,
  deletePackage,
} = require('../controllers/package.controller');

const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/', getPackages);
router.get('/:id', getPackage);

// Protected routes (Admin only)
router.use(protect);
router.use(authorize('admin'));

router.post('/', createPackage);
router.put('/:id', updatePackage);
router.delete('/:id', deletePackage);

module.exports = router;

