const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  checkAndAwardDepositReward,
  getDepositRewardStatus,
  getDepositRewardHistory,
} = require('../controllers/depositReward.controller');

const router = express.Router();

// All routes require authentication
router.use(protect);
router.use(authorize('user', 'admin'));

// Deposit reward routes
router.post('/check', checkAndAwardDepositReward);
router.get('/status', getDepositRewardStatus);
router.get('/history', getDepositRewardHistory);

module.exports = router;

