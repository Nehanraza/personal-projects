const express = require('express');
const router = express.Router();

// Import route modules
const authRoutes = require('./auth.routes');
const userRoutes = require('./user.routes');
const categoryRoutes = require('./category.routes');
const locationRoutes = require('./location.routes');
const adRoutes = require('./ad.routes');
const packageRoutes = require('./package.routes');
const reviewRoutes = require('./review.routes');
const messageRoutes = require('./message.routes');
const reportRoutes = require('./report.routes');
const favoriteRoutes = require('./favorite.routes');
const notificationRoutes = require('./notification.routes');
const dashboardRoutes = require('./dashboard.routes');
const profileRoutes = require('./profile.routes');
const adViewRoutes = require('./adView.routes');
const walletRoutes = require('./wallet.routes');
const spinnerRoutes = require('./spinner.routes');
const dailyReferralBonusRoutes = require('./dailyReferralBonus.routes');
const rankRewardRoutes = require('./rankReward.routes');
const commissionRoutes = require('./commission.routes');
const adminWithdrawalRoutes = require('./adminWithdrawal.routes');
const noticeRoutes = require('./notice.routes');
const depositRoutes = require('./deposit.routes');
const depositRewardRoutes = require('./depositReward.routes');
const transferRoutes = require('./transfer.routes');
const uploadRoutes = require('./upload.routes');
const adminApprovalRoutes = require('./adminApproval.routes');
const investmentPlanRoutes = require('./investmentPlanRoutes');
const adminUserPlanRoutes = require('./adminUserPlan.routes');

// Mount routes
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/categories', categoryRoutes);
router.use('/locations', locationRoutes);
router.use('/ads', adRoutes);
router.use('/packages', packageRoutes);
router.use('/reviews', reviewRoutes);
router.use('/messages', messageRoutes);
router.use('/reports', reportRoutes);
router.use('/favorites', favoriteRoutes);
router.use('/notifications', notificationRoutes);
router.use('/dashboard', dashboardRoutes);
router.use('/profile', profileRoutes);
router.use('/ad-views', adViewRoutes);
router.use('/wallet', walletRoutes);
router.use('/spinner', spinnerRoutes);
router.use('/daily-referral-bonus', dailyReferralBonusRoutes);
router.use('/rank-reward', rankRewardRoutes);
router.use('/commissions', commissionRoutes);
router.use('/admin/withdrawals', adminWithdrawalRoutes);
router.use('/notices', noticeRoutes);
router.use('/deposits', depositRoutes);
router.use('/deposit-rewards', depositRewardRoutes);
router.use('/transfers', transferRoutes);
router.use('/upload', uploadRoutes);
router.use('/admin/approval', adminApprovalRoutes);
router.use('/plans', investmentPlanRoutes);
router.use('/admin/user-plans', adminUserPlanRoutes);

// API info
router.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Pak Ads API',
    version: process.env.API_VERSION || 'v1',
    app_name: process.env.APP_NAME || 'Pak Ads',
    endpoints: {
      auth: '/api/v1/auth',
      users: '/api/v1/users',
      categories: '/api/v1/categories',
      locations: '/api/v1/locations',
      ads: '/api/v1/ads',
      packages: '/api/v1/packages',
      reviews: '/api/v1/reviews',
      messages: '/api/v1/messages',
      reports: '/api/v1/reports',
      favorites: '/api/v1/favorites',
      notifications: '/api/v1/notifications',
      dashboard: '/api/v1/dashboard',
      profile: '/api/v1/profile',
      adViews: '/api/v1/ad-views',
      wallet: '/api/v1/wallet',
      spinner: '/api/v1/spinner',
      dailyReferralBonus: '/api/v1/daily-referral-bonus',
      rankReward: '/api/v1/rank-reward',
      commissions: '/api/v1/commissions',
      adminWithdrawals: '/api/v1/admin/withdrawals',
      notices: '/api/v1/notices',
      deposits: '/api/v1/deposits',
      transfers: '/api/v1/transfers',
      adminApproval: '/api/v1/admin/approval',
      plans: '/api/v1/plans',
      adminUserPlans: '/api/v1/admin/user-plans',
    },
    documentation: {
      readme: 'See README.md for complete API documentation',
      quick_reference: 'See QUICK_REFERENCE.md for quick commands',
    },
  });
});

// Database setup endpoint (for initial deployment)
// IMPORTANT: Remove or protect this endpoint after first use in production
router.get('/setup-database', async (req, res) => {
  try {
    const { sequelize } = require('../config/database');
    const fs = require('fs').promises;
    const path = require('path');

    const results = {
      migrations: [],
      seeders: [],
      errors: [],
    };

    // Run migrations
    try {
      const migrationsPath = path.join(__dirname, '../database/migrations');
      const migrationFiles = await fs.readdir(migrationsPath);
      
      for (const file of migrationFiles.sort()) {
        try {
          const migration = require(path.join(migrationsPath, file));
          if (migration.up && typeof migration.up === 'function') {
            await migration.up(sequelize.getQueryInterface(), sequelize.Sequelize);
            results.migrations.push({ file, status: 'success' });
          }
        } catch (error) {
          results.migrations.push({ file, status: 'error', message: error.message });
          results.errors.push(`Migration ${file}: ${error.message}`);
        }
      }
    } catch (error) {
      results.errors.push(`Migrations directory error: ${error.message}`);
    }

    // Run seeders
    try {
      const seedersPath = path.join(__dirname, '../database/seeders');
      const seederFiles = ['adminSeeder.js', 'categorySeeder.js', 'locationSeeder.js', 'packageSeeder.js'];
      
      for (const file of seederFiles) {
        try {
          const seeder = require(path.join(seedersPath, file));
          if (typeof seeder === 'function') {
            await seeder();
            results.seeders.push({ file, status: 'success' });
          }
        } catch (error) {
          results.seeders.push({ file, status: 'error', message: error.message });
          results.errors.push(`Seeder ${file}: ${error.message}`);
        }
      }
    } catch (error) {
      results.errors.push(`Seeders directory error: ${error.message}`);
    }

    res.json({
      success: results.errors.length === 0,
      message: results.errors.length === 0 
        ? 'Database setup completed successfully' 
        : 'Database setup completed with some errors',
      results,
      warning: 'IMPORTANT: Remove or protect this endpoint in production!',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Database setup failed',
      error: error.message,
    });
  }
});

module.exports = router;
