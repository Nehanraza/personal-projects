const express = require('express');
const router = express.Router();

const {
  getUsers,
  getUser,
  updateUser,
  deleteUser,
  getMyReferrals,
  getReferralStats,
} = require('../controllers/user.controller');

const { protect, authorize } = require('../middleware/auth');

// All routes require authentication
router.use(protect);

router.get('/my-referrals', getMyReferrals);
router.get('/referral-stats', getReferralStats);

router
  .route('/')
  .get(authorize('admin'), getUsers);

router
  .route('/:id')
  .get(getUser)
  .put(updateUser)
  .delete(deleteUser);

module.exports = router;

