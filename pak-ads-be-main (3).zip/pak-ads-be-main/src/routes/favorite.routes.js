const express = require('express');
const router = express.Router();

const {
  getFavorites,
  addFavorite,
  removeFavorite,
  checkFavorite,
} = require('../controllers/favorite.controller');

const { protect } = require('../middleware/auth');

// All routes require authentication
router.use(protect);

router.get('/', getFavorites);
router.get('/check/:adId', checkFavorite);
router.post('/:adId', addFavorite);
router.delete('/:adId', removeFavorite);

module.exports = router;
