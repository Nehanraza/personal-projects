const express = require('express');
const router = express.Router();

const {
  getAds,
  getAd,
  createAd,
  updateAd,
  deleteAd,
  approveAd,
  rejectAd,
  featureAd,
  getAdStats,
  getMyAds,
} = require('../controllers/ad.controller');

const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/', getAds);

// Protected routes - must come before /:id to avoid route conflicts
router.get('/my-ads', protect, getMyAds);

// Public route for single ad
router.get('/:id', getAd);

// Protected routes
router.use(protect);

router.post('/', createAd);
router.put('/:id', updateAd);
router.delete('/:id', deleteAd);

// Admin only routes
router.get('/admin/stats', authorize('admin'), getAdStats);
router.put('/:id/approve', authorize('admin'), approveAd);
router.put('/:id/reject', authorize('admin'), rejectAd);
router.put('/:id/feature', authorize('admin'), featureAd);

module.exports = router;

