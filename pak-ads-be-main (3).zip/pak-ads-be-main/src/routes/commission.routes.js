/**
 * Commission Routes
 * Defines all routes for commission-related operations
 */

const express = require('express');
const router = express.Router();
const {
  getMyCommissionStats,
  getMyCommissionHistory,
  getMyNetwork,
  previewCommission,
  manuallyDistributeCommission,
  getOverallStats,
  getTopEarners,
  getUserStats,
  getCommissionStructure,
  getDailyCommissionEarnings,
} = require('../controllers/commission.controller');
const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/structure', getCommissionStructure);

// Protected user routes
router.use(protect); // All routes below require authentication

router.get('/my-stats', getMyCommissionStats);
router.get('/my-history', getMyCommissionHistory);
router.get('/my-network', getMyNetwork);
router.get('/daily-earnings', getDailyCommissionEarnings);
router.post('/preview', previewCommission);

// Admin only routes
router.post('/distribute', authorize('admin'), manuallyDistributeCommission);
router.get('/admin/overall-stats', authorize('admin'), getOverallStats);
router.get('/admin/top-earners', authorize('admin'), getTopEarners);
router.get('/admin/user/:userId', authorize('admin'), getUserStats);

module.exports = router;
