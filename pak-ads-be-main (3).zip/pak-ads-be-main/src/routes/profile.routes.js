const express = require('express');
const router = express.Router();

const {
  getUserProfile,
  getUserAds,
  getUserReviews,
} = require('../controllers/profile.controller');

// Public routes
router.get('/:userId', getUserProfile);
router.get('/:userId/ads', getUserAds);
router.get('/:userId/reviews', getUserReviews);

module.exports = router;
