const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  getWalletBalance,
  getEarningsHistory,
  getEarningsSummary,
  getEarningsByLevel,
  getReferralTree,
  requestWithdrawal,
  requestPlanWithdrawal,
  getWithdrawalHistory,
  getPaymentMethods,
  getROIHistory,
} = require('../controllers/wallet.controller');

const router = express.Router();

// All routes require authentication
router.use(protect);
router.use(authorize('user', 'admin'));

// Wallet routes
router.get('/balance', getWalletBalance);
router.get('/earnings', getEarningsHistory);
router.get('/earnings-summary', getEarningsSummary);
router.get('/earnings-by-level/:level', getEarningsByLevel);
router.get('/referral-tree', getReferralTree);
router.get('/roi-history', getROIHistory);

// Withdrawal routes
router.get('/payment-methods', getPaymentMethods);
router.post('/withdraw', requestWithdrawal);
router.post('/plan-withdraw', requestPlanWithdrawal);
router.get('/withdrawals', getWithdrawalHistory);

module.exports = router;

