const express = require('express');
const router = express.Router();

const {
  getMessages,
  getConversation,
  sendMessage,
  markAsRead,
  getUnreadCount,
  deleteMessage,
} = require('../controllers/message.controller');

const { protect } = require('../middleware/auth');

// All routes require authentication
router.use(protect);

router.get('/', getMessages);
router.get('/unread/count', getUnreadCount);
router.get('/conversation/:adId/:userId', getConversation);
router.post('/', sendMessage);
router.put('/:id/read', markAsRead);
router.delete('/:id', deleteMessage);

module.exports = router;

