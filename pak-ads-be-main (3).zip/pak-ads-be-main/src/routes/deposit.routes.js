const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  createDeposit,
  getDeposits,
  getDepositById,
  approveDeposit,
  rejectDeposit,
  getAllDeposits,
  getDepositStats,
} = require('../controllers/deposit.controller');

const router = express.Router();

// All routes require authentication
router.use(protect);

// User routes
router.post('/', upload.single('proofImage'), createDeposit);
router.get('/', getDeposits);
router.get('/:id', getDepositById);

// Admin only routes
router.use(authorize('admin'));
router.get('/admin/all', getAllDeposits);
router.put('/:id/approve', approveDeposit);
router.put('/:id/reject', rejectDeposit);
router.get('/admin/stats', getDepositStats);

module.exports = router;

