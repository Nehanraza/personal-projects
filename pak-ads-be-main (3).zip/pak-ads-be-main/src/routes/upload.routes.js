const express = require('express');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');
const {
  uploadImage,
  deleteImage,
} = require('../controllers/upload.controller');

const router = express.Router();

// All routes require authentication
router.use(protect);

// Upload routes
router.post('/', upload.single('image'), uploadImage);
router.delete('/:filename', deleteImage);

module.exports = router;

