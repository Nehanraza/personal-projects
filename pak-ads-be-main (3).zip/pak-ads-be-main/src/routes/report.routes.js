const express = require('express');
const router = express.Router();

const {
  getReports,
  getReport,
  createReport,
  updateReportStatus,
  deleteReport,
  getReportStats,
} = require('../controllers/report.controller');

const { protect, authorize } = require('../middleware/auth');

// Protected routes
router.use(protect);

// User can create reports
router.post('/', createReport);

// Admin only routes
router.get('/', authorize('admin'), getReports);
router.get('/stats', authorize('admin'), getReportStats);
router.get('/:id', authorize('admin'), getReport);
router.put('/:id/status', authorize('admin'), updateReportStatus);
router.delete('/:id', authorize('admin'), deleteReport);

module.exports = router;

