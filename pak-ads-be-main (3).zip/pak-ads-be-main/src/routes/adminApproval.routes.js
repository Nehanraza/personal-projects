const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  getPendingUsers,
  approveUser,
  rejectUser,
  getApprovedUsers,
  getUserApprovalStats,
} = require('../controllers/adminApproval.controller');

const router = express.Router();

// All admin approval routes require authentication and admin authorization
router.use(protect);
router.use(authorize('admin'));

// Get all pending users for approval
router.get('/pending', getPendingUsers);

// Get all approved users
router.get('/approved', getApprovedUsers);

// Get approval statistics
router.get('/stats', getUserApprovalStats);

// Approve a user
router.put('/:id/approve', approveUser);

// Reject a user
router.put('/:id/reject', rejectUser);

module.exports = router;
