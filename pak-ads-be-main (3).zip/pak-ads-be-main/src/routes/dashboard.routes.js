const express = require('express');
const router = express.Router();

const {
  getUserDashboard,
  getFinancialDashboard,   
  getAdminDashboard,
  getHomePageData,
  getCommissionDashboard,
  getAdminCommissionDashboard,
} = require('../controllers/dashboard.controller');

const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/home', getHomePageData);

// Protected routes
router.get('/stats', protect, getUserDashboard);
router.get('/financial', protect, getFinancialDashboard);
router.get('/commissions', protect, getCommissionDashboard);

// Admin routes
router.get('/admin/stats', protect, authorize('admin'), getAdminDashboard);
router.get('/admin/commissions', protect, authorize('admin'), getAdminCommissionDashboard);

module.exports = router;
