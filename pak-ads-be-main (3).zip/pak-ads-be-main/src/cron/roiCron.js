const cron = require('node-cron');
const { distributeDailyROIEarnings } = require('../utils/earningService');
const logger = require('../config/logger');

/**
 * Initialize ROI distribution cron job
 * Runs every minute to check for users whose 24h timer has expired
 */
const initROICron = () => {
  // schedule runs every minute
  cron.schedule('* * * * *', async () => {
    try {
      logger.info('[roi-cron] Checking for due ROI distributions...');
      const result = await distributeDailyROIEarnings();
      if (result.distributedCount > 0) {
        logger.info(`[roi-cron] Successfully distributed ROI to ${result.distributedCount} users.`);
      }
    } catch (error) {
      logger.error('[roi-cron] Error in background ROI distribution:', error);
    }
  });

  logger.info('⏰ ROI Earnings distribution background service initialized (every minute)');
};

module.exports = {
  initROICron
};
