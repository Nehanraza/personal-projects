/**
 * Detailed User Report with Deposit Status
 */

require('dotenv').config();
const { User, Earning, Deposit, RankReward, DepositReward } = require('./src/models');
const { sequelize } = require('./src/config/database');
const { Op } = require('sequelize');
const constants = require('./src/config/constants');

async function checkUserDetailedReport() {
  try {
    const email = 'faisalcomedychanel@gmail.com';
    const phone = '03497210618';

    console.log('\n' + '='.repeat(80));
    console.log('📊 COMPLETE USER DETAILED REPORT');
    console.log('='.repeat(80) + '\n');

    // Find user
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: email },
          { phone: phone }
        ]
      }
    });

    if (!user) {
      console.log('❌ User not found!');
      return;
    }

    // ========================================
    // BALANCE INFORMATION
    // ========================================
    const currentBalance = parseFloat(user.wallet_balance || 0);
    const totalEarnings = parseFloat(user.total_earnings || 0);
    const totalWithdrawn = parseFloat(user.total_withdrawn || 0);
    const balanceUSD = constants.convertPkrToUsd(currentBalance);
    const earningsUSD = constants.convertPkrToUsd(totalEarnings);
    const withdrawnUSD = constants.convertPkrToUsd(totalWithdrawn);

    console.log('💰 CURRENT BALANCE:');
    console.log('─'.repeat(80));
    console.log(`   Wallet Balance: ${currentBalance.toFixed(2)} PKR (${balanceUSD.toFixed(2)} USD)`);
    console.log(`   Total Earnings: ${totalEarnings.toFixed(2)} PKR (${earningsUSD.toFixed(2)} USD)`);
    console.log(`   Total Withdrawn: ${totalWithdrawn.toFixed(2)} PKR (${withdrawnUSD.toFixed(2)} USD)`);
    console.log('');

    // ========================================
    // REFERRAL STATISTICS
    // ========================================
    console.log('📊 REFERRAL STATISTICS:');
    console.log('─'.repeat(80));

    // Get all direct referrals with their deposit status
    const directReferrals = await User.findAll({
      where: { referred_by: user.id },
      include: [{
        model: Deposit,
        as: 'deposits',
        attributes: ['id', 'status', 'amount', 'created_at'],
        required: false,
      }],
      attributes: ['id', 'name', 'email', 'phone', 'created_at', 'joining_fee_paid'],
      order: [['created_at', 'ASC']]
    });

    const directReferralsCount = directReferrals.length;
    
    // Count referrals with approved deposits
    const referralsWithApproved = directReferrals.filter(ref => {
      return ref.deposits && ref.deposits.some(d => d.status === 'approved');
    });

    const referralsWithoutApproved = directReferrals.filter(ref => {
      return !ref.deposits || !ref.deposits.some(d => d.status === 'approved');
    });

    const approvedDepositCount = referralsWithApproved.length;
    const notApprovedCount = referralsWithoutApproved.length;

    console.log(`   Direct Referrals (Level 1): ${directReferralsCount}`);
    console.log(`   ├─ With Approved Deposits: ${approvedDepositCount}`);
    console.log(`   └─ Without Approved Deposits: ${notApprovedCount}`);
    console.log('');

    // Get indirect referrals count by level
    const levelCounts = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, 1 as level, created_at
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, rt.level + 1, u.created_at
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT level, COUNT(*) as count
      FROM referral_tree
      GROUP BY level
      ORDER BY level;
    `, {
      replacements: { userId: user.id },
      type: sequelize.QueryTypes.SELECT,
    });

    let totalIndirectReferrals = 0;
    console.log('   Indirect Referrals by Level:');
    for (let i = 2; i <= 7; i++) {
      const levelData = levelCounts.find(l => parseInt(l.level) === i);
      const count = levelData ? parseInt(levelData.count) : 0;
      totalIndirectReferrals += count;
      if (count > 0) {
        console.log(`      Level ${i}: ${count} referrals`);
      }
    }

    console.log(`\n   Total Direct Referrals: ${directReferralsCount}`);
    console.log(`   Total Indirect Referrals (Level 2-7): ${totalIndirectReferrals}`);
    console.log(`   Total Network Size: ${directReferralsCount + totalIndirectReferrals}`);
    console.log('');

    // ========================================
    // DIRECT REFERRALS WITH DEPOSIT STATUS
    // ========================================
    console.log('👥 DIRECT REFERRALS DETAILED LIST:');
    console.log('─'.repeat(80));
    
    referralsWithApproved.forEach((ref, idx) => {
      const approvedDeposit = ref.deposits.find(d => d.status === 'approved');
      console.log(`${(idx + 1).toString().padStart(2)}. ✅ ${ref.name} (${ref.email})`);
      console.log(`      Deposit Status: APPROVED (${parseFloat(approvedDeposit.amount).toFixed(2)} PKR)`);
      console.log(`      Joined: ${ref.created_at.toLocaleDateString()}`);
    });

    if (referralsWithoutApproved.length > 0) {
      console.log('\n   Referrals WITHOUT Approved Deposits:');
      referralsWithoutApproved.forEach((ref, idx) => {
        const depositStatus = ref.deposits && ref.deposits.length > 0 
          ? ref.deposits.map(d => d.status).join(', ') 
          : 'No deposit';
        console.log(`${(idx + 1).toString().padStart(2)}. ❌ ${ref.name} (${ref.email})`);
        console.log(`      Deposit Status: ${depositStatus}`);
        console.log(`      Joined: ${ref.created_at.toLocaleDateString()}`);
      });
    }
    console.log('');

    // ========================================
    // EXPECTED VS ACTUAL BALANCE
    // ========================================
    console.log('🧮 BALANCE CALCULATION:');
    console.log('─'.repeat(80));

    const earningsByType = await Earning.findAll({
      where: {
        user_id: user.id,
        status: 'completed'
      },
      attributes: [
        'type',
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['type'],
      raw: true,
    });

    const earningsDetails = {
      referral_commission: { total: 0, count: 0 },
      daily_referral_bonus: { total: 0, count: 0 },
      rank_reward: { total: 0, count: 0 },
      deposit_reward: { total: 0, count: 0 },
      ad_watching: { total: 0, count: 0 },
      lucky_draw_win: { total: 0, count: 0 },
    };

    for (const item of earningsByType) {
      if (earningsDetails[item.type]) {
        earningsDetails[item.type].total = parseFloat(item.total || 0);
        earningsDetails[item.type].count = parseInt(item.count || 0);
      }
    }

    const totalEarningsFromDB = Object.values(earningsDetails).reduce((sum, e) => sum + e.total, 0);
    const expectedBalanceUSD = constants.convertPkrToUsd(totalEarningsFromDB);

    console.log('   Earnings Breakdown:');
    console.log(`      Commission (All Levels): ${earningsDetails.referral_commission.total.toFixed(2)} PKR (${constants.convertPkrToUsd(earningsDetails.referral_commission.total).toFixed(2)} USD)`);
    console.log(`      Daily Bonus:            ${earningsDetails.daily_referral_bonus.total.toFixed(2)} PKR (${constants.convertPkrToUsd(earningsDetails.daily_referral_bonus.total).toFixed(2)} USD)`);
    console.log(`      Deposit Reward:         ${earningsDetails.deposit_reward.total.toFixed(2)} PKR (${constants.convertPkrToUsd(earningsDetails.deposit_reward.total).toFixed(2)} USD)`);
    console.log(`      Rank Reward:            ${earningsDetails.rank_reward.total.toFixed(2)} PKR (${constants.convertPkrToUsd(earningsDetails.rank_reward.total).toFixed(2)} USD)`);
    console.log(`      Ad Watching:            ${earningsDetails.ad_watching.total.toFixed(2)} PKR (${constants.convertPkrToUsd(earningsDetails.ad_watching.total).toFixed(2)} USD)`);
    console.log(`      Spinner:                ${earningsDetails.lucky_draw_win.total.toFixed(2)} PKR (${constants.convertPkrToUsd(earningsDetails.lucky_draw_win.total).toFixed(2)} USD)`);
    console.log(`      ────────────────────────────────────────────────────────────────`);
    console.log(`      EXPECTED BALANCE:       ${totalEarningsFromDB.toFixed(2)} PKR (${expectedBalanceUSD.toFixed(2)} USD)`);
    console.log(`      ACTUAL BALANCE:         ${currentBalance.toFixed(2)} PKR (${balanceUSD.toFixed(2)} USD)`);
    console.log(`      ────────────────────────────────────────────────────────────────`);
    
    const difference = currentBalance - totalEarningsFromDB;
    if (Math.abs(difference) <= 0.01) {
      console.log(`      ✅ BALANCE MATCHES PERFECTLY!`);
    } else {
      console.log(`      ⚠️  Difference: ${difference.toFixed(2)} PKR (${constants.convertPkrToUsd(difference).toFixed(2)} USD)`);
    }
    console.log('');

    // ========================================
    // SUMMARY
    // ========================================
    console.log('📋 SUMMARY:');
    console.log('─'.repeat(80));
    console.log(`   User: ${user.name} (${user.email})`);
    console.log(`   Phone: ${user.phone}`);
    console.log(`   Referral Code: ${user.referral_code}`);
    console.log('');
    console.log(`   💰 BALANCE:`);
    console.log(`      Current: ${currentBalance.toFixed(2)} PKR (${balanceUSD.toFixed(2)} USD)`);
    console.log(`      Expected: ${totalEarningsFromDB.toFixed(2)} PKR (${expectedBalanceUSD.toFixed(2)} USD)`);
    console.log(`      Status: ${Math.abs(difference) <= 0.01 ? '✅ CORRECT' : '⚠️  CHECK REQUIRED'}`);
    console.log('');
    console.log(`   📊 REFERRALS:`);
    console.log(`      Direct: ${directReferralsCount}`);
    console.log(`         ├─ With Approved Deposits: ${approvedDepositCount}`);
    console.log(`         └─ Without Approved Deposits: ${notApprovedCount}`);
    console.log(`      Indirect: ${totalIndirectReferrals} (Level 2-7)`);
    console.log(`      Total Network: ${directReferralsCount + totalIndirectReferrals}`);
    console.log('');

    console.log('='.repeat(80) + '\n');

    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error);
    await sequelize.close();
    process.exit(1);
  }
}

checkUserDetailedReport();

