/**
 * Script to retroactively award missing rank rewards and deposit rewards
 * to users who should have gotten them but didn't
 * 
 * Usage: node award-missing-rewards.js
 */

require('dotenv').config();
const { User, Earning, RankReward, DepositReward, Deposit } = require('./src/models');
const { sequelize } = require('./src/config/database');
const { Op } = require('sequelize');
const constants = require('./src/config/constants');
const { autoAwardRankReward } = require('./src/controllers/rankReward.controller');
const { autoAwardDepositReward } = require('./src/controllers/depositReward.controller');
const { hasApprovedDeposit } = require('./src/utils/depositGuard');

async function awardMissingRewards() {
  try {
    console.log('\n' + '='.repeat(80));
    console.log('🎁 AWARDING MISSING REWARDS TO ALL USERS');
    console.log('='.repeat(80) + '\n');

    // Get all users who have approved deposits
    const users = await User.findAll({
      where: {
        is_active: true,
      },
      include: [{
        model: Deposit,
        as: 'deposits',
        where: { status: 'approved' },
        required: true,
        attributes: ['id'],
      }],
      distinct: true,
    });

    console.log(`Found ${users.length} users with approved deposits to check...\n`);

    let totalRankRewardsAwarded = 0;
    let totalDepositRewardsAwarded = 0;
    let totalRankAmount = 0;
    let totalDepositAmount = 0;
    const usersWithRewards = [];

    for (const user of users) {
      try {
        // Check and award rank rewards
        const rankResult = await autoAwardRankReward(user.id);
        if (rankResult.awarded) {
          totalRankRewardsAwarded += rankResult.ranksAwarded;
          totalRankAmount += rankResult.totalRewardAmount;
          console.log(`✅ User ${user.id} (${user.email}): Awarded ${rankResult.ranksAwarded} rank reward(s) = ${rankResult.totalRewardAmount} PKR`);
          usersWithRewards.push({
            userId: user.id,
            email: user.email,
            rankRewards: rankResult.ranksAwarded,
            rankAmount: rankResult.totalRewardAmount,
          });
        }

        // Check and award deposit rewards
        const depositResult = await autoAwardDepositReward(user.id);
        if (depositResult.awarded) {
          totalDepositRewardsAwarded++;
          totalDepositAmount += depositResult.rewardAmount;
          console.log(`✅ User ${user.id} (${user.email}): Awarded deposit reward = ${depositResult.rewardAmount} PKR`);
          const existingUser = usersWithRewards.find(u => u.userId === user.id);
          if (existingUser) {
            existingUser.depositReward = depositResult.rewardAmount;
          } else {
            usersWithRewards.push({
              userId: user.id,
              email: user.email,
              depositReward: depositResult.rewardAmount,
            });
          }
        }
      } catch (error) {
        console.error(`❌ Error processing user ${user.id} (${user.email}):`, error.message);
      }
    }

    console.log('\n' + '='.repeat(80));
    console.log('📊 SUMMARY');
    console.log('='.repeat(80));
    console.log(`Total Users Processed: ${users.length}`);
    console.log(`Rank Rewards Awarded: ${totalRankRewardsAwarded} (${totalRankAmount.toFixed(2)} PKR)`);
    console.log(`Deposit Rewards Awarded: ${totalDepositRewardsAwarded} (${totalDepositAmount.toFixed(2)} PKR)`);
    console.log(`Total Amount Awarded: ${(totalRankAmount + totalDepositAmount).toFixed(2)} PKR`);
    console.log(`Users Who Received Rewards: ${usersWithRewards.length}`);

    if (usersWithRewards.length > 0) {
      console.log('\nUsers who received rewards:');
      usersWithRewards.forEach(u => {
        console.log(`  - User ${u.userId} (${u.email}):`);
        if (u.rankRewards) {
          console.log(`    Rank Rewards: ${u.rankRewards} = ${u.rankAmount} PKR`);
        }
        if (u.depositReward) {
          console.log(`    Deposit Reward: ${u.depositReward} PKR`);
        }
      });
    }

    console.log('\n' + '='.repeat(80) + '\n');

    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error);
    await sequelize.close();
    process.exit(1);
  }
}

// Run for specific user (for testing)
async function awardRewardsForUser(email) {
  try {
    console.log('\n' + '='.repeat(80));
    console.log(`🎁 AWARDING MISSING REWARDS FOR: ${email}`);
    console.log('='.repeat(80) + '\n');

    const user = await User.findOne({ where: { email } });

    if (!user) {
      console.log('❌ User not found!');
      await sequelize.close();
      return;
    }

    console.log(`User found: ${user.name} (ID: ${user.id})\n`);

    // Check and award rank rewards
    console.log('Checking rank rewards...');
    const rankResult = await autoAwardRankReward(user.id);
    if (rankResult.awarded) {
      console.log(`✅ Awarded ${rankResult.ranksAwarded} rank reward(s) = ${rankResult.totalRewardAmount} PKR`);
      rankResult.ranks.forEach(r => {
        console.log(`   - ${r.name}: ${r.rewardAmount} PKR`);
      });
    } else {
      console.log(`❌ No rank rewards awarded. Reason: ${rankResult.reason}`);
    }

    // Check and award deposit rewards
    console.log('\nChecking deposit rewards...');
    const depositResult = await autoAwardDepositReward(user.id);
    if (depositResult.awarded) {
      console.log(`✅ Awarded deposit reward = ${depositResult.rewardAmount} PKR`);
    } else {
      console.log(`❌ No deposit reward awarded. Reason: ${depositResult.reason}`);
    }

    // Get updated balance
    await user.reload();
    console.log(`\n💰 Updated Balance: ${parseFloat(user.wallet_balance).toFixed(2)} PKR`);
    console.log(`💰 Total Earnings: ${parseFloat(user.total_earnings).toFixed(2)} PKR`);

    console.log('\n' + '='.repeat(80) + '\n');

    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error);
    await sequelize.close();
    process.exit(1);
  }
}

// Check command line arguments
const args = process.argv.slice(2);
if (args.length > 0 && args[0] === '--user' && args[1]) {
  awardRewardsForUser(args[1]);
} else {
  awardMissingRewards();
}

