/**
 * Comprehensive User Balance Verification Script
 * Checks all earnings, calculates expected balance, and identifies discrepancies
 */

require('dotenv').config();
const { User, Earning, RankReward, DepositReward, DailyReferralBonus, Deposit, Transfer, Withdrawal } = require('./src/models');
const { sequelize } = require('./src/config/database');
const { Op } = require('sequelize');
const constants = require('./src/config/constants');

async function verifyUserBalance() {
  try {
    const email = 'faisalcomedychanel@gmail.com';
    const phone = '03497210618';

    console.log('\n========================================');
    console.log('💰 COMPREHENSIVE BALANCE VERIFICATION');
    console.log('========================================\n');

    // Find user
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: email },
          { phone: phone }
        ]
      }
    });

    if (!user) {
      console.log('❌ User not found!');
      return;
    }

    console.log('👤 USER INFO:');
    console.log(`   ID: ${user.id}`);
    console.log(`   Name: ${user.name}`);
    console.log(`   Email: ${user.email}`);
    console.log(`   Phone: ${user.phone}`);
    console.log(`   Created: ${user.created_at}`);

    // Current balance from database
    const currentBalance = parseFloat(user.wallet_balance || 0);
    const totalEarnings = parseFloat(user.total_earnings || 0);
    const totalWithdrawn = parseFloat(user.total_withdrawn || 0);

    console.log(`\n📊 CURRENT BALANCE (from users table):`);
    console.log(`   Wallet Balance: ${currentBalance} PKR (${constants.convertPkrToUsd(currentBalance)} USD)`);
    console.log(`   Total Earnings: ${totalEarnings} PKR`);
    console.log(`   Total Withdrawn: ${totalWithdrawn} PKR`);

    // ========================================
    // 1. EARNINGS BREAKDOWN BY TYPE
    // ========================================
    console.log(`\n📈 EARNINGS BREAKDOWN (from earnings table):`);
    console.log('   ----------------------------------------');

    const earningsByType = await Earning.findAll({
      where: { 
        user_id: user.id,
        status: 'completed'
      },
      attributes: [
        'type',
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['type'],
      order: [[sequelize.fn('SUM', sequelize.col('amount')), 'DESC']],
      raw: true,
    });

    const earningsDetails = {
      referral_commission: { total: 0, count: 0, records: [] },
      daily_referral_bonus: { total: 0, count: 0, records: [] },
      rank_reward: { total: 0, count: 0, records: [] },
      deposit_reward: { total: 0, count: 0, records: [] },
      ad_watching: { total: 0, count: 0, records: [] },
      bonus: { total: 0, count: 0, records: [] },
      lucky_draw_win: { total: 0, count: 0, records: [] },
      refund: { total: 0, count: 0, records: [] },
      deposit: { total: 0, count: 0, records: [] },
    };

    let totalEarningsFromDB = 0;

    for (const item of earningsByType) {
      const total = parseFloat(item.total || 0);
      const count = parseInt(item.count || 0);
      totalEarningsFromDB += total;
      
      if (earningsDetails[item.type]) {
        earningsDetails[item.type].total = total;
        earningsDetails[item.type].count = count;
      }

      console.log(`   ✅ ${item.type.padEnd(25)}: ${total.toFixed(2).padStart(12)} PKR (${count} transactions)`);
    }

    // Get detailed records for each type
    const allEarnings = await Earning.findAll({
      where: {
        user_id: user.id,
        status: 'completed'
      },
      order: [['created_at', 'ASC']]
    });

    for (const earning of allEarnings) {
      if (earningsDetails[earning.type]) {
        earningsDetails[earning.type].records.push({
          id: earning.id,
          amount: parseFloat(earning.amount),
          description: earning.description,
          created_at: earning.created_at,
          level: earning.level,
          metadata: earning.metadata
        });
      }
    }

    console.log(`\n   📊 TOTAL EARNINGS (sum of all completed): ${totalEarningsFromDB.toFixed(2)} PKR`);

    // ========================================
    // 2. DETAILED BREAKDOWN BY ACTIVITY
    // ========================================
    console.log(`\n🔍 DETAILED ACTIVITY BREAKDOWN:\n`);

    // 2a. Referral Commissions
    if (earningsDetails.referral_commission.count > 0) {
      console.log(`   💵 REFERRAL COMMISSIONS (${earningsDetails.referral_commission.count} transactions):`);
      console.log(`      Total: ${earningsDetails.referral_commission.total.toFixed(2)} PKR\n`);
      
      const commissionByLevel = {};
      earningsDetails.referral_commission.records.forEach(record => {
        const level = record.level || 0;
        if (!commissionByLevel[level]) {
          commissionByLevel[level] = { total: 0, count: 0 };
        }
        commissionByLevel[level].total += record.amount;
        commissionByLevel[level].count += 1;
      });

      for (const level of Object.keys(commissionByLevel).sort((a, b) => parseInt(a) - parseInt(b))) {
        console.log(`      Level ${level}: ${commissionByLevel[level].total.toFixed(2)} PKR (${commissionByLevel[level].count} transactions)`);
      }
      console.log('');
    }

    // 2b. Daily Referral Bonus
    if (earningsDetails.daily_referral_bonus.count > 0) {
      console.log(`   🎁 DAILY REFERRAL BONUS (${earningsDetails.daily_referral_bonus.count} transactions):`);
      console.log(`      Total: ${earningsDetails.daily_referral_bonus.total.toFixed(2)} PKR\n`);
      earningsDetails.daily_referral_bonus.records.forEach((record, idx) => {
        console.log(`      ${idx + 1}. ${record.amount.toFixed(2)} PKR - ${record.description || 'Daily bonus'}`);
        console.log(`         Date: ${record.created_at.toLocaleString()}`);
      });
      console.log('');
    }

    // 2c. Rank Rewards
    if (earningsDetails.rank_reward.count > 0) {
      console.log(`   🏆 RANK REWARDS (${earningsDetails.rank_reward.count} transactions):`);
      console.log(`      Total: ${earningsDetails.rank_reward.total.toFixed(2)} PKR\n`);
      
      const rankRewards = await RankReward.findAll({
        where: { user_id: user.id },
        order: [['rank', 'ASC']],
        include: [{
          model: Earning,
          as: 'earning',
          attributes: ['id', 'amount', 'description', 'created_at']
        }]
      });

      rankRewards.forEach(reward => {
        console.log(`      Rank ${reward.rank} (${reward.rank_name}):`);
        console.log(`         Reward: ${parseFloat(reward.reward_amount).toFixed(2)} PKR (${parseFloat(reward.reward_amount_usd)} USD)`);
        console.log(`         Required: ${reward.required_members} members, Actual: ${reward.actual_members}`);
        console.log(`         Claimed: ${reward.claimed_at.toLocaleString()}`);
        if (reward.earning) {
          console.log(`         Earning ID: ${reward.earning.id}, Amount: ${parseFloat(reward.earning.amount).toFixed(2)} PKR`);
        }
        console.log('');
      });
    }

    // 2d. Deposit Reward
    if (earningsDetails.deposit_reward.count > 0) {
      console.log(`   💳 DEPOSIT REWARD (${earningsDetails.deposit_reward.count} transactions):`);
      console.log(`      Total: ${earningsDetails.deposit_reward.total.toFixed(2)} PKR\n`);
      
      const depositRewards = await DepositReward.findAll({
        where: { user_id: user.id },
        include: [{
          model: Earning,
          as: 'earning',
          attributes: ['id', 'amount', 'description', 'created_at']
        }]
      });

      depositRewards.forEach(reward => {
        console.log(`      Deposit Reward:`);
        console.log(`         Reward: ${parseFloat(reward.reward_amount).toFixed(2)} PKR`);
        console.log(`         Referrals: ${reward.referrals_count}`);
        console.log(`         Awarded: ${reward.created_at ? reward.created_at.toLocaleString() : 'N/A'}`);
        if (reward.earning) {
          console.log(`         Earning ID: ${reward.earning.id}, Amount: ${parseFloat(reward.earning.amount).toFixed(2)} PKR`);
          console.log(`         Date: ${reward.earning.created_at ? reward.earning.created_at.toLocaleString() : 'N/A'}`);
        }
        console.log('');
      });
    }

    // 2e. Ad Watching
    if (earningsDetails.ad_watching.count > 0) {
      console.log(`   📺 AD WATCHING (${earningsDetails.ad_watching.count} transactions):`);
      console.log(`      Total: ${earningsDetails.ad_watching.total.toFixed(2)} PKR\n`);
      earningsDetails.ad_watching.records.forEach((record, idx) => {
        console.log(`      ${idx + 1}. ${record.amount.toFixed(2)} PKR - ${record.description || 'Ad watch'}`);
        console.log(`         Date: ${record.created_at.toLocaleString()}`);
      });
      console.log('');
    }

    // 2f. Other earnings
    ['bonus', 'lucky_draw_win', 'refund', 'deposit'].forEach(type => {
      if (earningsDetails[type].count > 0) {
        console.log(`   💰 ${type.toUpperCase().replace('_', ' ')} (${earningsDetails[type].count} transactions):`);
        console.log(`      Total: ${earningsDetails[type].total.toFixed(2)} PKR\n`);
      }
    });

    // ========================================
    // 3. DEDUCTIONS (WITHDRAWALS)
    // ========================================
    console.log(`\n💸 DEDUCTIONS:\n`);

    // Get withdrawals
    const withdrawals = await Earning.findAll({
      where: {
        user_id: user.id,
        type: 'withdrawal',
        status: { [Op.in]: ['completed', 'sent', 'approved'] }
      },
      order: [['created_at', 'ASC']]
    });

    const totalWithdrawalsFromEarnings = withdrawals.reduce((sum, w) => sum + Math.abs(parseFloat(w.amount || 0)), 0);

    if (withdrawals.length > 0) {
      console.log(`   Withdrawals (from earnings table):`);
      withdrawals.forEach((withdrawal, idx) => {
        console.log(`      ${idx + 1}. ${Math.abs(parseFloat(withdrawal.amount)).toFixed(2)} PKR - Status: ${withdrawal.status}`);
        console.log(`         Date: ${withdrawal.created_at.toLocaleString()}`);
      });
      console.log(`      Total Withdrawals: ${totalWithdrawalsFromEarnings.toFixed(2)} PKR\n`);
    } else {
      console.log(`   No withdrawals found.\n`);
    }

    // ========================================
    // 4. CALCULATED EXPECTED BALANCE
    // ========================================
    console.log(`\n🧮 BALANCE CALCULATION:\n`);

    // Expected balance = Total earnings - Total withdrawals
    const expectedBalance = totalEarningsFromDB - totalWithdrawalsFromEarnings;
    const balanceDifference = currentBalance - expectedBalance;

    console.log(`   Total Earnings (completed): ${totalEarningsFromDB.toFixed(2)} PKR`);
    console.log(`   Total Withdrawals:          ${totalWithdrawalsFromEarnings.toFixed(2)} PKR`);
    console.log(`   ────────────────────────────────────────────`);
    console.log(`   Expected Balance:           ${expectedBalance.toFixed(2)} PKR`);
    console.log(`   Actual Balance (DB):        ${currentBalance.toFixed(2)} PKR`);
    console.log(`   Difference:                 ${balanceDifference.toFixed(2)} PKR`);

    // ========================================
    // 5. VERIFICATION & ANALYSIS
    // ========================================
    console.log(`\n✅ VERIFICATION:\n`);

    const tolerance = 0.01; // Allow small rounding differences

    if (Math.abs(balanceDifference) <= tolerance) {
      console.log(`   ✅ BALANCE IS CORRECT!`);
      console.log(`      Expected: ${expectedBalance.toFixed(2)} PKR`);
      console.log(`      Actual: ${currentBalance.toFixed(2)} PKR`);
      console.log(`      Difference: ${balanceDifference.toFixed(2)} PKR (within tolerance)\n`);
    } else {
      console.log(`   ⚠️  BALANCE MISMATCH DETECTED!`);
      console.log(`      Expected: ${expectedBalance.toFixed(2)} PKR`);
      console.log(`      Actual: ${currentBalance.toFixed(2)} PKR`);
      console.log(`      Difference: ${balanceDifference.toFixed(2)} PKR\n`);

      if (balanceDifference > 0) {
        console.log(`   🔍 ANALYSIS:`);
        console.log(`      Actual balance is ${balanceDifference.toFixed(2)} PKR MORE than expected.`);
        console.log(`      Possible reasons:`);
        console.log(`      - Manual balance adjustments`);
        console.log(`      - Transactions not recorded in earnings table`);
        console.log(`      - Pending earnings converted to completed`);
      } else {
        console.log(`   🔍 ANALYSIS:`);
        console.log(`      Actual balance is ${Math.abs(balanceDifference).toFixed(2)} PKR LESS than expected.`);
        console.log(`      Possible reasons:`);
        console.log(`      - Earnings not added to balance`);
        console.log(`      - Balance updated incorrectly`);
        console.log(`      - Missing transactions`);
      }
    }

    // Check total_earnings vs calculated earnings
    const earningsDifference = totalEarnings - totalEarningsFromDB;
    console.log(`\n   Total Earnings Comparison:`);
    console.log(`      users.total_earnings:     ${totalEarnings.toFixed(2)} PKR`);
    console.log(`      Sum from earnings table:  ${totalEarningsFromDB.toFixed(2)} PKR`);
    console.log(`      Difference:               ${earningsDifference.toFixed(2)} PKR`);

    if (Math.abs(earningsDifference) <= tolerance) {
      console.log(`      ✅ Total earnings match!\n`);
    } else {
      console.log(`      ⚠️  Total earnings mismatch!\n`);
    }

    // ========================================
    // 6. SUMMARY
    // ========================================
    console.log(`\n📋 SUMMARY:\n`);
    console.log(`   Current Wallet Balance: ${currentBalance.toFixed(2)} PKR (${constants.convertPkrToUsd(currentBalance)} USD)`);
    console.log(`   Total Earnings:        ${totalEarningsFromDB.toFixed(2)} PKR`);
    console.log(`   Total Withdrawals:     ${totalWithdrawalsFromEarnings.toFixed(2)} PKR`);
    console.log(`   Expected Balance:      ${expectedBalance.toFixed(2)} PKR`);
    console.log(`   Balance Status:        ${Math.abs(balanceDifference) <= tolerance ? '✅ CORRECT' : '⚠️  MISMATCH'}\n`);

    // Breakdown summary
    console.log(`   Earnings by Source:`);
    console.log(`      Referral Commission:  ${earningsDetails.referral_commission.total.toFixed(2)} PKR (${earningsDetails.referral_commission.count} transactions)`);
    console.log(`      Daily Bonus:          ${earningsDetails.daily_referral_bonus.total.toFixed(2)} PKR (${earningsDetails.daily_referral_bonus.count} transactions)`);
    console.log(`      Rank Rewards:         ${earningsDetails.rank_reward.total.toFixed(2)} PKR (${earningsDetails.rank_reward.count} transactions)`);
    console.log(`      Deposit Rewards:      ${earningsDetails.deposit_reward.total.toFixed(2)} PKR (${earningsDetails.deposit_reward.count} transactions)`);
    console.log(`      Ad Watching:          ${earningsDetails.ad_watching.total.toFixed(2)} PKR (${earningsDetails.ad_watching.count} transactions)`);
    console.log(`      Other:                ${(totalEarningsFromDB - earningsDetails.referral_commission.total - earningsDetails.daily_referral_bonus.total - earningsDetails.rank_reward.total - earningsDetails.deposit_reward.total - earningsDetails.ad_watching.total).toFixed(2)} PKR\n`);

    console.log('========================================\n');

    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error);
    await sequelize.close();
    process.exit(1);
  }
}

verifyUserBalance();

