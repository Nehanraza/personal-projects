# Multi-Level Commission System - Quick Setup Guide

## Overview
This guide will help you set up and test the Multi-Level Referral Commission System.

---

## Step 1: Run Database Migrations

```bash
npm run db:migrate
```

This will create:
- Wallet fields in users table (`wallet_balance`, `total_earnings`, `total_withdrawn`)
- New `earnings` table to track all commissions

---

## Step 2: Restart Server

```bash
npm run dev
```

---

## Step 3: Test the Commission System

### A. Register First User (User A)

```bash
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Alice (User A)",
    "email": "alice@test.com",
    "password": "password123"
  }'
```

**Response**:
```json
{
  "success": true,
  "token": "eyJhbGc...",
  "user": {
    "id": 1,
    "name": "Alice (User A)",
    "email": "alice@test.com",
    "referralCode": "ABC12345"  ← SAVE THIS
  }
}
```

**Save User A's referral code and token!**

---

### B. Register Second User (User B) with User A's Code

```bash
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Bob (User B)",
    "email": "bob@test.com",
    "password": "password123",
    "referralCode": "ABC12345"
  }'
```

**Result**:
- User B is created
- User A automatically receives **22 PKR** (Level 1 commission)

**Save User B's referral code too!**

---

### C. Check User A's Wallet

```bash
curl -X GET http://localhost:4000/api/v1/wallet/balance \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected Response**:
```json
{
  "success": true,
  "data": {
    "walletBalance": 22.00,
    "totalEarnings": 22.00,
    "totalWithdrawn": 0.00,
    "totalReferrals": 1,
    "availableBalance": 22.00
  }
}
```

✅ **User A earned 22 PKR!**

---

### D. Register Third User (User C) with User B's Code

```bash
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Charlie (User C)",
    "email": "charlie@test.com",
    "password": "password123",
    "referralCode": "USER_B_REFERRAL_CODE"
  }'
```

**Result when User C registers**:
- User B receives **22 PKR** (Level 1 - direct referral)
- User A receives **9 PKR** (Level 2)

---

### E. Check User A's Updated Wallet

```bash
curl -X GET http://localhost:4000/api/v1/wallet/balance \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected Response**:
```json
{
  "success": true,
  "data": {
    "walletBalance": 31.00,   ← 22 + 9
    "totalEarnings": 31.00,
    "totalReferrals": 1
  }
}
```

✅ **User A now has 31 PKR total (22 from B + 9 from C)**

---

### F. Check User A's Earnings History

```bash
curl -X GET http://localhost:4000/api/v1/wallet/earnings \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected Response**:
```json
{
  "success": true,
  "data": {
    "earnings": [
      {
        "id": 2,
        "amount": 9.00,
        "level": 2,
        "description": "Level 2 referral commission",
        "fromUser": {
          "name": "Charlie (User C)"
        }
      },
      {
        "id": 1,
        "amount": 22.00,
        "level": 1,
        "description": "Level 1 referral commission",
        "fromUser": {
          "name": "Bob (User B)"
        }
      }
    ]
  }
}
```

---

### G. Get Earnings Summary

```bash
curl -X GET http://localhost:4000/api/v1/wallet/earnings-summary \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected Response**:
```json
{
  "success": true,
  "data": {
    "summary": {
      "walletBalance": 31.00,
      "totalEarnings": 31.00
    },
    "earningsByLevel": [
      {
        "level": 1,
        "count": 1,
        "total": 22.00
      },
      {
        "level": 2,
        "count": 1,
        "total": 9.00
      }
    ]
  }
}
```

---

### H. Get Referral Tree

```bash
curl -X GET http://localhost:4000/api/v1/wallet/referral-tree \
  -H "Authorization: Bearer USER_A_TOKEN"
```

**Expected Response**:
```json
{
  "success": true,
  "data": {
    "directReferrals": [
      {
        "name": "Bob (User B)",
        "earnedFromThis": 22.00,
        "totalReferrals": 1
      }
    ],
    "networkSummary": [
      {
        "level": 1,
        "count": 1
      },
      {
        "level": 2,
        "count": 1
      }
    ]
  }
}
```

---

## Testing Full 7-Level Chain

To test all 7 levels, create a chain of users:

```bash
# User A (no referrer)
# User B (referred by A) - A gets 22 PKR
# User C (referred by B) - B gets 22, A gets 9
# User D (referred by C) - C gets 22, B gets 9, A gets 7
# User E (referred by D) - D gets 22, C gets 9, B gets 7, A gets 5
# User F (referred by E) - E gets 22, D gets 9, C gets 7, B gets 5, A gets 4
# User G (referred by F) - F gets 22, E gets 9, D gets 7, C gets 5, B gets 4, A gets 3
# User H (referred by G) - G gets 22, F gets 9, E gets 7, D gets 5, C gets 4, B gets 3, A gets 2
```

**User A's total after all 7 levels**:
22 + 9 + 7 + 5 + 4 + 3 + 2 = **52 PKR**

---

## Verification Checklist

✅ **Automatic commission distribution**
- Register with referral code
- Check referrer's wallet immediately
- Commission should appear automatically

✅ **Multi-level distribution**
- Create 3-level chain (A → B → C)
- When C registers, both A and B should earn
- B gets 22 PKR, A gets 9 PKR

✅ **Correct amounts per level**
- Level 1: 22 PKR
- Level 2: 9 PKR
- Level 3: 7 PKR
- (and so on...)

✅ **Earnings history tracked**
- Check `/api/v1/wallet/earnings`
- Should show all commission records
- Includes `fromUser` information

✅ **Summary calculations correct**
- Total earnings = sum of all commissions
- Wallet balance = total earnings - total withdrawn
- Earnings by level are grouped correctly

✅ **Referral tree accurate**
- Direct referrals listed correctly
- Network summary shows count at each level

---

## API Endpoints Quick Reference

```
# Wallet endpoints
GET  /api/v1/wallet/balance               - Get wallet balance
GET  /api/v1/wallet/earnings              - Get earnings history
GET  /api/v1/wallet/earnings-summary      - Get summary by level
GET  /api/v1/wallet/earnings-by-level/:level - Get specific level earnings
GET  /api/v1/wallet/referral-tree         - Get referral network

# Registration (triggers commission distribution)
POST /api/v1/auth/register                - Register with referralCode
```

---

## Commission Structure Reminder

| Level | Amount |
|-------|--------|
| 1 | 22 PKR |
| 2 | 9 PKR |
| 3 | 7 PKR |
| 4 | 5 PKR |
| 5 | 4 PKR |
| 6 | 3 PKR |
| 7 | 2 PKR |
| **Total** | **52 PKR** |

---

## Common Issues & Solutions

### Issue: User not receiving commission

**Solution**:
1. Check server logs for errors
2. Verify database transaction didn't rollback
3. Query earnings table directly:
```sql
SELECT * FROM earnings WHERE user_id = <USER_ID>;
```

### Issue: Wrong commission amount

**Solution**:
1. Verify the level is calculated correctly
2. Check `commissionLevels` object in `auth.controller.js`
3. Ensure no custom modifications were made

### Issue: Earnings not showing in history

**Solution**:
1. Check if earnings were created: `SELECT * FROM earnings;`
2. Verify user authentication token is correct
3. Check pagination parameters

---

## Database Queries for Testing

### View all earnings
```sql
SELECT 
  e.id,
  e.amount,
  e.level,
  u1.name as earner,
  u2.name as from_user
FROM earnings e
JOIN users u1 ON e.user_id = u1.id
JOIN users u2 ON e.from_user_id = u2.id
ORDER BY e.created_at DESC;
```

### View wallet balances
```sql
SELECT 
  name,
  email,
  wallet_balance,
  total_earnings,
  total_referrals
FROM users
WHERE wallet_balance > 0
ORDER BY wallet_balance DESC;
```

### View referral chains
```sql
WITH RECURSIVE referral_chain AS (
  SELECT id, name, referred_by, 1 as level
  FROM users
  WHERE referred_by IS NULL
  
  UNION ALL
  
  SELECT u.id, u.name, u.referred_by, rc.level + 1
  FROM users u
  JOIN referral_chain rc ON u.referred_by = rc.id
)
SELECT * FROM referral_chain ORDER BY level, id;
```

---

## Next Steps

1. **Test with real data**: Create multiple test users
2. **Frontend integration**: Build wallet dashboard UI
3. **Add withdrawal system**: Allow users to withdraw earnings
4. **Email notifications**: Notify users when they earn commissions
5. **Analytics**: Track commission distribution patterns

---

## Support

For complete documentation:
- `MULTI_LEVEL_COMMISSION_SYSTEM.md` - Full technical documentation
- `AD_WATCHING_REFERRAL_SYSTEM.md` - Ad watching system docs

**Last Updated**: October 8, 2025

