/**
 * Complete User Details Check Script
 * Checks direct/indirect referrals, activities, balance, and calculations
 * 
 * Usage: node check-user-complete-details.js
 */

require('dotenv').config();
const { User, Earning, RankReward, DepositReward, Deposit, AdView } = require('./src/models');
const { sequelize } = require('./src/config/database');
const { Op } = require('sequelize');
const constants = require('./src/config/constants');

async function checkUserCompleteDetails() {
  try {
    const email = 'faisalcomedychanel@gmail.com';
    const phone = '03497210618';

    console.log('\n' + '='.repeat(80));
    console.log('🔍 COMPLETE USER DETAILS REPORT');
    console.log('='.repeat(80) + '\n');

    // Find user
    const user = await User.findOne({
      where: {
        [Op.or]: [
          { email: email },
          { phone: phone }
        ]
      }
    });

    if (!user) {
      console.log('❌ User not found!');
      return;
    }

    // ========================================
    // 1. BASIC USER INFORMATION
    // ========================================
    console.log('👤 USER INFORMATION:');
    console.log('─'.repeat(80));
    console.log(`   ID: ${user.id}`);
    console.log(`   Name: ${user.name}`);
    console.log(`   Email: ${user.email}`);
    console.log(`   Phone: ${user.phone}`);
    console.log(`   Referral Code: ${user.referral_code || 'N/A'}`);
    console.log(`   Referred By: ${user.referred_by || 'None'}`);
    console.log(`   Created At: ${user.created_at}`);
    console.log(`   Joining Fee Paid: ${user.joining_fee_paid ? '✅ Yes' : '❌ No'}`);
    console.log('');

    // ========================================
    // 2. REFERRAL STATISTICS
    // ========================================
    console.log('📊 REFERRAL STATISTICS:');
    console.log('─'.repeat(80));

    // Get direct referrals (Level 1)
    const directReferrals = await User.findAll({
      where: { referred_by: user.id },
      attributes: ['id', 'name', 'email', 'phone', 'created_at', 'joining_fee_paid'],
      order: [['created_at', 'ASC']]
    });

    const directReferralsCount = directReferrals.length;
    console.log(`   Direct Referrals (Level 1): ${directReferralsCount}`);

    // Get referrals with approved deposits (for commission calculation)
    const directReferralsWithApprovedDeposits = await User.findAll({
      where: { referred_by: user.id },
      include: [{
        model: Deposit,
        as: 'deposits',
        where: { status: 'approved' },
        required: false,
        attributes: ['id']
      }],
      attributes: ['id']
    });

    const approvedDepositCount = directReferralsWithApprovedDeposits.filter(
      ref => ref.deposits && ref.deposits.length > 0
    ).length;

    console.log(`   Direct Referrals with Approved Deposits: ${approvedDepositCount}`);

    // Get indirect referrals count by level using recursive query
    const levelCounts = await sequelize.query(`
      WITH RECURSIVE referral_tree AS (
        SELECT id, referred_by, 1 as level, created_at
        FROM users
        WHERE referred_by = :userId
        
        UNION ALL
        
        SELECT u.id, u.referred_by, rt.level + 1, u.created_at
        FROM users u
        INNER JOIN referral_tree rt ON u.referred_by = rt.id
        WHERE rt.level < 7
      )
      SELECT level, COUNT(*) as count
      FROM referral_tree
      GROUP BY level
      ORDER BY level;
    `, {
      replacements: { userId: user.id },
      type: sequelize.QueryTypes.SELECT,
    });

    let totalIndirectReferrals = 0;
    console.log('\n   Indirect Referrals by Level:');
    for (let i = 2; i <= 7; i++) {
      const levelData = levelCounts.find(l => parseInt(l.level) === i);
      const count = levelData ? parseInt(levelData.count) : 0;
      totalIndirectReferrals += count;
      console.log(`      Level ${i}: ${count} referrals`);
    }

    console.log(`\n   Total Direct Referrals: ${directReferralsCount}`);
    console.log(`   Total Indirect Referrals (Level 2-7): ${totalIndirectReferrals}`);
    console.log(`   Total Network Size: ${directReferralsCount + totalIndirectReferrals}`);
    console.log(`   User's total_referrals field: ${user.total_referrals || 0}`);
    console.log('');

    // ========================================
    // 3. WEBSITE ACTIVITIES
    // ========================================
    console.log('🎯 WEBSITE ACTIVITIES:');
    console.log('─'.repeat(80));

    // Ad Watching Activities
    const adViews = await AdView.findAll({
      where: { user_id: user.id },
      order: [['watched_at', 'DESC']],
      limit: 100
    });

    const adWatchingEarnings = await Earning.findAll({
      where: {
        user_id: user.id,
        type: 'ad_watching',
        status: 'completed'
      },
      order: [['created_at', 'ASC']]
    });

    // Separate first and second ads
    const firstAds = adWatchingEarnings.filter(e => {
      try {
        const metadata = e.metadata ? JSON.parse(e.metadata) : {};
        return metadata.ad_type === 'first';
      } catch {
        return false;
      }
    });

    const secondAds = adWatchingEarnings.filter(e => {
      try {
        const metadata = e.metadata ? JSON.parse(e.metadata) : {};
        return metadata.ad_type === 'second';
      } catch {
        return false;
      }
    });

    console.log(`   📺 Ad Watching:`);
    console.log(`      Total Ads Watched: ${adViews.length}`);
    console.log(`      First Ads Watched: ${firstAds.length} (${firstAds.length * constants.AD_WATCHING.FIRST_AD_EARNING} PKR)`);
    console.log(`      Second Ads Watched: ${secondAds.length} (${secondAds.length * constants.AD_WATCHING.SECOND_AD_EARNING} PKR)`);
    console.log(`      Total Ad Earnings: ${adWatchingEarnings.reduce((sum, e) => sum + parseFloat(e.amount), 0).toFixed(2)} PKR`);

    // Deposit Activities
    const deposits = await Deposit.findAll({
      where: { user_id: user.id },
      order: [['created_at', 'DESC']]
    });

    const approvedDeposits = deposits.filter(d => d.status === 'approved');
    const pendingDeposits = deposits.filter(d => d.status === 'pending');
    const rejectedDeposits = deposits.filter(d => d.status === 'rejected');

    console.log(`\n   💳 Deposits:`);
    console.log(`      Total Deposits: ${deposits.length}`);
    console.log(`      Approved: ${approvedDeposits.length}`);
    console.log(`      Pending: ${pendingDeposits.length}`);
    console.log(`      Rejected: ${rejectedDeposits.length}`);

    if (approvedDeposits.length > 0) {
      const totalDepositAmount = approvedDeposits.reduce((sum, d) => sum + parseFloat(d.amount || 0), 0);
      console.log(`      Total Approved Amount: ${totalDepositAmount.toFixed(2)} PKR`);
    }

    // Withdrawal Activities (from Earning table)
    const withdrawals = await Earning.findAll({
      where: {
        user_id: user.id,
        type: 'withdrawal',
        status: { [Op.in]: ['completed', 'pending', 'approved', 'sent'] }
      },
      order: [['created_at', 'DESC']]
    });

    console.log(`\n   💸 Withdrawals:`);
    console.log(`      Total Withdrawals: ${withdrawals.length}`);
    if (withdrawals.length > 0) {
      withdrawals.forEach((w, idx) => {
        console.log(`      ${idx + 1}. ${Math.abs(parseFloat(w.amount)).toFixed(2)} PKR - Status: ${w.status} - Date: ${w.created_at.toLocaleString()}`);
      });
      const totalWithdrawn = withdrawals.reduce((sum, w) => sum + Math.abs(parseFloat(w.amount || 0)), 0);
      console.log(`      Total Withdrawn: ${totalWithdrawn.toFixed(2)} PKR`);
    } else {
      console.log(`      No withdrawals yet`);
    }

    // Lucky Draw/Spinner
    const spinnerWins = await Earning.findAll({
      where: {
        user_id: user.id,
        type: 'lucky_draw_win',
        status: 'completed'
      }
    });

    console.log(`\n   🎰 Lucky Draw/Spinner:`);
    console.log(`      Total Wins: ${spinnerWins.length}`);
    if (spinnerWins.length > 0) {
      const totalSpinnerAmount = spinnerWins.reduce((sum, e) => sum + parseFloat(e.amount), 0);
      console.log(`      Total Spinner Earnings: ${totalSpinnerAmount.toFixed(2)} PKR`);
    }

    console.log('');

    // ========================================
    // 4. CURRENT BALANCE
    // ========================================
    console.log('💰 CURRENT BALANCE:');
    console.log('─'.repeat(80));
    const currentBalance = parseFloat(user.wallet_balance || 0);
    const totalEarnings = parseFloat(user.total_earnings || 0);
    const totalWithdrawn = parseFloat(user.total_withdrawn || 0);

    console.log(`   Wallet Balance: ${currentBalance.toFixed(2)} PKR (${constants.convertPkrToUsd(currentBalance).toFixed(2)} USD)`);
    console.log(`   Total Earnings: ${totalEarnings.toFixed(2)} PKR`);
    console.log(`   Total Withdrawn: ${totalWithdrawn.toFixed(2)} PKR`);
    console.log('');

    // ========================================
    // 5. EARNINGS BREAKDOWN
    // ========================================
    console.log('💵 EARNINGS BREAKDOWN:');
    console.log('─'.repeat(80));

    const earningsByType = await Earning.findAll({
      where: {
        user_id: user.id,
        status: 'completed'
      },
      attributes: [
        'type',
        [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
      ],
      group: ['type'],
      order: [[sequelize.fn('SUM', sequelize.col('amount')), 'DESC']],
      raw: true,
    });

    const earningsDetails = {
      referral_commission: { total: 0, count: 0 },
      daily_referral_bonus: { total: 0, count: 0 },
      rank_reward: { total: 0, count: 0 },
      deposit_reward: { total: 0, count: 0 },
      ad_watching: { total: 0, count: 0 },
      lucky_draw_win: { total: 0, count: 0 },
      bonus: { total: 0, count: 0 },
      refund: { total: 0, count: 0 },
      deposit: { total: 0, count: 0 },
    };

    let totalEarningsFromDB = 0;

    for (const item of earningsByType) {
      const total = parseFloat(item.total || 0);
      const count = parseInt(item.count || 0);
      totalEarningsFromDB += total;

      if (earningsDetails[item.type]) {
        earningsDetails[item.type].total = total;
        earningsDetails[item.type].count = count;
      }

      console.log(`   ${item.type.padEnd(25)}: ${total.toFixed(2).padStart(12)} PKR (${count} transactions)`);
    }

    console.log(`\n   Total Earnings (sum): ${totalEarningsFromDB.toFixed(2)} PKR`);
    console.log('');

    // Commission breakdown by level
    if (earningsDetails.referral_commission.count > 0) {
      const commissionsByLevel = await Earning.findAll({
        where: {
          user_id: user.id,
          type: 'referral_commission',
          status: 'completed'
        },
        attributes: [
          'level',
          [sequelize.fn('SUM', sequelize.col('amount')), 'total'],
          [sequelize.fn('COUNT', sequelize.col('id')), 'count'],
        ],
        group: ['level'],
        order: [['level', 'ASC']],
        raw: true,
      });

      console.log('   Commission Breakdown by Level:');
      commissionsByLevel.forEach(item => {
        console.log(`      Level ${item.level}: ${parseFloat(item.total).toFixed(2)} PKR (${item.count} transactions)`);
      });
      console.log('');
    }

    // ========================================
    // 6. EXPECTED BALANCE CALCULATION
    // ========================================
    console.log('🧮 EXPECTED BALANCE CALCULATION:');
    console.log('─'.repeat(80));

    // 1. Commission from deposits (Level 1 only, 175 PKR per approved deposit)
    const commissionFromDeposits = approvedDepositCount * 175;
    console.log(`   1. Commission from Deposits (Level 1):`);
    console.log(`      ${approvedDepositCount} approved deposits × 175 PKR = ${commissionFromDeposits.toFixed(2)} PKR`);

    // 2. Daily Referral Bonus
    // Logic: 3 refs = 283 PKR, 6 refs = 566 PKR total, 8 refs = 849 PKR total
    let dailyBonusAmount = 0;
    const cappedReferrals = Math.min(directReferralsCount, 8);
    if (cappedReferrals >= 8) {
      dailyBonusAmount = 849; // 3 bonuses
    } else if (cappedReferrals >= 6) {
      dailyBonusAmount = 566; // 2 bonuses
    } else if (cappedReferrals >= 3) {
      dailyBonusAmount = 283; // 1 bonus
    }
    console.log(`\n   2. Daily Referral Bonus:`);
    console.log(`      ${directReferralsCount} direct referrals (capped at 8)`);
    if (cappedReferrals >= 8) {
      console.log(`      8 referrals = 3 bonuses = 849 PKR`);
    } else if (cappedReferrals >= 6) {
      console.log(`      6 referrals = 2 bonuses = 566 PKR`);
    } else if (cappedReferrals >= 3) {
      console.log(`      3 referrals = 1 bonus = 283 PKR`);
    } else {
      console.log(`      Less than 3 referrals = 0 PKR`);
    }
    console.log(`      Expected: ${dailyBonusAmount.toFixed(2)} PKR`);

    // 3. Rank Rewards
    const rankRewards = await RankReward.findAll({
      where: { user_id: user.id },
      include: [{
        model: Earning,
        as: 'earning',
        attributes: ['id', 'amount', 'status']
      }]
    });

    let rankRewardAmount = 0;
    console.log(`\n   3. Rank Rewards:`);
    if (rankRewards.length > 0) {
      rankRewards.forEach(r => {
        const amount = parseFloat(r.reward_amount);
        rankRewardAmount += amount;
        console.log(`      Rank ${r.rank} (${r.rank_name}): ${amount.toFixed(2)} PKR - ${r.actual_members} members`);
      });
    } else {
      console.log(`      No rank rewards claimed yet`);
      // Check eligible ranks
      const ranks = constants.RANK_REWARDS;
      for (const [rankNumber, rankData] of Object.entries(ranks)) {
        if (directReferralsCount >= rankData.members) {
          console.log(`      ⚠️  Eligible for Rank ${rankNumber} but not claimed: ${rankData.rewardPKR} PKR`);
        }
      }
    }
    console.log(`      Total: ${rankRewardAmount.toFixed(2)} PKR`);

    // 4. Deposit Rewards
    const depositRewards = await DepositReward.findAll({
      where: { user_id: user.id },
      include: [{
        model: Earning,
        as: 'earning',
        attributes: ['id', 'amount', 'status']
      }]
    });

    let depositRewardAmount = 0;
    console.log(`\n   4. Deposit Rewards:`);
    if (depositRewards.length > 0) {
      depositRewards.forEach(r => {
        const amount = parseFloat(r.reward_amount);
        depositRewardAmount += amount;
        console.log(`      Deposit Reward: ${amount.toFixed(2)} PKR - ${r.referrals_count} referrals`);
      });
    } else {
      console.log(`      No deposit rewards claimed yet`);
      if (directReferralsCount >= 15 && approvedDeposits.length > 0) {
        console.log(`      ⚠️  Eligible for deposit reward (15+ referrals) but not claimed: 566 PKR`);
      }
    }
    console.log(`      Total: ${depositRewardAmount.toFixed(2)} PKR`);

    // 5. Ad Watching Earnings
    const firstAdEarnings = firstAds.length * constants.AD_WATCHING.FIRST_AD_EARNING;
    const secondAdEarnings = secondAds.length * constants.AD_WATCHING.SECOND_AD_EARNING;
    const totalAdEarnings = firstAdEarnings + secondAdEarnings;

    console.log(`\n   5. Ad Watching Earnings:`);
    console.log(`      First Ads: ${firstAds.length} × ${constants.AD_WATCHING.FIRST_AD_EARNING} PKR = ${firstAdEarnings.toFixed(2)} PKR`);
    console.log(`      Second Ads: ${secondAds.length} × ${constants.AD_WATCHING.SECOND_AD_EARNING} PKR = ${secondAdEarnings.toFixed(2)} PKR`);
    console.log(`      Total: ${totalAdEarnings.toFixed(2)} PKR`);

    // 6. Other Earnings (Spinner, Bonus, etc.)
    const otherEarnings = earningsDetails.lucky_draw_win.total + earningsDetails.bonus.total + earningsDetails.refund.total;
    console.log(`\n   6. Other Earnings (Spinner, Bonus, Refund):`);
    console.log(`      Total: ${otherEarnings.toFixed(2)} PKR`);

    // Calculate expected balance
    // Note: Commission includes all levels (not just Level 1), so we use actual earnings from DB
    const totalCommissionEarned = earningsDetails.referral_commission.total;
    const expectedBalance = totalCommissionEarned + earningsDetails.daily_referral_bonus.total + 
                           earningsDetails.rank_reward.total + earningsDetails.deposit_reward.total + 
                           earningsDetails.ad_watching.total + otherEarnings;
    
    // Also calculate based on Level 1 only for comparison
    const expectedBalanceLevel1Only = commissionFromDeposits + dailyBonusAmount + rankRewardAmount + 
                                      depositRewardAmount + totalAdEarnings + otherEarnings;

    console.log(`\n   ────────────────────────────────────────────────────────────────`);
    console.log(`   Expected Balance Calculation (Based on Actual Earnings):`);
    console.log(`      Commission (All Levels): ${totalCommissionEarned.toFixed(2).padStart(12)} PKR`);
    console.log(`      Daily Bonus:            ${earningsDetails.daily_referral_bonus.total.toFixed(2).padStart(12)} PKR`);
    console.log(`      Rank Rewards:           ${earningsDetails.rank_reward.total.toFixed(2).padStart(12)} PKR`);
    console.log(`      Deposit Rewards:        ${earningsDetails.deposit_reward.total.toFixed(2).padStart(12)} PKR`);
    console.log(`      Ad Watching:            ${earningsDetails.ad_watching.total.toFixed(2).padStart(12)} PKR`);
    console.log(`      Other Earnings:         ${otherEarnings.toFixed(2).padStart(12)} PKR`);
    console.log(`      ────────────────────────────────────────────────────────────────`);
    console.log(`      EXPECTED BALANCE:       ${expectedBalance.toFixed(2).padStart(12)} PKR`);
    console.log(`      ACTUAL BALANCE:         ${currentBalance.toFixed(2).padStart(12)} PKR`);
    console.log(`      ────────────────────────────────────────────────────────────────`);
    
    const difference = currentBalance - expectedBalance;
    if (Math.abs(difference) <= 0.01) {
      console.log(`      ✅ BALANCE MATCHES PERFECTLY!`);
    } else if (difference > 0) {
      console.log(`      ⚠️  Balance is ${difference.toFixed(2)} PKR MORE than expected`);
      console.log(`      (This could be due to: additional commissions, manual adjustments, or pending transactions)`);
    } else {
      console.log(`      ⚠️  Balance is ${Math.abs(difference).toFixed(2)} PKR LESS than expected`);
      console.log(`      (This could indicate missing earnings or balance not updated)`);
    }
    
    console.log(`\n   ────────────────────────────────────────────────────────────────`);
    console.log(`   Note: Expected balance includes ALL commission levels (Level 1-5)`);
    console.log(`   Level 1 Only Calculation: ${expectedBalanceLevel1Only.toFixed(2)} PKR`);
    console.log(`   (This shows what balance would be if only Level 1 commissions counted)`);
    console.log('');

    // ========================================
    // 7. SUMMARY
    // ========================================
    console.log('📋 SUMMARY:');
    console.log('─'.repeat(80));
    console.log(`   User: ${user.name} (${user.email})`);
    console.log(`   Direct Referrals: ${directReferralsCount}`);
    console.log(`   Indirect Referrals: ${totalIndirectReferrals}`);
    console.log(`   Total Network: ${directReferralsCount + totalIndirectReferrals}`);
    console.log(`   Current Balance: ${currentBalance.toFixed(2)} PKR (${constants.convertPkrToUsd(currentBalance).toFixed(2)} USD)`);
    console.log(`   Expected Balance: ${expectedBalance.toFixed(2)} PKR (${constants.convertPkrToUsd(expectedBalance).toFixed(2)} USD)`);
    console.log(`   Balance Status: ${Math.abs(difference) <= 0.01 ? '✅ CORRECT' : '⚠️  MISMATCH'}`);
    console.log('');

    // List direct referrals
    if (directReferrals.length > 0) {
      console.log('   Direct Referrals List:');
      directReferrals.forEach((ref, idx) => {
        console.log(`      ${idx + 1}. ${ref.name} (${ref.email}) - Joined: ${ref.created_at.toLocaleDateString()} - Fee Paid: ${ref.joining_fee_paid ? 'Yes' : 'No'}`);
      });
      console.log('');
    }

    console.log('='.repeat(80) + '\n');

    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error);
    await sequelize.close();
    process.exit(1);
  }
}

checkUserCompleteDetails();

