const { User } = require('./src/models');

// Check the OTP for a user
const checkOTP = async () => {
  try {
    const user = await User.findOne({ 
      where: { email: 'saifuddinqazi3@gmail.com' },
      attributes: ['email', 'reset_password_token', 'reset_password_expire']
    });
    
    if (user) {
      console.log('📧 User Email:', user.email);
      console.log('🔑 Reset OTP:', user.reset_password_token);
      console.log('⏰ OTP Expires:', user.reset_password_expire);
      console.log('✅ OTP Valid:', new Date() < new Date(user.reset_password_expire));
    } else {
      console.log('❌ User not found');
    }
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
};

checkOTP();
