# Vercel Deployment Checklist

Use this checklist to ensure a successful deployment to Vercel.

## Pre-Deployment

- [ ] **Create PostgreSQL Database**
  - [ ] Sign up for Neon.tech, Supabase, or Railway
  - [ ] Create new database
  - [ ] Save connection credentials

- [ ] **Get Cloudinary Account**
  - [ ] Sign up at cloudinary.com
  - [ ] Get Cloud Name, API Key, and API Secret from dashboard

- [ ] **Generate JWT Secret**
  - [ ] Generate a random string (at least 32 characters)
  - [ ] Example: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

## Vercel Setup

- [ ] **Create Vercel Account**
  - [ ] Sign up at vercel.com
  - [ ] Connect your Git provider (GitHub/GitLab/Bitbucket)

- [ ] **Import Project**
  - [ ] Go to vercel.com/new
  - [ ] Import your repository
  - [ ] Framework: Other
  - [ ] Click Deploy (initial deployment)

## Environment Variables

Copy all variables from `.env.vercel.example` to Vercel:
**Settings → Environment Variables**

### Required Variables (Must Have)
- [ ] `NODE_ENV=production`
- [ ] `DB_HOST` (from your database provider)
- [ ] `DB_USERNAME` (from your database provider)
- [ ] `DB_PASSWORD` (from your database provider)
- [ ] `DB_DATABASE` (from your database provider)
- [ ] `DB_PORT=5432`
- [ ] `DB_CONNECTION=postgres`
- [ ] `JWT_SECRET` (your generated secret)
- [ ] `CLOUDINARY_CLOUD_NAME` (from Cloudinary)
- [ ] `CLOUDINARY_API_KEY` (from Cloudinary)
- [ ] `CLOUDINARY_API_SECRET` (from Cloudinary)

### Recommended Variables
- [ ] `APP_URL` (your Vercel deployment URL)
- [ ] `CORS_ORIGIN=*` (or your frontend domain)
- [ ] `JWT_EXPIRE=30d`
- [ ] `JWT_COOKIE_EXPIRE=30`
- [ ] `LOG_LEVEL=info`

### Optional Variables (Email)
- [ ] `SMTP_HOST`
- [ ] `SMTP_PORT`
- [ ] `SMTP_EMAIL`
- [ ] `SMTP_PASSWORD`
- [ ] `FROM_EMAIL`
- [ ] `FROM_NAME`

## Redeploy After Adding Variables

- [ ] **Trigger Redeploy**
  - [ ] Go to Deployments tab
  - [ ] Click "..." on latest deployment
  - [ ] Click "Redeploy"
  - [ ] Wait for deployment to complete

## Database Setup

Choose ONE method:

### Method 1: Setup Endpoint (Easiest)
- [ ] Visit: `https://your-project.vercel.app/api/v1/setup-database`
- [ ] Check response shows success
- [ ] **IMPORTANT**: Remove this endpoint after use (see below)

### Method 2: Local Migration
- [ ] Create `.env.production` with cloud database credentials
- [ ] Run `node src/database/migrate.js`
- [ ] Run `node src/database/seeders/index.js`

## Testing

- [ ] **Test Health Endpoint**
  ```bash
  curl https://your-project.vercel.app/health
  ```
  Expected: `{"success": true, "message": "Pak Ads is running"}`

- [ ] **Test API Root**
  ```bash
  curl https://your-project.vercel.app/api/v1/
  ```
  Expected: JSON with endpoints list

- [ ] **Test Login**
  ```bash
  curl -X POST https://your-project.vercel.app/api/v1/auth/login \
    -H "Content-Type: application/json" \
    -d '{"email":"admin@pakads.com","password":"admin123"}'
  ```
  Expected: Token response

- [ ] **Test in Postman/Thunder Client**
  - [ ] Import API collection
  - [ ] Update base URL to Vercel URL
  - [ ] Test key endpoints

## Security & Cleanup

- [ ] **Remove Setup Endpoint** (if you used Method 1)
  - [ ] Edit `src/routes/index.js`
  - [ ] Remove or comment out the `/setup-database` route
  - [ ] Commit and push changes
  - [ ] Vercel will auto-redeploy

- [ ] **Update CORS** (if you have a specific frontend)
  - [ ] Change `CORS_ORIGIN` from `*` to your frontend domain
  - [ ] Example: `https://your-frontend.vercel.app`
  - [ ] Redeploy

- [ ] **Verify Logs**
  - [ ] Go to https://vercel.com/your-project/logs
  - [ ] Check for any errors
  - [ ] Verify database connections work

## Production Optimization

- [ ] **Custom Domain** (optional)
  - [ ] Go to Settings → Domains
  - [ ] Add your domain
  - [ ] Update DNS records
  - [ ] Update `APP_URL` environment variable

- [ ] **Enable Vercel Analytics** (optional)
  - [ ] Go to Analytics tab
  - [ ] Enable analytics

- [ ] **Set up Monitoring** (optional)
  - [ ] UptimeRobot for uptime monitoring
  - [ ] Sentry for error tracking
  - [ ] LogRocket for session replay

- [ ] **Configure CI/CD** (if not auto-enabled)
  - [ ] Ensure automatic deployments on git push
  - [ ] Configure branch deployments (preview for dev, production for main)

## Frontend Integration

- [ ] **Update Frontend API URL**
  - [ ] Change API base URL to: `https://your-project.vercel.app/api/v1`
  - [ ] Update all API calls
  - [ ] Test frontend integration

- [ ] **Test File Uploads**
  - [ ] Upload an image through your frontend
  - [ ] Verify it uploads to Cloudinary
  - [ ] Verify URL is returned correctly

## Documentation

- [ ] **Update README**
  - [ ] Add production URL
  - [ ] Update API documentation
  - [ ] Document environment setup

- [ ] **Share with Team**
  - [ ] Share Vercel project URL
  - [ ] Share API documentation
  - [ ] Share login credentials (securely)

## Troubleshooting

If something doesn't work:

1. **Check Vercel Logs**
   - Visit: https://vercel.com/your-project/logs
   - Look for error messages

2. **Verify Environment Variables**
   - Settings → Environment Variables
   - Ensure all required variables are set
   - Check for typos

3. **Database Connection**
   - Test connection from your database provider's console
   - Verify credentials are correct
   - Check database allows external connections

4. **Redeploy**
   - Sometimes a fresh deployment fixes issues
   - Deployments → Redeploy

## Success Criteria

Your deployment is successful when:

- [ ] Health check returns 200 OK
- [ ] API root returns endpoints list
- [ ] Login works with admin credentials
- [ ] Database queries work (try fetching categories/locations)
- [ ] File upload works (test with image upload)
- [ ] No errors in Vercel logs
- [ ] Frontend can connect to API

---

## Quick Commands Reference

```bash
# Generate JWT Secret
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Test health
curl https://your-project.vercel.app/health

# Test login
curl -X POST https://your-project.vercel.app/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@pakads.com","password":"admin123"}'

# Deploy with Vercel CLI
vercel --prod

# Pull environment variables locally
vercel env pull
```

---

**Congratulations! Your app is deployed! 🎉**

Need help? Check:
- `VERCEL_DEPLOYMENT_GUIDE.md` - Detailed guide
- `VERCEL_QUICK_START.md` - Quick start guide
- Vercel Docs: https://vercel.com/docs
- Vercel Discord: https://vercel.com/discord

