# Commission System - Quick Reference Guide

## 🎯 Commission Structure at a Glance

| Level | PKR Amount | Percentage | Who Gets It |
|-------|-----------|-----------|-------------|
| 1 | 22 | 44% | Direct referrer |
| 2 | 9 | 18% | Referrer's referrer |
| 3 | 7 | 14% | Level 3 upline |
| 4 | 5 | 10% | Level 4 upline |
| 5 | 4 | 8% | Level 5 upline |
| 6 | 3 | 6% | Level 6 upline |
| 7 | 2 | 4% | Level 7 upline |

**Total Distributed:** 52 PKR (104% of 50 PKR base)

---

## 📡 Key API Endpoints

### User Endpoints

```bash
# Get my commission stats
GET /api/v1/commissions/my-stats

# Get my commission history (paginated)
GET /api/v1/commissions/my-history?page=1&limit=20&level=1

# Get my referral network
GET /api/v1/commissions/my-network?levels=7

# Preview commission distribution
POST /api/v1/commissions/preview
{
  "fromUserId": 123,
  "baseAmount": 650,
  "calculationType": "percentage"
}

# Get daily commission earnings
GET /api/v1/commissions/daily-earnings?days=30

# Get commission structure (Public)
GET /api/v1/commissions/structure
```

### Admin Endpoints

```bash
# Get overall statistics
GET /api/v1/commissions/admin/overall-stats?startDate=2024-01-01&endDate=2024-12-31

# Get top earners
GET /api/v1/commissions/admin/top-earners?limit=10

# Get specific user stats
GET /api/v1/commissions/admin/user/:userId

# Manually distribute commission
POST /api/v1/commissions/distribute
{
  "fromUserId": 123,
  "baseAmount": 650,
  "activityType": "manual",
  "calculationType": "percentage"
}
```

### Dashboard Endpoints

```bash
# User commission dashboard
GET /api/v1/dashboard/commissions

# Admin commission dashboard
GET /api/v1/dashboard/admin/commissions
```

---

## 💻 Code Usage Examples

### 1. Distribute Commission on Joining Fee (Already Implemented)

```javascript
// In auth.controller.js - Already integrated
const commissionService = require('../utils/commissionService');

if (referrerId) {
  const joiningFeeAmount = constants.CURRENCY.JOINING_FEE_PKR; // 650 PKR
  await commissionService.distributeJoiningFeeCommission(
    user.id, 
    joiningFeeAmount
  );
}
```

### 2. Distribute Commission on Ad Watching

```javascript
const { distributeAdWatchingCommission } = require('../utils/commissionService');

// After user watches ad and earns 50 PKR
try {
  const result = await distributeAdWatchingCommission(userId, 50);
  console.log(`Distributed ${result.totalDistributed} PKR to ${result.recipients} users`);
} catch (error) {
  console.error('Commission distribution failed:', error);
}
```

### 3. Distribute Commission on Purchase

```javascript
const { distributePurchaseCommission } = require('../utils/commissionService');

const result = await distributePurchaseCommission(
  userId,
  purchaseAmount,
  { orderId: order.id, productName: product.name }
);
```

### 4. Get User Commission Stats

```javascript
const { getUserCommissionStats } = require('../utils/commissionService');

const stats = await getUserCommissionStats(userId);
// Returns: totalCommissionEarned, totalCommissions, directReferrals, byLevel, etc.
```

### 5. Preview Commission Before Distribution

```javascript
const { previewCommissionDistribution } = require('../utils/commissionService');

const preview = await previewCommissionDistribution(userId, 650, 'percentage');
// Returns preview without actually distributing
```

---

## 🔧 Configuration

### Update Commission Percentages

Edit `src/config/constants.js`:

```javascript
COMMISSION_LEVELS: {
  1: { amount: 22, ratio: 0.44, percentage: 44 },
  2: { amount: 9, ratio: 0.18, percentage: 18 },
  3: { amount: 7, ratio: 0.14, percentage: 14 },
  4: { amount: 5, ratio: 0.10, percentage: 10 },
  5: { amount: 4, ratio: 0.08, percentage: 8 },
  6: { amount: 3, ratio: 0.06, percentage: 6 },
  7: { amount: 2, ratio: 0.04, percentage: 4 },
},
```

---

## 📊 Database Schema

### Earnings Table (Commissions)

```sql
earnings
├── id                  INT (Primary Key)
├── user_id            INT (Who earned)
├── from_user_id       INT (Who triggered)
├── amount             DECIMAL(12,2)
├── level              INT (1-7)
├── type               ENUM ('referral_commission', ...)
├── description        VARCHAR
├── status             ENUM ('completed', 'pending', 'cancelled')
├── metadata           TEXT (JSON)
├── created_at         TIMESTAMP
└── updated_at         TIMESTAMP
```

### Users Table (Referral Fields)

```sql
users
├── referred_by        INT (Referrer's ID)
├── referral_code      VARCHAR (Unique)
└── total_referrals    INT
```

---

## 🧪 Testing Examples

### Test 1: Simple Chain (3 Levels)

```
User A → User B → User C → NEW USER (650 PKR joining fee)

Expected Commissions:
- User C: 650 × 0.44 = 286 PKR (Level 1)
- User B: 650 × 0.18 = 117 PKR (Level 2)
- User A: 650 × 0.14 = 91 PKR (Level 3)
Total: 494 PKR
```

### Test 2: Maximum Chain (7 Levels)

```
A → B → C → D → E → F → G → NEW USER (650 PKR)

Expected Commissions:
- G: 286 PKR (Level 1, 44%)
- F: 117 PKR (Level 2, 18%)
- E: 91 PKR (Level 3, 14%)
- D: 65 PKR (Level 4, 10%)
- C: 52 PKR (Level 5, 8%)
- B: 39 PKR (Level 6, 6%)
- A: 26 PKR (Level 7, 4%)
Total: 676 PKR
```

### Test 3: No Referrer

```
NEW USER (no referral code)
Expected: No commissions distributed
```

---

## 🚀 Quick Start Integration

### Step 1: Import Service

```javascript
const commissionService = require('../utils/commissionService');
```

### Step 2: Call Distribution Function

```javascript
// On any earning event
const result = await commissionService.distributeCommission(
  userId,           // User who earned
  amount,           // Base amount
  'activity_type',  // Type: joining_fee, ad_watching, purchase, etc.
  'percentage',     // Or 'fixed'
  { transaction }   // Optional: pass existing transaction
);
```

### Step 3: Handle Result

```javascript
if (result.distributed) {
  console.log(`✅ Distributed ${result.totalDistributed} PKR to ${result.recipients} users`);
  console.log(result.details); // Array of {userId, level, amount}
} else {
  console.log(`ℹ️ ${result.message}`); // e.g., "No upline found"
}
```

---

## 🔍 Useful Queries

### Get User's Total Commission Earnings

```sql
SELECT SUM(amount) as total_commission
FROM earnings
WHERE user_id = ? AND type = 'referral_commission' AND status = 'completed';
```

### Get Commission Breakdown by Level

```sql
SELECT level, COUNT(*) as count, SUM(amount) as total
FROM earnings
WHERE user_id = ? AND type = 'referral_commission'
GROUP BY level
ORDER BY level;
```

### Find Top Commission Earners

```sql
SELECT u.name, SUM(e.amount) as total_earned
FROM users u
JOIN earnings e ON u.id = e.user_id
WHERE e.type = 'referral_commission'
GROUP BY u.id, u.name
ORDER BY total_earned DESC
LIMIT 10;
```

---

## ⚡ Common Operations

### Check If User Has Upline

```javascript
const { getUplineChain } = require('../utils/commissionService');
const upline = await getUplineChain(userId);
console.log(`User has ${upline.length} levels of upline`);
```

### Get Commission Structure

```javascript
const { COMMISSION_LEVELS } = require('../config/constants');
console.log(COMMISSION_LEVELS[1]); // { amount: 22, ratio: 0.44, percentage: 44 }
```

### Calculate Expected Commission

```javascript
const { calculateCommissionForLevel } = require('../utils/commissionService');
const commission = calculateCommissionForLevel(650, 1, 'percentage');
console.log(`Level 1 commission: ${commission} PKR`); // 286 PKR
```

---

## 🛠️ Troubleshooting

### Issue: No commissions distributed
✅ **Check:** User has `referred_by` field set
✅ **Check:** Referrer exists in database
✅ **Check:** Commission service is imported

### Issue: Wrong amounts
✅ **Check:** `COMMISSION_LEVELS` in constants.js
✅ **Check:** `calculationType` parameter (percentage vs fixed)
✅ **Check:** Base amount passed to function

### Issue: Missing commissions in history
✅ **Check:** `type = 'referral_commission'` in earnings table
✅ **Check:** Status is 'completed'
✅ **Check:** Transaction didn't roll back

---

## 📱 Response Examples

### Successful Distribution

```json
{
  "success": true,
  "distributed": true,
  "message": "Commission distributed successfully",
  "totalDistributed": 676.00,
  "recipients": 7,
  "details": [
    {
      "userId": 10,
      "userName": "John Doe",
      "level": 1,
      "amount": 286.00,
      "earningId": 1234
    }
  ]
}
```

### No Upline

```json
{
  "success": true,
  "distributed": false,
  "message": "No upline found for commission distribution",
  "totalDistributed": 0,
  "recipients": 0
}
```

---

## 📚 Related Files

- **Service:** `src/utils/commissionService.js`
- **Controller:** `src/controllers/commission.controller.js`
- **Routes:** `src/routes/commission.routes.js`
- **Constants:** `src/config/constants.js`
- **Model:** `src/models/Earning.js`
- **User Model:** `src/models/User.js`

---

## 🎓 Best Practices

1. ✅ Always use transactions for commission distribution
2. ✅ Don't fail main operations if commission distribution fails
3. ✅ Log all commission distributions for audit
4. ✅ Validate user exists before distributing
5. ✅ Use percentage-based for scalability
6. ✅ Preview before distributing for testing
7. ✅ Check user's upline exists before attempting distribution

---

## 📞 Quick Support

For detailed information, see `COMMISSION_SYSTEM_DOCUMENTATION.md`

For API testing, see `API_DOCUMENTATION.md`

---

**Version:** 1.0.0  
**Last Updated:** October 2024


