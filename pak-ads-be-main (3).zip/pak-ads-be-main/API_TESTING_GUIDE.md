# Complete API Testing Guide - Pak Ads Backend

This document provides step-by-step testing instructions for all 82 API endpoints.

---

## 🔧 Prerequisites

### 1. Start the Server

```bash
# Make sure database is running
# PostgreSQL should be running on port 5432

# Start the backend server
npm run dev

# Server should be running on: http://localhost:4000
```

### 2. Verify Health Check

```bash
curl http://localhost:4000/health
```

Expected response:
```json
{
  "success": true,
  "message": "NodePakAds is running",
  "environment": "development",
  "timestamp": "2024-10-08T..."
}
```

---

## ✅ Testing Flow

I recommend testing in this order to build upon successful operations.

---

## 1️⃣ Authentication APIs (8 endpoints)

### Test 1.1: Register User

```bash
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "password": "test123456",
    "phone": "+92-300-1234567"
  }'
```

**Expected:** Status 201, returns user object and JWT token

**Save the token** for authenticated requests!

### Test 1.2: Login (Admin)

```bash
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@pakads.com",
    "password": "admin123"
  }'
```

**Expected:** Status 200, returns admin user and token

**Save the admin token** separately!

### Test 1.3: Get Current User

```bash
curl http://localhost:4000/api/v1/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, returns user details

### Test 1.4: Update User Details

```bash
curl -X PUT http://localhost:4000/api/v1/auth/updatedetails \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "name": "Test User Updated",
    "phone": "+92-300-9999999"
  }'
```

**Expected:** Status 200, returns updated user

---

## 2️⃣ Category APIs (7 endpoints)

### Test 2.1: Get All Categories

```bash
curl "http://localhost:4000/api/v1/categories"
```

**Expected:** Status 200, list of all categories

### Test 2.2: Get Category Tree

```bash
curl "http://localhost:4000/api/v1/categories/tree"
```

**Expected:** Status 200, hierarchical category structure with subcategories

### Test 2.3: Get Single Category

```bash
curl "http://localhost:4000/api/v1/categories/1"
```

**Expected:** Status 200, category details with subcategories

### Test 2.4: Create Category (Admin Only)

```bash
curl -X POST http://localhost:4000/api/v1/categories \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE" \
  -d '{
    "name": "Test Category",
    "slug": "test-category-unique",
    "description": "Testing category creation",
    "icon": "🔧",
    "is_active": true,
    "display_order": 100
  }'
```

**Expected:** Status 201, returns created category

### Test 2.5: Update Category (Admin Only)

```bash
curl -X PUT http://localhost:4000/api/v1/categories/1 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE" \
  -d '{
    "description": "Updated description"
  }'
```

**Expected:** Status 200, returns updated category

---

## 3️⃣ Location APIs (7 endpoints)

### Test 3.1: Get All Locations

```bash
curl "http://localhost:4000/api/v1/locations"
```

**Expected:** Status 200, list of all locations

### Test 3.2: Get Location Tree

```bash
curl "http://localhost:4000/api/v1/locations/tree"
```

**Expected:** Status 200, hierarchical location structure

### Test 3.3: Get Locations by Type

```bash
curl "http://localhost:4000/api/v1/locations?type=city"
```

**Expected:** Status 200, only cities

### Test 3.4: Search Locations

```bash
curl "http://localhost:4000/api/v1/locations?search=lahore"
```

**Expected:** Status 200, locations matching "lahore"

---

## 4️⃣ Package APIs (6 endpoints)

### Test 4.1: Get All Packages

```bash
curl "http://localhost:4000/api/v1/packages"
```

**Expected:** Status 200, list of all 5 packages (Free to Platinum)

### Test 4.2: Get Active Packages

```bash
curl "http://localhost:4000/api/v1/packages?is_active=true"
```

**Expected:** Status 200, only active packages

---

## 5️⃣ Ad APIs (10 endpoints)

### Test 5.1: Browse All Ads

```bash
curl "http://localhost:4000/api/v1/ads?page=1&limit=10"
```

**Expected:** Status 200, paginated list of ads (may be empty initially)

### Test 5.2: Create Ad

```bash
curl -X POST http://localhost:4000/api/v1/ads \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "title": "iPhone 13 Pro Max 256GB",
    "slug": "iphone-13-pro-max-256gb-test1",
    "description": "Brand new sealed iPhone 13 Pro Max with 256GB storage. Complete box with all accessories.",
    "price": 120000,
    "is_negotiable": true,
    "condition": "new",
    "category_id": 1,
    "location_id": 1,
    "address": "DHA Phase 5, Lahore",
    "phone": "+92-300-1234567",
    "email": "seller@example.com"
  }'
```

**Expected:** Status 201, returns created ad (status will be "pending")

**Save the ad ID!**

### Test 5.3: Get Single Ad

```bash
curl "http://localhost:4000/api/v1/ads/1"
```

**Expected:** Status 200, complete ad details (view_count should increment)

### Test 5.4: Search Ads

```bash
curl "http://localhost:4000/api/v1/ads?search=iphone"
```

**Expected:** Status 200, ads matching search

### Test 5.5: Filter by Category

```bash
curl "http://localhost:4000/api/v1/ads?category_id=1"
```

**Expected:** Status 200, ads in category 1

### Test 5.6: Filter by Price Range

```bash
curl "http://localhost:4000/api/v1/ads?min_price=10000&max_price=150000"
```

**Expected:** Status 200, ads within price range

### Test 5.7: Approve Ad (Admin)

```bash
curl -X PUT http://localhost:4000/api/v1/ads/1/approve \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE"
```

**Expected:** Status 200, ad status changes to "active"

### Test 5.8: Feature Ad (Admin)

```bash
curl -X PUT http://localhost:4000/api/v1/ads/1/feature \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE" \
  -d '{"days": 7}'
```

**Expected:** Status 200, ad becomes featured for 7 days

### Test 5.9: Get Ad Statistics (Admin)

```bash
curl "http://localhost:4000/api/v1/ads/admin/stats" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE"
```

**Expected:** Status 200, returns statistics (total, featured, active, pending)

---

## 6️⃣ Favorites APIs (4 endpoints)

### Test 6.1: Add to Favorites

```bash
curl -X POST http://localhost:4000/api/v1/favorites/1 \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 201, favorite created

### Test 6.2: Check if Favorited

```bash
curl "http://localhost:4000/api/v1/favorites/check/1" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, `{"is_favorited": true}`

### Test 6.3: Get All Favorites

```bash
curl "http://localhost:4000/api/v1/favorites" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, list of favorited ads

### Test 6.4: Remove from Favorites

```bash
curl -X DELETE http://localhost:4000/api/v1/favorites/1 \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, favorite removed

---

## 7️⃣ Review APIs (7 endpoints)

### Test 7.1: Create Review

```bash
curl -X POST http://localhost:4000/api/v1/reviews \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "ad_id": 1,
    "rating": 5,
    "comment": "Excellent seller! Very responsive and product as described."
  }'
```

**Expected:** Status 201, review created

### Test 7.2: Get Reviews for Ad

```bash
curl "http://localhost:4000/api/v1/reviews?ad_id=1"
```

**Expected:** Status 200, list of reviews

### Test 7.3: Get Reviews for Seller

```bash
curl "http://localhost:4000/api/v1/reviews?seller_id=1"
```

**Expected:** Status 200, reviews received by seller

---

## 8️⃣ Message APIs (7 endpoints)

### Test 8.1: Send Message

```bash
curl -X POST http://localhost:4000/api/v1/messages \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "ad_id": 1,
    "receiver_id": 1,
    "message": "Hi! Is this item still available? Can I visit to see it?"
  }'
```

**Expected:** Status 201, message sent

### Test 8.2: Get All Messages

```bash
curl "http://localhost:4000/api/v1/messages" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, list of messages

### Test 8.3: Get Unread Count

```bash
curl "http://localhost:4000/api/v1/messages/unread/count" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, `{"unread_count": X}`

### Test 8.4: Get Conversation

```bash
curl "http://localhost:4000/api/v1/messages/conversation/1/1" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, conversation thread

---

## 9️⃣ Dashboard APIs (3 endpoints)

### Test 9.1: Get Homepage Data

```bash
curl "http://localhost:4000/api/v1/dashboard/home"
```

**Expected:** Status 200, featured ads, recent ads, categories, locations

### Test 9.2: Get User Dashboard

```bash
curl "http://localhost:4000/api/v1/dashboard/stats" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, user statistics (ads, views, favorites, messages, reviews)

### Test 9.3: Get Admin Dashboard

```bash
curl "http://localhost:4000/api/v1/dashboard/admin/stats" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE"
```

**Expected:** Status 200, complete system statistics

---

## 🔟 Profile APIs (3 endpoints)

### Test 10.1: Get User Profile

```bash
curl "http://localhost:4000/api/v1/profile/1"
```

**Expected:** Status 200, public profile with stats

### Test 10.2: Get User's Ads

```bash
curl "http://localhost:4000/api/v1/profile/1/ads"
```

**Expected:** Status 200, user's active ads

### Test 10.3: Get User's Reviews

```bash
curl "http://localhost:4000/api/v1/profile/1/reviews"
```

**Expected:** Status 200, reviews received

---

## 1️⃣1️⃣ Notification APIs (6 endpoints)

### Test 11.1: Get All Notifications

```bash
curl "http://localhost:4000/api/v1/notifications" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, list of notifications

### Test 11.2: Get Unread Count

```bash
curl "http://localhost:4000/api/v1/notifications/unread/count" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**Expected:** Status 200, `{"unread_count": X}`

---

## 1️⃣2️⃣ Report APIs (7 endpoints)

### Test 12.1: Create Report

```bash
curl -X POST http://localhost:4000/api/v1/reports \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "ad_id": 1,
    "reason": "spam",
    "description": "This ad appears to be spam"
  }'
```

**Expected:** Status 201, report created

### Test 12.2: Get All Reports (Admin)

```bash
curl "http://localhost:4000/api/v1/reports" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE"
```

**Expected:** Status 200, list of all reports

### Test 12.3: Get Report Statistics (Admin)

```bash
curl "http://localhost:4000/api/v1/reports/stats" \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE"
```

**Expected:** Status 200, report statistics

---

## 🧪 Complete Test Script (PowerShell)

Save this as `test-apis.ps1`:

```powershell
$BaseUrl = "http://localhost:4000/api/v1"
$AdminEmail = "admin@pakads.com"
$AdminPassword = "admin123"

Write-Host "`n=== TESTING PAK ADS BACKEND APIs ===`n" -ForegroundColor Cyan

# Test 1: Health Check
Write-Host "1. Testing Health Check..." -ForegroundColor Yellow
try {
    $health = Invoke-RestMethod -Uri "http://localhost:4000/health"
    Write-Host "   ✅ Health Check Passed" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Health Check Failed: $_" -ForegroundColor Red
    exit
}

# Test 2: Admin Login
Write-Host "2. Testing Admin Login..." -ForegroundColor Yellow
try {
    $loginBody = @{
        email = $AdminEmail
        password = $AdminPassword
    } | ConvertTo-Json

    $loginResponse = Invoke-RestMethod -Uri "$BaseUrl/auth/login" -Method Post -Body $loginBody -ContentType "application/json"
    $AdminToken = $loginResponse.token
    Write-Host "   ✅ Admin Login Successful" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Admin Login Failed: $_" -ForegroundColor Red
}

# Test 3: Get Categories
Write-Host "3. Testing Get Categories..." -ForegroundColor Yellow
try {
    $categories = Invoke-RestMethod -Uri "$BaseUrl/categories"
    Write-Host "   ✅ Categories Retrieved: $($categories.count) items" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Get Categories Failed: $_" -ForegroundColor Red
}

# Test 4: Get Locations
Write-Host "4. Testing Get Locations..." -ForegroundColor Yellow
try {
    $locations = Invoke-RestMethod -Uri "$BaseUrl/locations"
    Write-Host "   ✅ Locations Retrieved: $($locations.count) items" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Get Locations Failed: $_" -ForegroundColor Red
}

# Test 5: Get Packages
Write-Host "5. Testing Get Packages..." -ForegroundColor Yellow
try {
    $packages = Invoke-RestMethod -Uri "$BaseUrl/packages"
    Write-Host "   ✅ Packages Retrieved: $($packages.count) items" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Get Packages Failed: $_" -ForegroundColor Red
}

# Test 6: Get Homepage Data
Write-Host "6. Testing Get Homepage Data..." -ForegroundColor Yellow
try {
    $homepage = Invoke-RestMethod -Uri "$BaseUrl/dashboard/home"
    Write-Host "   ✅ Homepage Data Retrieved" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Get Homepage Data Failed: $_" -ForegroundColor Red
}

# Test 7: Create Ad
Write-Host "7. Testing Create Ad..." -ForegroundColor Yellow
try {
    $adBody = @{
        title = "Test iPhone 13"
        slug = "test-iphone-13-" + (Get-Date -Format "yyyyMMddHHmmss")
        description = "Testing ad creation"
        price = 100000
        is_negotiable = $true
        condition = "new"
        category_id = 1
        location_id = 1
        phone = "+92-300-1234567"
    } | ConvertTo-Json

    $headers = @{ Authorization = "Bearer $AdminToken" }
    $adResponse = Invoke-RestMethod -Uri "$BaseUrl/ads" -Method Post -Body $adBody -ContentType "application/json" -Headers $headers
    $AdId = $adResponse.data.id
    Write-Host "   ✅ Ad Created: ID $AdId" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Create Ad Failed: $_" -ForegroundColor Red
}

# Test 8: Get Single Ad
if ($AdId) {
    Write-Host "8. Testing Get Single Ad..." -ForegroundColor Yellow
    try {
        $ad = Invoke-RestMethod -Uri "$BaseUrl/ads/$AdId"
        Write-Host "   ✅ Ad Retrieved: views_count = $($ad.data.views_count)" -ForegroundColor Green
    } catch {
        Write-Host "   ❌ Get Ad Failed: $_" -ForegroundColor Red
    }
}

# Test 9: Search Ads
Write-Host "9. Testing Search Ads..." -ForegroundColor Yellow
try {
    $searchResults = Invoke-RestMethod -Uri "$BaseUrl/ads?search=iphone"
    Write-Host "   ✅ Search Completed: $($searchResults.count) results" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Search Failed: $_" -ForegroundColor Red
}

# Test 10: Get Dashboard Stats
Write-Host "10. Testing User Dashboard Stats..." -ForegroundColor Yellow
try {
    $headers = @{ Authorization = "Bearer $AdminToken" }
    $dashStats = Invoke-RestMethod -Uri "$BaseUrl/dashboard/stats" -Headers $headers
    Write-Host "   ✅ Dashboard Stats Retrieved" -ForegroundColor Green
} catch {
    Write-Host "   ❌ Dashboard Stats Failed: $_" -ForegroundColor Red
}

Write-Host "`n=== TESTING COMPLETE ===`n" -ForegroundColor Cyan
```

Run it:
```bash
.\test-apis.ps1
```

---

## 📊 Expected Results Summary

### ✅ All endpoints should return:
- **Success Response**: `{"success": true, ...}`
- **Proper HTTP Status Codes**: 200, 201, 400, 401, 403, 404
- **Pagination**: `count`, `total`, `page`, `pages`
- **Data Structure**: Consistent JSON format

### ✅ Authentication should work:
- Register creates user and returns token
- Login returns token
- Protected routes reject without token
- Admin routes reject non-admin users

### ✅ Data relationships should work:
- Ads include category, location, user, images
- Reviews include ad, reviewer info
- Messages include sender, receiver, ad info
- Favorites include complete ad details

### ✅ Business logic should work:
- View counter increments on ad view
- Favorites counter updates
- Can't review same ad twice
- Can't report same ad twice
- Approval workflow (pending → active)

---

## 🐛 Common Issues & Solutions

### Issue 1: Server Not Starting
**Solution:**
```bash
# Check if port 3000 is in use
Get-NetTCPConnection -LocalPort 3000

# Kill the process
Get-Process -Id (Get-NetTCPConnection -LocalPort 3000).OwningProcess | Stop-Process -Force

# Restart
npm run dev
```

### Issue 2: Database Connection Error
**Solution:**
- Verify PostgreSQL is running
- Check `.env` database credentials
- Test connection: `psql -U postgres -d node_pak_ads_db`

### Issue 3: Token Expired
**Solution:**
- Login again to get fresh token
- Token is valid for 7 days by default

### Issue 4: 404 Not Found
**Solution:**
- Check URL path `/api/v1/...`
- Verify migrations ran: `npm run db:migrate`
- Check if data seeded: `npm run db:seed`

---

## 📝 Test Checklist

Use this checklist to track your testing:

### Authentication ✅
- [ ] Register user
- [ ] Login user
- [ ] Get current user
- [ ] Update user details
- [ ] Update password
- [ ] Logout

### Categories ✅
- [ ] Get all categories
- [ ] Get category tree
- [ ] Get single category
- [ ] Create category (admin)
- [ ] Update category (admin)

### Locations ✅
- [ ] Get all locations
- [ ] Get location tree
- [ ] Search locations
- [ ] Filter by type

### Ads ✅
- [ ] Browse all ads
- [ ] Search ads
- [ ] Filter by category
- [ ] Filter by location
- [ ] Filter by price range
- [ ] Create ad
- [ ] Get single ad
- [ ] Update ad
- [ ] Delete ad
- [ ] Approve ad (admin)
- [ ] Reject ad (admin)
- [ ] Feature ad (admin)
- [ ] Get statistics (admin)

### Favorites ✅
- [ ] Add to favorites
- [ ] Check if favorited
- [ ] Get all favorites
- [ ] Remove from favorites

### Reviews ✅
- [ ] Create review
- [ ] Get reviews for ad
- [ ] Get reviews for seller
- [ ] Update review
- [ ] Delete review
- [ ] Approve review (admin)

### Messages ✅
- [ ] Send message
- [ ] Get all messages
- [ ] Get conversation
- [ ] Get unread count
- [ ] Mark as read

### Reports ✅
- [ ] Create report
- [ ] Get all reports (admin)
- [ ] Update report status (admin)
- [ ] Get statistics (admin)

### Dashboard ✅
- [ ] Get homepage data
- [ ] Get user dashboard
- [ ] Get admin dashboard

### Profile ✅
- [ ] Get user profile
- [ ] Get user's ads
- [ ] Get user's reviews

### Notifications ✅
- [ ] Get all notifications
- [ ] Get unread count
- [ ] Mark as read
- [ ] Mark all as read

### Packages ✅
- [ ] Get all packages
- [ ] Get single package

---

## 🎯 Integration Testing Scenarios

### Scenario 1: New User Posts Ad
1. Register → Get token
2. Get categories → Select category
3. Get locations → Select location
4. Create ad → Get ad ID
5. Verify ad is in pending status
6. Admin approves ad
7. Verify ad is now active

### Scenario 2: User Browses and Favorites
1. Get homepage data
2. Browse ads by category
3. View ad details (increments views)
4. Add to favorites
5. Get favorites list
6. Contact seller (send message)

### Scenario 3: User Reviews Seller
1. Find completed transaction
2. Create review with rating
3. View seller's profile
4. See review appears in seller's profile

### Scenario 4: Admin Moderates Content
1. Login as admin
2. View pending ads
3. Approve/reject ads
4. View reports
5. Process reports
6. Feature specific ads
7. View statistics

---

## 📊 Performance Benchmarks

Test these for performance:

```bash
# Pagination stress test
curl "http://localhost:4000/api/v1/ads?limit=100"

# Complex filter query
curl "http://localhost:4000/api/v1/ads?category_id=1&location_id=5&min_price=10000&max_price=100000&condition=new&search=phone"

# Multiple includes
curl "http://localhost:4000/api/v1/ads/1" # Should include user, category, location, images
```

**Expected:** All responses under 1 second

---

## 📄 Test Report Template

After testing, fill this out:

### ✅ Working Endpoints: ___/82
### ❌ Failing Endpoints: ___/82
### ⚠️ Endpoints with Issues: ___/82

### Issues Found:
1. 
2. 
3. 

### Performance Notes:
- Average response time:
- Slowest endpoint:
- Database query optimization needed:

---

## 🚀 Ready for Frontend Integration

Once all tests pass:
1. Update frontend environment variables
2. Test CORS settings
3. Integrate with React/Next.js
4. Deploy to production

---

**Start Testing:** Make sure server is running on `http://localhost:4000`  
**Test Order:** Follow the numbered sections above  
**Report Issues:** Document any failures

**Good luck with testing!** 🎉

